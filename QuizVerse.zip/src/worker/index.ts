import { Hono } from "hono";

const app = new Hono<{ Bindings: Env }>();

// Save a quiz score
app.post("/api/scores", async (c) => {
  const { studentName, quizId, quizTitle, score, totalQuestions, timeTaken } = await c.req.json();
  
  if (!studentName || !quizId || score === undefined) {
    return c.json({ error: "Missing required fields" }, 400);
  }

  const now = new Date().toISOString();
  
  await c.env.DB.prepare(
    `INSERT INTO scores (student_name, quiz_id, quiz_title, score, total_questions, time_taken, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(studentName, quizId, quizTitle, score, totalQuestions, timeTaken, now, now).run();

  return c.json({ success: true });
});

// Get leaderboard - top scores for each quiz
app.get("/api/leaderboard", async (c) => {
  const quizId = c.req.query("quizId");
  
  let query = `
    SELECT id, student_name, quiz_id, quiz_title, score, total_questions, time_taken, created_at
    FROM scores
  `;
  
  if (quizId) {
    query += ` WHERE quiz_id = ? ORDER BY score DESC, time_taken ASC LIMIT 20`;
    const results = await c.env.DB.prepare(query).bind(quizId).all();
    return c.json(results.results);
  }
  
  // Get top 5 from each quiz
  query = `
    SELECT id, student_name, quiz_id, quiz_title, score, total_questions, time_taken, created_at
    FROM scores
    ORDER BY score DESC, time_taken ASC
    LIMIT 50
  `;
  
  const results = await c.env.DB.prepare(query).all();
  return c.json(results.results);
});

export default app;
