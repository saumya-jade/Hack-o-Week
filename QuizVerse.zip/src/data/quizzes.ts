export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  subject: string;
  questions: Question[];
}

export const quizzes: Quiz[] = [
  {
    id: "physics-12",
    title: "Physics - Complete 12th Board",
    subject: "Physics",
    questions: [
      // Electrostatics
      {
        id: 1,
        question: "The electric field inside a charged conductor in electrostatic equilibrium is:",
        options: ["Maximum at the center", "Zero everywhere", "Uniform throughout", "Maximum at the surface"],
        correctAnswer: 1,
        explanation: "In electrostatic equilibrium, free charges distribute on the surface of a conductor. Inside, the net electric field is zero because any field would cause charge movement, contradicting equilibrium."
      },
      {
        id: 2,
        question: "Two point charges +q and -q are placed at distance 'd' apart. The electric field at the midpoint is:",
        options: ["Zero", "Directed towards +q", "Directed towards -q", "Perpendicular to the line joining charges"],
        correctAnswer: 2,
        explanation: "At the midpoint, field due to +q points away from it (towards -q) and field due to -q also points towards -q. Both fields add up in the direction towards -q."
      },
      {
        id: 3,
        question: "The capacitance of a parallel plate capacitor increases when:",
        options: ["Distance between plates increases", "Area of plates decreases", "A dielectric is inserted between plates", "The charge on plates is reduced"],
        correctAnswer: 2,
        explanation: "Capacitance C = εA/d. Inserting a dielectric increases the permittivity ε, thereby increasing the capacitance. Area decrease or distance increase would reduce capacitance."
      },
      // Current Electricity
      {
        id: 4,
        question: "The drift velocity of electrons in a conductor is proportional to:",
        options: ["Square of electric field", "Electric field", "Inverse of electric field", "Square root of electric field"],
        correctAnswer: 1,
        explanation: "Drift velocity vd = eEτ/m, where E is electric field, τ is relaxation time, e is charge, and m is mass. This shows vd is directly proportional to E."
      },
      {
        id: 5,
        question: "In a Wheatstone bridge, the condition for balance is:",
        options: ["P/Q = R/S", "P×Q = R×S", "P+Q = R+S", "P-Q = R-S"],
        correctAnswer: 0,
        explanation: "A Wheatstone bridge is balanced when no current flows through the galvanometer. This occurs when P/Q = R/S, where P, Q, R, S are the four resistances."
      },
      // Magnetic Effects of Current
      {
        id: 6,
        question: "A circular coil of radius R carries current I. The magnetic field at its center is:",
        options: ["μ₀I/R", "μ₀I/2R", "μ₀IR/2", "μ₀I²/R"],
        correctAnswer: 1,
        explanation: "Using Biot-Savart law, the magnetic field at the center of a circular coil is B = μ₀I/2R, where μ₀ is permeability of free space."
      },
      {
        id: 7,
        question: "The force experienced by a current-carrying conductor placed perpendicular to a magnetic field B is:",
        options: ["Zero", "BIL", "BI/L", "BL/I"],
        correctAnswer: 1,
        explanation: "When a conductor of length L carrying current I is placed perpendicular to magnetic field B, the force F = BIL (from F = BIL sinθ, where θ = 90°)."
      },
      // Electromagnetic Induction
      {
        id: 8,
        question: "According to Lenz's law, the direction of induced EMF is such that it:",
        options: ["Aids the change in flux", "Opposes the change in flux", "Is independent of flux change", "Is parallel to magnetic field"],
        correctAnswer: 1,
        explanation: "Lenz's law states that induced EMF always opposes the change in magnetic flux that produces it. This is a consequence of conservation of energy."
      },
      {
        id: 9,
        question: "The self-inductance of a solenoid depends on:",
        options: ["Current through it only", "Number of turns, area and length", "Material of core only", "Applied voltage"],
        correctAnswer: 1,
        explanation: "Self-inductance L = μ₀n²V = μ₀N²A/l, where N is number of turns, A is cross-sectional area, and l is length. It's a geometric property."
      },
      // Alternating Current
      {
        id: 10,
        question: "In a pure inductive AC circuit, the current:",
        options: ["Leads voltage by 90°", "Lags voltage by 90°", "Is in phase with voltage", "Leads voltage by 45°"],
        correctAnswer: 1,
        explanation: "In a pure inductor, voltage leads current by 90° (or current lags voltage by 90°) because inductor opposes change in current."
      },
      {
        id: 11,
        question: "At resonance in an LCR series circuit:",
        options: ["Impedance is maximum", "Current is minimum", "Power factor is unity", "Voltage across L equals applied voltage"],
        correctAnswer: 2,
        explanation: "At resonance, XL = XC, so impedance Z = R (minimum), current is maximum, and power factor cos φ = R/Z = 1 (unity)."
      },
      // Optics
      {
        id: 12,
        question: "In Young's double slit experiment, the fringe width is:",
        options: ["λD/d", "λd/D", "Dd/λ", "λ/Dd"],
        correctAnswer: 0,
        explanation: "Fringe width β = λD/d, where λ is wavelength, D is distance to screen, and d is slit separation. Fringe width increases with wavelength and screen distance."
      },
      {
        id: 13,
        question: "Total internal reflection occurs when light travels from:",
        options: ["Rarer to denser medium", "Denser to rarer medium at angle > critical angle", "Any medium to vacuum", "Vacuum to any medium"],
        correctAnswer: 1,
        explanation: "Total internal reflection requires light to travel from denser to rarer medium and the angle of incidence must exceed the critical angle."
      },
      // Modern Physics
      {
        id: 14,
        question: "The binding energy per nucleon is maximum for:",
        options: ["Hydrogen", "Uranium", "Iron", "Helium"],
        correctAnswer: 2,
        explanation: "Iron-56 has the maximum binding energy per nucleon (~8.8 MeV), making it the most stable nucleus. This explains why fusion releases energy for lighter elements and fission for heavier ones."
      },
      {
        id: 15,
        question: "In photoelectric effect, the stopping potential depends on:",
        options: ["Intensity of light only", "Frequency of light", "Both intensity and frequency equally", "Nature of collector plate"],
        correctAnswer: 1,
        explanation: "Stopping potential V₀ = (hν - φ)/e depends only on frequency ν and work function φ. Intensity affects the number of photoelectrons, not their maximum energy."
      }
    ]
  },
  {
    id: "chemistry-12",
    title: "Chemistry - Complete 12th Board",
    subject: "Chemistry",
    questions: [
      // Solid State
      {
        id: 1,
        question: "The number of atoms in a face-centered cubic (FCC) unit cell is:",
        options: ["1", "2", "4", "6"],
        correctAnswer: 2,
        explanation: "In FCC: 8 corner atoms × 1/8 + 6 face atoms × 1/2 = 1 + 3 = 4 atoms per unit cell."
      },
      {
        id: 2,
        question: "Schottky defect is observed in crystals when:",
        options: ["Ions occupy interstitial sites", "Equal number of cations and anions are missing", "Electrons are trapped in anion vacancies", "Foreign atoms replace host atoms"],
        correctAnswer: 1,
        explanation: "Schottky defect occurs when equal numbers of cations and anions leave their lattice sites, creating vacancies while maintaining electrical neutrality."
      },
      // Solutions
      {
        id: 3,
        question: "According to Raoult's law, the relative lowering of vapor pressure is equal to:",
        options: ["Mole fraction of solvent", "Mole fraction of solute", "Molarity of solution", "Molality of solution"],
        correctAnswer: 1,
        explanation: "Raoult's law states (P° - P)/P° = x₂, where x₂ is the mole fraction of the non-volatile solute. This is the relative lowering of vapor pressure."
      },
      {
        id: 4,
        question: "An azeotropic mixture is one which:",
        options: ["Boils at constant temperature", "Has same composition in liquid and vapor phase", "Cannot be separated by distillation", "All of the above"],
        correctAnswer: 3,
        explanation: "Azeotropes are constant boiling mixtures where liquid and vapor have identical composition, making separation by simple distillation impossible."
      },
      // Electrochemistry
      {
        id: 5,
        question: "The standard electrode potential of hydrogen electrode is taken as:",
        options: ["1 V", "-1 V", "0 V", "0.5 V"],
        correctAnswer: 2,
        explanation: "By convention, the standard hydrogen electrode (SHE) is assigned a potential of exactly 0 V. All other electrode potentials are measured relative to it."
      },
      {
        id: 6,
        question: "In electrolysis of molten NaCl, at cathode:",
        options: ["Chlorine is liberated", "Sodium is deposited", "Oxygen is evolved", "Hydrogen is evolved"],
        correctAnswer: 1,
        explanation: "In electrolysis of molten NaCl, Na⁺ ions move to cathode and get reduced: Na⁺ + e⁻ → Na. Sodium metal is deposited at the cathode."
      },
      // Chemical Kinetics
      {
        id: 7,
        question: "The half-life of a first-order reaction is:",
        options: ["Dependent on initial concentration", "Independent of initial concentration", "Doubled when concentration is halved", "Halved when temperature is doubled"],
        correctAnswer: 1,
        explanation: "For first-order reactions, t₁/₂ = 0.693/k. The half-life depends only on the rate constant k, not on initial concentration."
      },
      {
        id: 8,
        question: "The Arrhenius equation relates rate constant to:",
        options: ["Concentration and time", "Temperature and activation energy", "Pressure and volume", "Catalyst and inhibitor"],
        correctAnswer: 1,
        explanation: "Arrhenius equation k = Ae^(-Ea/RT) relates rate constant to temperature T and activation energy Ea. A is the pre-exponential factor."
      },
      // Surface Chemistry
      {
        id: 9,
        question: "Physical adsorption is characterized by:",
        options: ["High activation energy", "Irreversibility", "Low heat of adsorption", "Chemical bond formation"],
        correctAnswer: 2,
        explanation: "Physisorption involves weak van der Waals forces, hence low heat of adsorption (20-40 kJ/mol), reversibility, and no activation energy."
      },
      {
        id: 10,
        question: "Coagulation of a colloid can be achieved by:",
        options: ["Adding electrolyte", "Dilution", "Cooling", "Adding protective colloid"],
        correctAnswer: 0,
        explanation: "Adding an electrolyte neutralizes the charge on colloidal particles, removing the electrostatic stabilization and causing particles to aggregate (coagulate)."
      },
      // Coordination Compounds
      {
        id: 11,
        question: "The coordination number of central metal ion in [Fe(CN)₆]⁴⁻ is:",
        options: ["4", "5", "6", "8"],
        correctAnswer: 2,
        explanation: "Coordination number equals the number of donor atoms bonded to the central metal. Here, 6 CN⁻ ligands are attached to Fe, giving coordination number 6."
      },
      {
        id: 12,
        question: "Which of the following is a bidentate ligand?",
        options: ["Ammonia", "Water", "Ethylenediamine", "Chloride ion"],
        correctAnswer: 2,
        explanation: "Ethylenediamine (en) has two nitrogen atoms that can donate electron pairs to the central metal, making it a bidentate ligand. NH₃, H₂O, and Cl⁻ are monodentate."
      },
      // Organic Chemistry - Haloalkanes
      {
        id: 13,
        question: "In SN2 reaction mechanism:",
        options: ["Carbocation intermediate forms", "Reaction rate depends on both substrate and nucleophile", "Racemization occurs", "Tertiary halides react fastest"],
        correctAnswer: 1,
        explanation: "SN2 is a one-step bimolecular reaction where rate = k[substrate][nucleophile]. It proceeds with inversion of configuration (Walden inversion)."
      },
      // Alcohols and Phenols
      {
        id: 14,
        question: "Lucas reagent is used to distinguish between:",
        options: ["Aldehydes and ketones", "Primary, secondary, and tertiary alcohols", "Alkenes and alkynes", "Carboxylic acids and esters"],
        correctAnswer: 1,
        explanation: "Lucas reagent (conc. HCl + ZnCl₂) reacts differently with alcohols: tertiary alcohols react immediately, secondary in 5 minutes, primary very slowly or require heating."
      },
      // Biomolecules
      {
        id: 15,
        question: "The peptide bond is formed between:",
        options: ["Two carboxyl groups", "Two amino groups", "Amino group of one amino acid and carboxyl group of another", "Amino acids and carbohydrates"],
        correctAnswer: 2,
        explanation: "A peptide bond forms when the carboxyl group (-COOH) of one amino acid reacts with the amino group (-NH₂) of another, releasing water (condensation reaction)."
      }
    ]
  },
  {
    id: "maths-12",
    title: "Maths - Complete 12th Board",
    subject: "Mathematics",
    questions: [
      // Relations and Functions
      {
        id: 1,
        question: "A relation R on set A is an equivalence relation if it is:",
        options: ["Reflexive only", "Symmetric only", "Transitive only", "Reflexive, symmetric, and transitive"],
        correctAnswer: 3,
        explanation: "An equivalence relation must satisfy all three properties: reflexive (aRa), symmetric (if aRb then bRa), and transitive (if aRb and bRc then aRc)."
      },
      {
        id: 2,
        question: "If f(x) = x² and g(x) = √x, then fog(x) equals:",
        options: ["x", "x²", "|x|", "√x²"],
        correctAnswer: 0,
        explanation: "fog(x) = f(g(x)) = f(√x) = (√x)² = x (for x ≥ 0). The composition of squaring and square root returns the original value."
      },
      // Inverse Trigonometric Functions
      {
        id: 3,
        question: "The principal value of sin⁻¹(1/2) is:",
        options: ["π/3", "π/6", "π/4", "5π/6"],
        correctAnswer: 1,
        explanation: "sin⁻¹(1/2) gives the angle whose sine is 1/2. In the principal range [-π/2, π/2], this angle is π/6 (30°), since sin(π/6) = 1/2."
      },
      {
        id: 4,
        question: "tan⁻¹(1) + tan⁻¹(2) + tan⁻¹(3) equals:",
        options: ["π", "π/2", "3π/4", "π/4"],
        correctAnswer: 0,
        explanation: "Using the formula for sum of inverse tangents and the fact that tan⁻¹(1) = π/4, and tan⁻¹(2) + tan⁻¹(3) = π - tan⁻¹(1) = 3π/4, the total is π."
      },
      // Matrices and Determinants
      {
        id: 5,
        question: "If A is a square matrix of order 3 and |A| = 5, then |adj A| equals:",
        options: ["5", "25", "125", "1/5"],
        correctAnswer: 1,
        explanation: "For an n×n matrix, |adj A| = |A|^(n-1). Here n = 3, so |adj A| = 5² = 25."
      },
      {
        id: 6,
        question: "A square matrix A is singular if:",
        options: ["|A| = 1", "|A| = 0", "A = A⁻¹", "A = Aᵀ"],
        correctAnswer: 1,
        explanation: "A singular matrix has determinant equal to zero. Such matrices have no inverse and their rows/columns are linearly dependent."
      },
      // Continuity and Differentiability
      {
        id: 7,
        question: "The derivative of eˣ with respect to x is:",
        options: ["xeˣ⁻¹", "eˣ", "eˣ⁻¹", "xeˣ"],
        correctAnswer: 1,
        explanation: "The exponential function eˣ is unique in that it is its own derivative. d/dx(eˣ) = eˣ for all x."
      },
      {
        id: 8,
        question: "If y = sin⁻¹x, then dy/dx equals:",
        options: ["1/√(1-x²)", "-1/√(1-x²)", "1/√(1+x²)", "1/(1-x²)"],
        correctAnswer: 0,
        explanation: "The derivative of inverse sine is d/dx(sin⁻¹x) = 1/√(1-x²), valid for |x| < 1."
      },
      // Applications of Derivatives
      {
        id: 9,
        question: "A function f(x) has a local maximum at x = c if:",
        options: ["f'(c) > 0", "f'(c) < 0", "f'(c) = 0 and f''(c) < 0", "f'(c) = 0 and f''(c) > 0"],
        correctAnswer: 2,
        explanation: "At a local maximum, f'(c) = 0 (critical point) and f''(c) < 0 (concave down). This is the second derivative test for maxima."
      },
      // Integrals
      {
        id: 10,
        question: "∫(1/x)dx equals:",
        options: ["x⁻²", "ln|x| + C", "-1/x² + C", "1 + C"],
        correctAnswer: 1,
        explanation: "The integral of 1/x is the natural logarithm. ∫(1/x)dx = ln|x| + C. The absolute value handles both positive and negative x."
      },
      {
        id: 11,
        question: "∫₀^π sin x dx equals:",
        options: ["0", "1", "2", "-1"],
        correctAnswer: 2,
        explanation: "∫₀^π sin x dx = [-cos x]₀^π = -cos π - (-cos 0) = -(-1) - (-1) = 1 + 1 = 2."
      },
      // Differential Equations
      {
        id: 12,
        question: "The order of the differential equation d²y/dx² + (dy/dx)³ + y = 0 is:",
        options: ["1", "2", "3", "5"],
        correctAnswer: 1,
        explanation: "The order of a differential equation is the highest derivative present. Here, the highest is d²y/dx² (second derivative), so order = 2."
      },
      // Vectors
      {
        id: 13,
        question: "If vectors a⃗ and b⃗ are perpendicular, then a⃗ · b⃗ equals:",
        options: ["1", "|a||b|", "0", "-1"],
        correctAnswer: 2,
        explanation: "The dot product a⃗ · b⃗ = |a||b|cos θ. When vectors are perpendicular, θ = 90°, so cos 90° = 0, making the dot product zero."
      },
      // Three Dimensional Geometry
      {
        id: 14,
        question: "The direction cosines of a line satisfy the relation:",
        options: ["l + m + n = 1", "l² + m² + n² = 1", "l × m × n = 1", "l - m - n = 0"],
        correctAnswer: 1,
        explanation: "Direction cosines (l, m, n) are cosines of angles with coordinate axes. Since they form a unit vector, l² + m² + n² = 1."
      },
      // Probability
      {
        id: 15,
        question: "If P(A) = 0.4 and P(B|A) = 0.5, then P(A ∩ B) equals:",
        options: ["0.9", "0.2", "0.8", "0.1"],
        correctAnswer: 1,
        explanation: "Using conditional probability: P(B|A) = P(A ∩ B)/P(A). Therefore, P(A ∩ B) = P(B|A) × P(A) = 0.5 × 0.4 = 0.2."
      }
    ]
  }
];
