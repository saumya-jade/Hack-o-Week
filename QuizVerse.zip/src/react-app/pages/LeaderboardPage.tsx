import { useEffect, useState } from "react";
import { Link } from "react-router";
import { Trophy, Clock, ArrowLeft, Users } from "lucide-react";
import { Button } from "@/react-app/components/ui/button";
import { quizzes } from "@/data/quizzes";

interface ScoreEntry {
  id: number;
  student_name: string;
  quiz_id: string;
  quiz_title: string;
  score: number;
  total_questions: number;
  time_taken: number;
  created_at: string;
}

export default function LeaderboardPage() {
  const [scores, setScores] = useState<ScoreEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedQuiz, setSelectedQuiz] = useState<string>("all");

  useEffect(() => {
    const link = document.createElement("link");
    link.href = "https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap";
    link.rel = "stylesheet";
    document.head.appendChild(link);
    return () => { document.head.removeChild(link); };
  }, []);

  useEffect(() => {
    fetchScores();
  }, [selectedQuiz]);

  const fetchScores = async () => {
    setLoading(true);
    try {
      const url = selectedQuiz === "all" 
        ? "/api/leaderboard" 
        : `/api/leaderboard?quizId=${selectedQuiz}`;
      const res = await fetch(url);
      const data = await res.json();
      setScores(data);
    } catch (error) {
      console.error("Failed to fetch leaderboard:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const getRankIcon = (index: number) => {
    if (index === 0) return <span className="text-2xl">🥇</span>;
    if (index === 1) return <span className="text-2xl">🥈</span>;
    if (index === 2) return <span className="text-2xl">🥉</span>;
    return <span className="w-8 h-8 flex items-center justify-center rounded-full bg-muted text-sm font-bold">{index + 1}</span>;
  };

  return (
    <div 
      className="min-h-screen"
      style={{ fontFamily: "'Nunito', sans-serif" }}
    >
      {/* Decorative background */}
      <div className="fixed inset-0 -z-10 overflow-hidden colorful-bg">
        <div className="absolute top-10 left-1/4 w-32 h-32 bg-purple-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
        <div className="absolute top-1/2 right-10 w-24 h-24 bg-cyan-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
        <div className="absolute bottom-20 left-10 w-40 h-40 bg-pink-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
        <div className="absolute bottom-1/3 right-1/4 w-36 h-36 bg-amber-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to="/" className="p-2 rounded-xl hover:bg-muted transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Trophy className="w-6 h-6 text-primary" />
              Leaderboard
            </h1>
            <p className="text-sm text-muted-foreground">Top quiz performers</p>
          </div>
        </div>

        {/* Quiz filter */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          <button
            onClick={() => setSelectedQuiz("all")}
            className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
              selectedQuiz === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-card border border-border hover:bg-muted"
            }`}
          >
            All Quizzes
          </button>
          {quizzes.map((quiz) => (
            <button
              key={quiz.id}
              onClick={() => setSelectedQuiz(quiz.id)}
              className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                selectedQuiz === quiz.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border hover:bg-muted"
              }`}
            >
              {quiz.title}
            </button>
          ))}
        </div>

        {/* Leaderboard list */}
        <div className="bg-card rounded-3xl border border-border shadow-lg overflow-hidden">
          {loading ? (
            <div className="p-12 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-muted-foreground">Loading scores...</p>
            </div>
          ) : scores.length === 0 ? (
            <div className="p-12 text-center">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-bold text-foreground mb-2">No scores yet!</h3>
              <p className="text-muted-foreground mb-6">Be the first to take a quiz and make the leaderboard.</p>
              <Button asChild>
                <Link to="/">Take a Quiz</Link>
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {/* Header row */}
              <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-muted/50 text-sm font-semibold text-muted-foreground">
                <div className="col-span-1">Rank</div>
                <div className="col-span-4">Student</div>
                <div className="col-span-3">Quiz</div>
                <div className="col-span-2 text-center">Score</div>
                <div className="col-span-2 text-right">Time</div>
              </div>
              
              {/* Score rows */}
              {scores.map((entry, index) => (
                <div 
                  key={entry.id}
                  className={`grid grid-cols-12 gap-4 px-6 py-4 items-center transition-colors hover:bg-muted/30 ${
                    index < 3 ? "bg-primary/5" : ""
                  }`}
                >
                  <div className="col-span-1 flex items-center">
                    {getRankIcon(index)}
                  </div>
                  <div className="col-span-4">
                    <p className="font-bold text-foreground truncate">{entry.student_name}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(entry.created_at)}</p>
                  </div>
                  <div className="col-span-3">
                    <p className="text-sm text-muted-foreground truncate">{entry.quiz_title}</p>
                  </div>
                  <div className="col-span-2 text-center">
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary font-bold">
                      {entry.score}/{entry.total_questions}
                    </span>
                  </div>
                  <div className="col-span-2 text-right flex items-center justify-end gap-1 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span className="font-medium">{formatTime(entry.time_taken)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Back button */}
        <div className="mt-8 text-center">
          <Button variant="outline" asChild className="gap-2">
            <Link to="/">
              <ArrowLeft className="w-4 h-4" />
              Back to Quizzes
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
