import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router";
import { quizzes, Question } from "@/data/quizzes";
import { Button } from "@/react-app/components/ui/button";
import { Input } from "@/react-app/components/ui/input";
import { ArrowLeft, CheckCircle2, XCircle, Trophy, RotateCcw, Home, Clock, User, Play } from "lucide-react";
import { Progress } from "@/react-app/components/ui/progress";

const SECONDS_PER_QUESTION = 240;

export default function QuizPage() {
  const { quizId } = useParams();
  const navigate = useNavigate();
  
  // Student info
  const [studentName, setStudentName] = useState("");
  const [hasStarted, setHasStarted] = useState(false);
  
  // Quiz state
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  
  // Timer state
  const [timeLeft, setTimeLeft] = useState(0);
  const [totalTimeTaken, setTotalTimeTaken] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  const quiz = quizzes.find((q) => q.id === quizId);
  const totalTime = quiz ? quiz.questions.length * SECONDS_PER_QUESTION : 0;

  useEffect(() => {
    const link = document.createElement("link");
    link.href = "https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap";
    link.rel = "stylesheet";
    document.head.appendChild(link);
    return () => { document.head.removeChild(link); };
  }, []);

  // Timer effect
  useEffect(() => {
    if (hasStarted && !isFinished && !showResult) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            // Time's up - auto submit or move to next
            handleTimeUp();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [hasStarted, isFinished, showResult, currentQuestion]);

  const handleTimeUp = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    // Auto-submit with no answer if not already answered
    if (selectedAnswer === null) {
      setShowResult(true);
      setAnswers([...answers, null]);
    }
  };

  const handleStartQuiz = () => {
    if (!studentName.trim()) return;
    setHasStarted(true);
    setTimeLeft(totalTime);
    startTimeRef.current = Date.now();
  };

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ fontFamily: "'Nunito', sans-serif" }}>
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Quiz not found</h1>
          <Link to="/" className="text-primary hover:underline">Go back home</Link>
        </div>
      </div>
    );
  }

  const question: Question = quiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100;

  const handleSelectAnswer = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;
    
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    setShowResult(true);
    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);
    
    if (selectedAnswer === question.correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      // Calculate total time taken
      const elapsed = Math.round((Date.now() - startTimeRef.current) / 1000);
      setTotalTimeTaken(elapsed);
      setIsFinished(true);
      
      // Save score to backend
      saveScore(elapsed);
    }
  };

  const saveScore = async (timeTaken: number) => {
    try {
      await fetch("/api/scores", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          studentName: studentName.trim(),
          quizId: quiz.id,
          quizTitle: quiz.title,
          score: score + (selectedAnswer === question.correctAnswer ? 1 : 0),
          totalQuestions: quiz.questions.length,
          timeTaken,
        }),
      });
    } catch (error) {
      console.error("Failed to save score:", error);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnswers([]);
    setIsFinished(false);
    setHasStarted(false);
    setStudentName("");
    setTimeLeft(0);
    setTotalTimeTaken(0);
  };

  const getOptionClass = (index: number) => {
    const base = "w-full p-4 text-left rounded-xl border-2 transition-all duration-200 font-medium";
    
    if (!showResult) {
      if (selectedAnswer === index) {
        return `${base} border-primary bg-primary/10 text-primary`;
      }
      return `${base} border-border bg-card hover:border-primary/50 hover:bg-primary/5`;
    }
    
    if (index === question.correctAnswer) {
      return `${base} border-emerald-500 bg-emerald-50 text-emerald-700`;
    }
    if (selectedAnswer === index && index !== question.correctAnswer) {
      return `${base} border-red-500 bg-red-50 text-red-700`;
    }
    return `${base} border-border bg-muted/50 text-muted-foreground`;
  };

  const getScoreMessage = () => {
    const finalScore = score;
    const percentage = (finalScore / quiz.questions.length) * 100;
    if (percentage === 100) return { emoji: "🎉", message: "Perfect score! Amazing!" };
    if (percentage >= 80) return { emoji: "🌟", message: "Great job! You're a star!" };
    if (percentage >= 60) return { emoji: "👍", message: "Good effort! Keep learning!" };
    if (percentage >= 40) return { emoji: "📚", message: "Not bad! Review and try again!" };
    return { emoji: "💪", message: "Keep practicing! You'll get better!" };
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getTimerColor = () => {
    if (timeLeft <= 10) return "text-red-500";
    if (timeLeft <= 30) return "text-orange-500";
    return "text-primary";
  };

  // Student info screen
  if (!hasStarted) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center p-4"
        style={{ fontFamily: "'Nunito', sans-serif" }}
      >
        {/* Decorative background */}
        <div className="fixed inset-0 -z-10 overflow-hidden colorful-bg">
          <div className="absolute top-10 right-1/4 w-32 h-32 bg-purple-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
          <div className="absolute top-1/3 left-10 w-24 h-24 bg-cyan-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
          <div className="absolute bottom-1/4 right-10 w-40 h-40 bg-pink-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
          <div className="absolute bottom-10 left-1/3 w-28 h-28 bg-amber-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
        </div>

        <div className="max-w-md w-full">
          <div className="bg-card rounded-3xl border border-border p-8 shadow-lg">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <User className="w-8 h-8 text-primary" />
              </div>
              <h1 className="text-2xl font-bold text-foreground mb-2">{quiz.title}</h1>
              <p className="text-muted-foreground">{quiz.subject} • {quiz.questions.length} questions</p>
            </div>

            <div className="bg-muted/50 rounded-2xl p-4 mb-6">
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>Time limit: {formatTime(totalTime)}</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Enter your name
                </label>
                <Input
                  type="text"
                  placeholder="Your name"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleStartQuiz()}
                  className="h-12 text-lg"
                />
              </div>

              <Button 
                onClick={handleStartQuiz}
                disabled={!studentName.trim()}
                className="w-full gap-2" 
                size="lg"
              >
                <Play className="w-4 h-4" />
                Start Quiz
              </Button>

              <Button 
                variant="outline" 
                asChild 
                className="w-full gap-2"
              >
                <Link to="/">
                  <ArrowLeft className="w-4 h-4" />
                  Back to Quizzes
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Results screen
  if (isFinished) {
    const { emoji, message } = getScoreMessage();
    const finalScore = score;
    
    return (
      <div 
        className="min-h-screen flex items-center justify-center p-4"
        style={{ fontFamily: "'Nunito', sans-serif" }}
      >
        <div className="max-w-md w-full">
          <div className="bg-card rounded-3xl border border-border p-8 text-center shadow-lg">
            <div className="text-6xl mb-4">{emoji}</div>
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-4">
              <Trophy className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-1">Great work, {studentName}!</h1>
            <p className="text-muted-foreground mb-6">{message}</p>
            
            <div className="bg-muted/50 rounded-2xl p-6 mb-4">
              <div className="text-5xl font-extrabold text-primary mb-1">
                {finalScore}/{quiz.questions.length}
              </div>
              <p className="text-sm text-muted-foreground">
                {Math.round((finalScore / quiz.questions.length) * 100)}% correct
              </p>
            </div>

            <div className="flex items-center justify-center gap-2 text-muted-foreground mb-6">
              <Clock className="w-4 h-4" />
              <span>Time: {formatTime(totalTimeTaken)}</span>
            </div>
            
            <div className="space-y-3">
              <Button onClick={handleRestart} className="w-full gap-2" size="lg">
                <RotateCcw className="w-4 h-4" />
                Try Again
              </Button>
              <Button variant="outline" asChild className="w-full gap-2" size="lg">
                <Link to="/leaderboard">
                  <Trophy className="w-4 h-4" />
                  View Leaderboard
                </Link>
              </Button>
              <Button variant="ghost" asChild className="w-full gap-2">
                <Link to="/">
                  <Home className="w-4 h-4" />
                  Back to Quizzes
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen"
      style={{ fontFamily: "'Nunito', sans-serif" }}
    >
      {/* Decorative background */}
      <div className="fixed inset-0 -z-10 overflow-hidden colorful-bg">
        <div className="absolute top-10 right-1/4 w-32 h-32 bg-purple-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
        <div className="absolute top-1/3 left-10 w-24 h-24 bg-cyan-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
        <div className="absolute bottom-1/4 right-10 w-40 h-40 bg-pink-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
        <div className="absolute bottom-10 left-1/3 w-28 h-28 bg-amber-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate("/")}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-foreground">{quiz.title}</h1>
            <p className="text-sm text-muted-foreground">{studentName}</p>
          </div>
          
          {/* Timer */}
          <div className={`flex items-center gap-2 px-4 py-2 rounded-xl bg-card border border-border ${getTimerColor()}`}>
            <Clock className="w-5 h-5" />
            <span className="text-lg font-bold tabular-nums">{formatTime(timeLeft)}</span>
          </div>
          
          <div className="text-right">
            <div className="text-lg font-bold text-primary">
              {currentQuestion + 1}/{quiz.questions.length}
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mb-8">
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question card */}
        <div className="bg-card rounded-3xl border border-border p-6 md:p-8 shadow-lg mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 rounded-full text-sm font-semibold text-primary mb-4">
            Question {currentQuestion + 1}
          </div>
          
          <h2 className="text-xl md:text-2xl font-bold text-card-foreground mb-8">
            {question.question}
          </h2>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleSelectAnswer(index)}
                disabled={showResult}
                className={getOptionClass(index)}
              >
                <div className="flex items-center gap-3">
                  <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-sm font-bold">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="flex-1">{option}</span>
                  {showResult && index === question.correctAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  )}
                  {showResult && selectedAnswer === index && index !== question.correctAnswer && (
                    <XCircle className="w-5 h-5 text-red-500" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-3">
          {!showResult ? (
            <Button 
              onClick={handleSubmitAnswer}
              disabled={selectedAnswer === null}
              className="flex-1"
              size="lg"
            >
              Check Answer
            </Button>
          ) : (
            <Button 
              onClick={handleNextQuestion}
              className="flex-1"
              size="lg"
            >
              {currentQuestion < quiz.questions.length - 1 ? "Next Question" : "See Results"}
            </Button>
          )}
        </div>

        {/* Feedback message */}
        {showResult && (
          <div className={`mt-4 rounded-2xl overflow-hidden ${
            selectedAnswer === question.correctAnswer 
              ? "bg-emerald-50 border border-emerald-200" 
              : "bg-gradient-to-br from-red-50 to-orange-50 border border-red-200"
          }`}>
            <div className={`p-4 text-center font-semibold ${
              selectedAnswer === question.correctAnswer 
                ? "text-emerald-700" 
                : "text-red-700"
            }`}>
              {selectedAnswer === question.correctAnswer ? (
                <span className="flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  🎉 Correct! Well done!
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <XCircle className="w-5 h-5" />
                  Not quite! The correct answer is: {question.options[question.correctAnswer]}
                </span>
              )}
            </div>
            
            {/* Explanation section - shown when wrong */}
            {selectedAnswer !== question.correctAnswer && question.explanation && (
              <div className="px-4 pb-4 pt-2 border-t border-red-200">
                <div className="bg-white/80 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl flex-shrink-0">💡</span>
                    <div>
                      <p className="font-bold text-gray-800 mb-1">Explanation:</p>
                      <p className="text-gray-700 text-sm leading-relaxed">{question.explanation}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
