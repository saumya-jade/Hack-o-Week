import { useEffect } from "react";
import { Link } from "react-router";
import { quizzes } from "@/data/quizzes";
import { Sparkles, GraduationCap, Trophy, Atom, FlaskConical } from "lucide-react";
import { Button } from "@/react-app/components/ui/button";

const subjectIcons: Record<string, React.ReactNode> = {
  Physics: <Atom className="w-6 h-6" />,
  Chemistry: <FlaskConical className="w-6 h-6" />,
  Mathematics: <Sparkles className="w-6 h-6" />,
};

const subjectColors: Record<string, string> = {
  Physics: "from-blue-500 to-indigo-600",
  Chemistry: "from-emerald-500 to-teal-600",
  Mathematics: "from-orange-400 to-rose-500",
};

export default function Home() {
  useEffect(() => {
    const link = document.createElement("link");
    link.href = "https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap";
    link.rel = "stylesheet";
    document.head.appendChild(link);
    return () => { document.head.removeChild(link); };
  }, []);

  return (
    <div 
      className="min-h-screen"
      style={{ fontFamily: "'Nunito', sans-serif" }}
    >
      {/* Decorative background */}
      <div className="fixed inset-0 -z-10 overflow-hidden colorful-bg">
        <div className="absolute top-10 left-1/4 w-32 h-32 bg-purple-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
        <div className="absolute top-1/2 right-10 w-24 h-24 bg-cyan-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
        <div className="absolute bottom-20 left-10 w-40 h-40 bg-pink-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
        <div className="absolute top-20 right-1/3 w-28 h-28 bg-amber-400/30 rounded-full blur-2xl floating-shape-slow pulse-glow" />
        <div className="absolute bottom-1/3 right-1/4 w-36 h-36 bg-green-400/30 rounded-full blur-2xl floating-shape pulse-glow" />
      </div>

      {/* Header */}
      <header className="pt-8 pb-6 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full">
              <GraduationCap className="w-5 h-5 text-primary" />
              <span className="text-sm font-semibold text-primary">Student Quiz Portal</span>
            </div>
            <Button variant="outline" asChild className="gap-2">
              <Link to="/leaderboard">
                <Trophy className="w-4 h-4" />
                Leaderboard
              </Link>
            </Button>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-foreground mb-3">
            Welcome to <span className="text-primary">QuizWhiz</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Master your 12th board exams with interactive quizzes! Pick a subject and test your knowledge.
          </p>
        </div>
      </header>

      {/* Quiz Cards */}
      <main className="px-4 pb-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
            <span className="w-8 h-1 bg-primary rounded-full" />
            Available Quizzes
          </h2>
          
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {quizzes.map((quiz) => (
              <Link
                key={quiz.id}
                to={`/quiz/${quiz.id}`}
                className="group block"
              >
                <div className="relative bg-card rounded-2xl border border-border p-6 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1 hover:border-primary/30">
                  {/* Subject badge */}
                  <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r ${subjectColors[quiz.subject]} text-white text-sm font-semibold mb-4`}>
                    {subjectIcons[quiz.subject]}
                    {quiz.subject}
                  </div>
                  
                  <h3 className="text-xl font-bold text-card-foreground mb-2 group-hover:text-primary transition-colors">
                    {quiz.title}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground mb-4">
                    {quiz.questions.length} questions • Multiple choice
                  </p>
                  
                  <div className="flex items-center text-primary font-semibold text-sm">
                    Start Quiz
                    <svg className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-6 text-center text-sm text-muted-foreground">
        <p>Made with ❤️ for learning</p>
      </footer>
    </div>
  );
}
