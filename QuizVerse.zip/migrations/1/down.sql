DROP INDEX idx_scores_score;
DROP INDEX idx_scores_quiz_id;
DROP TABLE scores;