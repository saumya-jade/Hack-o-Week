# Todo
- #1: Add teacher dashboard to create and manage quizzes
- #2: Add more 12th board subjects (Biology, English, etc.)
