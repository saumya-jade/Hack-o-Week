
CREATE TABLE registrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  participant_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  college TEXT NOT NULL,
  event TEXT NOT NULL,
  team_name TEXT,
  team_size INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_registrations_email ON registrations(email);
CREATE INDEX idx_registrations_event ON registrations(event);
