
DROP INDEX idx_registrations_event;
DROP INDEX idx_registrations_email;
DROP TABLE registrations;
