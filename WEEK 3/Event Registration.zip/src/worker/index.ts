import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { RegistrationInput } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

const registrationSchema = z.object({
  participant_name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  college: z.string().min(1, "College is required"),
  event: z.string().min(1, "Event is required"),
  team_name: z.string().optional(),
  team_size: z.number().min(1).max(3).optional(),
});

app.post("/api/register", zValidator("json", registrationSchema), async (c) => {
  const data = c.req.valid("json") as RegistrationInput;

  try {
    const result = await c.env.DB.prepare(
      `INSERT INTO registrations (participant_name, email, phone, college, event, team_name, team_size)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
      .bind(
        data.participant_name,
        data.email,
        data.phone,
        data.college,
        data.event,
        data.team_name || null,
        data.team_size || null
      )
      .run();

    return c.json({
      success: true,
      message: "Registration successful!",
      id: result.meta.last_row_id,
    });
  } catch (error) {
    console.error("Registration error:", error);
    return c.json(
      {
        success: false,
        message: "Failed to register. Please try again.",
      },
      500
    );
  }
});

app.get("/api/registrations", async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      "SELECT * FROM registrations ORDER BY created_at DESC"
    ).all();

    return c.json({ registrations: results });
  } catch (error) {
    console.error("Error fetching registrations:", error);
    return c.json(
      {
        success: false,
        message: "Failed to fetch registrations",
      },
      500
    );
  }
});

export default app;
