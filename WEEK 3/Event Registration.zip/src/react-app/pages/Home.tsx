import { useState } from "react";
import { Button } from "@/react-app/components/ui/button";
import { Input } from "@/react-app/components/ui/input";
import { Label } from "@/react-app/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/react-app/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/react-app/components/ui/card";
import { Calendar, Trophy, Users, Zap, Code, Gamepad2 } from "lucide-react";

const COLLEGES = [
  "SLS",
  "SCMS",
  "SIBM",
  "SSPD",
  "Other Colleges",
];

const EVENTS = [
  {
    id: "sit-novate",
    name: "SIT Novate2.0",
    description: "The ultimate 24-hour hackathon",
    prize: "₹70,000",
    teamSize: "3 members per team",
    fee: "₹400 per team",
    icon: Code,
    color: "from-purple-500 to-pink-500",
  },
  {
    id: "sitank",
    name: "SITank2.0",
    description: "Pitch your startup ideas",
    fee: "₹500",
    icon: Trophy,
    color: "from-blue-500 to-cyan-500",
  },
  {
    id: "robotics",
    name: "Robotics Workshop",
    description: "Learn and build robots",
    fee: "₹200",
    icon: Zap,
    color: "from-orange-500 to-red-500",
  },
  {
    id: "codesprint",
    name: "Codesprint2.0",
    description: "Think you can pull off the world's biggest bank heist and get away with it?",
    prize: "₹17,000+",
    teamSize: "2-3 bandits per team",
    fee: "₹200 per team (payable only after Round 1 shortlisting)",
    date: "27th February 2026",
    time: "10:00 AM",
    location: "Symbiosis Institute of Technology, Nagpur",
    details: [
      "This is not just competitive coding. Plan the heist, execute it, and escape the vault through technical, logical, and fun challenges open for all years. 🏦",
      "Round 1 is online and free for all. Shortlisted teams advance to the on-campus heist.",
      "Only ~30 teams make it inside",
      "PCs in the Safehouse",
      "Snacks provided",
      "Goodies throughout",
      "Certificates for all",
      "BELLA CIAO. LET'S GO. 🔥🏦💸"
    ],
    icon: Users,
    color: "from-green-500 to-emerald-500",
  },
  {
    id: "squid-game",
    name: "Squid Game",
    description: "Ultimate survival challenge",
    fee: "Free",
    icon: Gamepad2,
    color: "from-red-600 to-pink-600",
  },
];

export default function Home() {
  const [formData, setFormData] = useState({
    participant_name: "",
    email: "",
    phone: "",
    college: "",
    event: "",
    team_name: "",
    team_size: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const selectedEvent = EVENTS.find((e) => e.id === formData.event);
  const requiresTeam = ["sit-novate", "codesprint"].includes(formData.event);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");

    try {
      const payload = {
        ...formData,
        team_size: formData.team_size ? parseInt(formData.team_size) : undefined,
      };

      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.success) {
        setSubmitted(true);
        setFormData({
          participant_name: "",
          email: "",
          phone: "",
          college: "",
          event: "",
          team_name: "",
          team_size: "",
        });
      } else {
        setError(data.message || "Registration failed. Please try again.");
      }
    } catch (err) {
      setError("An error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
        <Card className="max-w-md w-full bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-4">
              <Trophy className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl text-white">Registration Successful!</CardTitle>
            <CardDescription className="text-gray-300">
              You're all set for Enthusia5.0. We'll send you event details via email.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => setSubmitted(false)}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              Register Another Participant
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 mb-4">
            Enthusia5.0
          </h1>
          <p className="text-xl text-gray-300">Register for the Ultimate College Tech Fest</p>
          <p className="text-lg text-gray-400 mt-2">26-28 February 2026</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Featured Events</h2>
            {EVENTS.map((event) => {
              const Icon = event.icon;
              return (
                <Card
                  key={event.id}
                  className="bg-white/5 backdrop-blur-lg border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  onClick={() => setFormData({ ...formData, event: event.id })}
                >
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${event.color} flex items-center justify-center flex-shrink-0`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-white text-xl mb-2">{event.name}</CardTitle>
                        <CardDescription className="text-gray-400">{event.description}</CardDescription>
                        <div className="flex flex-wrap gap-3 mt-3">
                          {event.prize && (
                            <span className="px-3 py-1 bg-yellow-500/20 text-yellow-300 rounded-full text-sm font-medium">
                              Prize: {event.prize}
                            </span>
                          )}
                          {event.teamSize && (
                            <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
                              {event.teamSize}
                            </span>
                          )}
                          {event.fee && (
                            <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-sm">
                              {event.fee}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              );
            })}
          </div>

          <div>
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 sticky top-4">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Registration Form</CardTitle>
                <CardDescription className="text-gray-300">Fill in your details to register</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-white">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.participant_name}
                      onChange={(e) => setFormData({ ...formData, participant_name: e.target.value })}
                      required
                      className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-white">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-white">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required
                      className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
                      placeholder="+91 1234567890"
                    />
                  </div>

                  <div>
                    <Label htmlFor="college" className="text-white">College</Label>
                    <Select
                      value={formData.college}
                      onValueChange={(value) => setFormData({ ...formData, college: value })}
                      required
                    >
                      <SelectTrigger className="bg-white/5 border-white/20 text-white">
                        <SelectValue placeholder="Select your college" />
                      </SelectTrigger>
                      <SelectContent>
                        {COLLEGES.map((college) => (
                          <SelectItem key={college} value={college}>
                            {college}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="event" className="text-white">Event</Label>
                    <Select
                      value={formData.event}
                      onValueChange={(value) => setFormData({ ...formData, event: value })}
                      required
                    >
                      <SelectTrigger className="bg-white/5 border-white/20 text-white">
                        <SelectValue placeholder="Select an event" />
                      </SelectTrigger>
                      <SelectContent>
                        {EVENTS.map((event) => (
                          <SelectItem key={event.id} value={event.id}>
                            {event.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {requiresTeam && (
                    <>
                      <div>
                        <Label htmlFor="team_name" className="text-white">Team Name</Label>
                        <Input
                          id="team_name"
                          value={formData.team_name}
                          onChange={(e) => setFormData({ ...formData, team_name: e.target.value })}
                          className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
                          placeholder="Enter your team name"
                        />
                      </div>

                      <div>
                        <Label htmlFor="team_size" className="text-white">Team Size</Label>
                        <Input
                          id="team_size"
                          type="number"
                          min="1"
                          max="3"
                          value={formData.team_size}
                          onChange={(e) => setFormData({ ...formData, team_size: e.target.value })}
                          className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
                          placeholder="Number of team members"
                        />
                      </div>
                    </>
                  )}

                  {error && (
                    <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200 text-sm">
                      {error}
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold py-6 text-lg"
                  >
                    {isSubmitting ? "Registering..." : "Register Now"}
                  </Button>

                  {selectedEvent && (
                    <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                      <div className="flex items-start gap-3">
                        <Calendar className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                        <div className="text-sm text-gray-300 space-y-2">
                          <p className="font-medium text-white mb-1">Selected: {selectedEvent.name}</p>
                          <p>{selectedEvent.description}</p>
                          {selectedEvent.date && (
                            <p className="text-white">📅 {selectedEvent.date}</p>
                          )}
                          {selectedEvent.time && (
                            <p className="text-white">⏰ {selectedEvent.time}</p>
                          )}
                          {selectedEvent.location && (
                            <p className="text-white">📍 {selectedEvent.location}</p>
                          )}
                          {selectedEvent.prize && <p className="mt-1">💰 Prize Pool: {selectedEvent.prize}</p>}
                          {selectedEvent.teamSize && <p>👥 {selectedEvent.teamSize}</p>}
                          {selectedEvent.fee && <p>🎟️ Registration Fee: {selectedEvent.fee}</p>}
                          {selectedEvent.details && (
                            <div className="mt-3 space-y-1.5 border-t border-blue-500/30 pt-3">
                              {selectedEvent.details.map((detail, idx) => (
                                <p key={idx} className="text-gray-300">{detail}</p>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
