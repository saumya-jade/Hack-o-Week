export interface Registration {
  id: number;
  participant_name: string;
  email: string;
  phone: string;
  college: string;
  event: string;
  team_name: string | null;
  team_size: number | null;
  created_at: string;
  updated_at: string;
}

export interface RegistrationInput {
  participant_name: string;
  email: string;
  phone: string;
  college: string;
  event: string;
  team_name?: string;
  team_size?: number;
}
