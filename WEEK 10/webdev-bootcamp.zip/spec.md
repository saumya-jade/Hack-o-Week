# WebDev Bootcamp Landing Page

## Current State
New project. Empty backend and frontend scaffolding.

## Requested Changes (Diff)

### Add
- Hero section with headline, subheadline, and enrollment CTA button
- Stats bar (graduates, job placement rate, course duration, projects built)
- Course curriculum/modules section listing topics covered
- Why Choose Us / Key Benefits section
- Instructors section with profiles
- Student testimonials section
- Enrollment/Contact form section (name, email, phone, message)
- Footer with links and contact info

### Modify
- N/A (new project)

### Remove
- N/A

## Implementation Plan
1. Backend: simple contact form submission handler storing inquiries
2. Frontend: full responsive single-page landing page with all sections above
3. Smooth scroll navigation, mobile hamburger menu
4. Form submission wired to backend
