import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Toaster } from "@/components/ui/sonner";
import { Textarea } from "@/components/ui/textarea";
import { useSubmitInquiry } from "@/hooks/useQueries";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Award,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Clock,
  Cloud,
  Code2,
  Cpu,
  Globe,
  Loader2,
  Menu,
  Quote,
  Server,
  TrendingUp,
  Users,
  X,
  Zap,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";

const queryClient = new QueryClient();

export default function AppWrapper() {
  return (
    <QueryClientProvider client={queryClient}>
      <App />
      <Toaster />
    </QueryClientProvider>
  );
}

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
}

const AVATAR_COLORS = [
  "oklch(0.52 0.18 264)",
  "oklch(0.60 0.18 294)",
  "oklch(0.56 0.18 324)",
];

const STUDENT_AVATARS = [
  { init: "AK", color: AVATAR_COLORS[0] },
  { init: "MJ", color: AVATAR_COLORS[1] },
  { init: "SR", color: AVATAR_COLORS[2] },
];

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const { mutate: submitInquiry, isPending, isSuccess } = useSubmitInquiry();

  const navLinks = [
    { label: "Curriculum", id: "curriculum" },
    { label: "Instructors", id: "instructors" },
    { label: "Success Stories", id: "testimonials" },
    { label: "Admissions", id: "admissions" },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitInquiry(formData, {
      onSuccess: () => {
        toast.success(
          "Application submitted! We'll be in touch within 24 hours.",
        );
        setFormData({ name: "", email: "", phone: "", message: "" });
      },
      onError: () => {
        toast.error("Something went wrong. Please try again.");
      },
    });
  };

  return (
    <div className="min-h-screen bg-background font-inter">
      {/* NAVBAR */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-border shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="flex items-center gap-2"
              data-ocid="nav.link"
            >
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <Code2 className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg text-foreground">
                Dev<span className="text-primary">Forge</span> Academy
              </span>
            </button>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  type="button"
                  onClick={() => scrollTo(link.id)}
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                  data-ocid="nav.link"
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* CTA + Hamburger */}
            <div className="flex items-center gap-3">
              <Button
                type="button"
                onClick={() => scrollTo("admissions")}
                className="hidden md:flex rounded-full bg-primary text-white font-semibold px-6 shadow-sm hover:bg-primary/90"
                data-ocid="nav.primary_button"
              >
                Apply Now
              </Button>
              <button
                type="button"
                className="md:hidden p-2 rounded-md text-foreground"
                onClick={() => setMobileOpen(!mobileOpen)}
                aria-label="Toggle menu"
                data-ocid="nav.toggle"
              >
                {mobileOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-border"
              data-ocid="nav.panel"
            >
              <div className="px-4 py-4 flex flex-col gap-3">
                {navLinks.map((link) => (
                  <button
                    type="button"
                    key={link.label}
                    onClick={() => {
                      scrollTo(link.id);
                      setMobileOpen(false);
                    }}
                    className="text-sm font-medium text-foreground py-2 border-b border-border last:border-0 text-left"
                    data-ocid="nav.link"
                  >
                    {link.label}
                  </button>
                ))}
                <Button
                  type="button"
                  onClick={() => {
                    scrollTo("admissions");
                    setMobileOpen(false);
                  }}
                  className="w-full rounded-full bg-primary text-white font-semibold mt-2"
                  data-ocid="nav.primary_button"
                >
                  Apply Now
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main>
        {/* HERO */}
        <section className="relative overflow-hidden bg-background">
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "linear-gradient(135deg, transparent 40%, oklch(0.92 0.06 220 / 0.35) 100%)",
            }}
          />
          <div
            className="absolute inset-0 pointer-events-none opacity-40"
            style={{
              backgroundImage:
                "radial-gradient(circle, oklch(0.7 0.04 240) 1px, transparent 1px)",
              backgroundSize: "32px 32px",
            }}
          />

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Left */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: "easeOut" }}
              >
                <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-1.5 text-sm font-semibold mb-6">
                  <Zap className="w-3.5 h-3.5" />
                  Next Cohort Starts April 14, 2026
                </div>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-foreground leading-tight tracking-tight mb-6">
                  Launch Your Tech Career:{" "}
                  <span className="text-primary">
                    Become a Full-Stack Developer
                  </span>{" "}
                  in 16 Weeks
                </h1>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl">
                  Join 2,500+ graduates who transformed their careers through
                  our intensive, project-based bootcamp. Learn from senior
                  engineers, build real products, and land your dream job.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button
                    size="lg"
                    type="button"
                    onClick={() => scrollTo("admissions")}
                    className="rounded-full bg-primary text-white font-semibold px-8 shadow-card hover:bg-primary/90 transition-all"
                    data-ocid="hero.primary_button"
                  >
                    Start Your Journey
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                  <Button
                    size="lg"
                    type="button"
                    variant="outline"
                    onClick={() => scrollTo("curriculum")}
                    className="rounded-full border-border font-semibold px-8 hover:bg-secondary transition-all"
                    data-ocid="hero.secondary_button"
                  >
                    View Curriculum
                  </Button>
                </div>
              </motion.div>

              {/* Right – Illustrated coding scene */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
                className="relative"
              >
                <div
                  className="relative rounded-2xl overflow-hidden shadow-card-lg"
                  style={{
                    background:
                      "linear-gradient(135deg, oklch(0.18 0.05 255), oklch(0.26 0.07 250))",
                    minHeight: "380px",
                  }}
                >
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-3 h-3 rounded-full bg-red-400" />
                      <div className="w-3 h-3 rounded-full bg-yellow-400" />
                      <div className="w-3 h-3 rounded-full bg-green-400" />
                      <span className="ml-3 text-xs text-white/50 font-mono">
                        app.tsx
                      </span>
                    </div>
                    <div className="font-mono text-sm space-y-1">
                      <div>
                        <span className="text-blue-300">import</span>{" "}
                        <span className="text-white">React</span>{" "}
                        <span className="text-blue-300">from</span>{" "}
                        <span className="text-green-300">'react'</span>
                      </div>
                      <div className="mt-2">
                        <span className="text-purple-300">function</span>{" "}
                        <span className="text-yellow-300">App</span>
                        <span className="text-white">() {"{"}</span>
                      </div>
                      <div className="ml-4">
                        <span className="text-blue-300">return</span>{" "}
                        <span className="text-white">(</span>
                      </div>
                      <div className="ml-8 text-orange-300">
                        &lt;div className=
                        <span className="text-green-300">"hero"</span>&gt;
                      </div>
                      <div className="ml-12 text-orange-300">
                        &lt;h1&gt;
                        <span className="text-white">Hello World!</span>
                        &lt;/h1&gt;
                      </div>
                      <div className="ml-8 text-orange-300">&lt;/div&gt;</div>
                      <div className="ml-4 text-white">)</div>
                      <div className="text-white">{"}"}</div>
                    </div>
                  </div>

                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl p-3">
                      <div className="flex -space-x-2">
                        {STUDENT_AVATARS.map((av) => (
                          <div
                            key={av.init}
                            className="w-8 h-8 rounded-full border-2 border-white/20 flex items-center justify-center text-xs font-bold text-white"
                            style={{ background: av.color }}
                          >
                            {av.init}
                          </div>
                        ))}
                      </div>
                      <div>
                        <p className="text-white text-xs font-semibold">
                          3 students coding live
                        </p>
                        <p className="text-white/60 text-xs">
                          Week 8 – React & APIs
                        </p>
                      </div>
                      <div className="ml-auto w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    </div>
                  </div>

                  <div className="absolute top-4 right-4 bg-accent/20 border border-accent/40 rounded-xl px-3 py-2">
                    <p className="text-accent text-xs font-bold">
                      95% Job Placement
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* STATS BAR */}
        <section className="bg-white border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="grid grid-cols-2 lg:grid-cols-4 gap-8"
            >
              {[
                {
                  icon: <Users className="w-7 h-7" />,
                  value: "2,500+",
                  label: "Graduates",
                },
                {
                  icon: <TrendingUp className="w-7 h-7" />,
                  value: "95%",
                  label: "Job Placement",
                },
                {
                  icon: <Award className="w-7 h-7" />,
                  value: "$85k",
                  label: "Avg Salary",
                },
                {
                  icon: <Clock className="w-7 h-7" />,
                  value: "16 Weeks",
                  label: "Duration",
                },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 text-primary mb-3">
                    {stat.icon}
                  </div>
                  <p className="text-2xl font-bold text-foreground">
                    {stat.value}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {stat.label}
                  </p>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* CURRICULUM */}
        <section id="curriculum" className="py-20 lg:py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-14"
            >
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Course Curriculum
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto text-base">
                A carefully crafted 16-week journey from zero to job-ready
                full-stack engineer.
              </p>
            </motion.div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: <BookOpen className="w-6 h-6" />,
                  title: "HTML & CSS Foundations",
                  weeks: "Weeks 1–3",
                  skills: [
                    "Semantic HTML5",
                    "Flexbox & Grid",
                    "Responsive Design",
                    "CSS Animations",
                  ],
                  progress: 30,
                },
                {
                  icon: <Code2 className="w-6 h-6" />,
                  title: "JavaScript & React",
                  weeks: "Weeks 4–8",
                  skills: [
                    "ES6+ Fundamentals",
                    "React 19 & Hooks",
                    "State Management",
                    "TypeScript",
                  ],
                  progress: 55,
                },
                {
                  icon: <Server className="w-6 h-6" />,
                  title: "Backend & APIs",
                  weeks: "Weeks 9–13",
                  skills: [
                    "Node.js & Express",
                    "REST & GraphQL",
                    "PostgreSQL",
                    "Auth & Security",
                  ],
                  progress: 75,
                },
                {
                  icon: <Cloud className="w-6 h-6" />,
                  title: "DevOps & Deployment",
                  weeks: "Weeks 14–16",
                  skills: [
                    "Docker & Containers",
                    "CI/CD Pipelines",
                    "AWS / Vercel",
                    "Monitoring",
                  ],
                  progress: 100,
                },
              ].map((track, i) => (
                <motion.div
                  key={track.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className="rounded-2xl p-6 shadow-card-lg flex flex-col"
                  style={{
                    background:
                      "linear-gradient(160deg, oklch(0.18 0.05 255), oklch(0.22 0.055 250))",
                  }}
                  data-ocid={`curriculum.item.${i + 1}`}
                >
                  <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-accent mb-4">
                    {track.icon}
                  </div>
                  <p className="text-xs font-semibold text-accent mb-1">
                    {track.weeks}
                  </p>
                  <h3 className="text-base font-bold text-white mb-4">
                    {track.title}
                  </h3>
                  <ul className="space-y-2 flex-1">
                    {track.skills.map((skill) => (
                      <li
                        key={skill}
                        className="flex items-center gap-2 text-sm text-white/70"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent flex-shrink-0" />
                        {skill}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-5">
                    <div className="flex justify-between text-xs text-white/50 mb-1.5">
                      <span>Track progress</span>
                      <span>{track.progress}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-accent"
                        style={{ width: `${track.progress}%` }}
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* INSTRUCTORS + TESTIMONIALS */}
        <section className="bg-white py-20 lg:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Instructors */}
              <div id="instructors">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="mb-8"
                >
                  <h2 className="text-3xl font-bold text-foreground mb-3">
                    Meet Your Instructors
                  </h2>
                  <p className="text-muted-foreground">
                    Learn from engineers who've shipped real products at top
                    companies.
                  </p>
                </motion.div>

                <div className="space-y-4">
                  {[
                    {
                      initials: "SR",
                      name: "Sarah Rodriguez",
                      role: "Senior Engineer at Google",
                      bio: "10+ years building large-scale React apps. Led the Workspace frontend team before joining DevForge to share what she wishes she'd learned earlier.",
                      hue: 264,
                    },
                    {
                      initials: "MK",
                      name: "Marcus Kim",
                      role: "Backend Lead at Stripe",
                      bio: "Distributed systems expert who designed payment infrastructure handling $50B/year. Passionate about teaching API design and system thinking.",
                      hue: 200,
                    },
                    {
                      initials: "AP",
                      name: "Aisha Patel",
                      role: "DevOps Architect at AWS",
                      bio: "Built cloud infrastructure for Fortune 500 companies. Specializes in making DevOps approachable for self-taught engineers.",
                      hue: 160,
                    },
                  ].map((instructor, i) => (
                    <motion.div
                      key={instructor.name}
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="flex gap-4 p-5 rounded-2xl border border-border bg-background shadow-xs hover:shadow-card transition-shadow"
                      data-ocid={`instructors.item.${i + 1}`}
                    >
                      <div
                        className="w-14 h-14 rounded-2xl flex-shrink-0 flex items-center justify-center text-white font-bold text-lg"
                        style={{
                          background: `oklch(0.52 0.18 ${instructor.hue})`,
                        }}
                      >
                        {instructor.initials}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">
                          {instructor.name}
                        </p>
                        <p className="text-sm text-primary font-medium mb-2">
                          {instructor.role}
                        </p>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {instructor.bio}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Testimonials */}
              <div id="testimonials">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="mb-8"
                >
                  <h2 className="text-3xl font-bold text-foreground mb-3">
                    Student Success Stories
                  </h2>
                  <p className="text-muted-foreground">
                    Real outcomes from graduates who took the leap.
                  </p>
                </motion.div>

                <div
                  className="rounded-2xl p-6 space-y-5"
                  style={{
                    background:
                      "linear-gradient(160deg, oklch(0.18 0.05 255), oklch(0.22 0.055 250))",
                  }}
                >
                  {[
                    {
                      initials: "JL",
                      name: "Jamie Lee",
                      company: "Now at Shopify",
                      quote:
                        "I went from teaching high school to building e-commerce features at Shopify — in under a year. DevForge's curriculum is brutally practical and the mentorship is unmatched.",
                      hue: 30,
                    },
                    {
                      initials: "TD",
                      name: "Tariq Dixon",
                      company: "Now at Airbnb",
                      quote:
                        "The career support team helped me land my first tech interview within 3 weeks of graduating. The mock interviews were invaluable. I got an offer that tripled my salary.",
                      hue: 200,
                    },
                    {
                      initials: "EN",
                      name: "Elena Novak",
                      company: "Co-founded her startup",
                      quote:
                        "Not just a job — I now have the confidence to build anything I can imagine. DevForge gave me the foundation to launch my own product six months after graduating.",
                      hue: 160,
                    },
                  ].map((t, i) => (
                    <motion.div
                      key={t.name}
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="bg-white/[0.08] rounded-xl p-4"
                      data-ocid={`testimonials.item.${i + 1}`}
                    >
                      <Quote className="w-5 h-5 text-accent mb-3" />
                      <p className="text-white/80 text-sm leading-relaxed mb-4">
                        {t.quote}
                      </p>
                      <div className="flex items-center gap-3">
                        <div
                          className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                          style={{ background: `oklch(0.55 0.16 ${t.hue})` }}
                        >
                          {t.initials}
                        </div>
                        <div>
                          <p className="text-white font-semibold text-sm">
                            {t.name}
                          </p>
                          <p className="text-accent text-xs">{t.company}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* KEY STATS & OUTCOMES */}
        <section className="bg-background py-20 lg:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-14"
            >
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Why DevForge Works
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Outcomes speak louder than promises.
              </p>
            </motion.div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: <Cpu className="w-8 h-8" />,
                  title: "Project-Based Learning",
                  desc: "Every week you ship working code. No theory without practice — you build 5 real projects employers can see on GitHub.",
                },
                {
                  icon: <Users className="w-8 h-8" />,
                  title: "1:10 Instructor Ratio",
                  desc: "Small cohorts mean every student gets personalized attention. You're never a number — you're a developer in training.",
                },
                {
                  icon: <Globe className="w-8 h-8" />,
                  title: "Hiring Network",
                  desc: "We've placed grads at Google, Stripe, Shopify, Airbnb, and 200+ more companies. Our hiring partners actively recruit here.",
                },
                {
                  icon: <TrendingUp className="w-8 h-8" />,
                  title: "Salary Negotiation",
                  desc: "Our career coaches have helped graduates negotiate an average of $12k above initial offers. We don't stop at the first offer.",
                },
                {
                  icon: <CheckCircle2 className="w-8 h-8" />,
                  title: "Job Guarantee",
                  desc: "If you don't get hired within 6 months of graduating, we refund your tuition — no questions asked. We bet on your success.",
                },
                {
                  icon: <Zap className="w-8 h-8" />,
                  title: "Lifetime Access",
                  desc: "Curriculum updates, alumni community, job boards, and office hours — yours for life, not just 16 weeks.",
                },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="bg-white rounded-2xl p-6 border border-border shadow-xs hover:shadow-card transition-shadow"
                  data-ocid={`outcomes.item.${i + 1}`}
                >
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary mb-4">
                    {item.icon}
                  </div>
                  <h3 className="font-bold text-foreground mb-2">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.desc}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ENROLLMENT FORM */}
        <section id="admissions" className="py-20 lg:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="text-4xl font-extrabold text-foreground leading-tight mb-5">
                  Ready to Build{" "}
                  <span className="text-primary">Your Future?</span>
                </h2>
                <p className="text-muted-foreground text-base leading-relaxed mb-8">
                  Seats are limited to 30 students per cohort to maintain
                  quality. Submit your application today — our admissions team
                  will reach out within 24 hours.
                </p>
                <div className="space-y-4">
                  {[
                    "No prior coding experience required",
                    "Flexible payment plans & ISAs available",
                    "Full-time & part-time tracks offered",
                    "Dedicated career coach from day one",
                  ].map((point) => (
                    <div key={point} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0" />
                      <span className="text-sm text-foreground">{point}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-background rounded-2xl border border-border shadow-card-lg p-8"
                data-ocid="admissions.panel"
              >
                {isSuccess ? (
                  <div
                    className="text-center py-8"
                    data-ocid="admissions.success_state"
                  >
                    <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle2 className="w-8 h-8 text-accent" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-2">
                      Application Received!
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      We'll be in touch within 24 hours to discuss next steps.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <h3 className="text-xl font-bold text-foreground mb-1">
                        Start Your Application
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        Tell us a bit about yourself.
                      </p>
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="name" className="text-sm font-medium">
                        Full Name
                      </Label>
                      <Input
                        id="name"
                        placeholder="Jane Smith"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData((p) => ({ ...p, name: e.target.value }))
                        }
                        required
                        className="rounded-xl"
                        data-ocid="admissions.input"
                      />
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="email" className="text-sm font-medium">
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="jane@example.com"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData((p) => ({ ...p, email: e.target.value }))
                        }
                        required
                        className="rounded-xl"
                        data-ocid="admissions.input"
                      />
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="phone" className="text-sm font-medium">
                        Phone Number
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData((p) => ({ ...p, phone: e.target.value }))
                        }
                        className="rounded-xl"
                        data-ocid="admissions.input"
                      />
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="message" className="text-sm font-medium">
                        Why do you want to join?
                      </Label>
                      <Textarea
                        id="message"
                        placeholder="Tell us about your background and goals..."
                        value={formData.message}
                        onChange={(e) =>
                          setFormData((p) => ({
                            ...p,
                            message: e.target.value,
                          }))
                        }
                        rows={3}
                        className="rounded-xl resize-none"
                        data-ocid="admissions.textarea"
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isPending}
                      className="w-full rounded-full bg-primary text-white font-semibold py-3 shadow-card hover:bg-primary/90 transition-all"
                      data-ocid="admissions.submit_button"
                    >
                      {isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        "Submit Application"
                      )}
                    </Button>
                    {isPending && (
                      <p
                        className="text-center text-xs text-muted-foreground"
                        data-ocid="admissions.loading_state"
                      >
                        Sending your application...
                      </p>
                    )}
                  </form>
                )}
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer
        className="py-14"
        style={{
          background:
            "linear-gradient(160deg, oklch(0.16 0.05 255), oklch(0.20 0.05 250))",
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
            <div className="lg:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                  <Code2 className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-lg text-white">
                  Dev<span className="text-accent">Forge</span> Academy
                </span>
              </div>
              <p className="text-sm text-white/50 leading-relaxed">
                Transforming careers through intensive, project-based full-stack
                web development education.
              </p>
            </div>

            <div>
              <p className="font-semibold text-white mb-4 text-sm">Program</p>
              <ul className="space-y-2">
                {[
                  { label: "Curriculum", id: "curriculum" },
                  { label: "Instructors", id: "instructors" },
                  { label: "Outcomes", id: "admissions" },
                  { label: "Admissions", id: "admissions" },
                  { label: "Schedule", id: "curriculum" },
                ].map((item) => (
                  <li key={item.label}>
                    <button
                      type="button"
                      onClick={() => scrollTo(item.id)}
                      className="text-sm text-white/50 hover:text-white transition-colors"
                      data-ocid="footer.link"
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="font-semibold text-white mb-4 text-sm">Company</p>
              <ul className="space-y-2">
                {["About Us", "Blog", "Press", "Careers", "Partners"].map(
                  (label) => (
                    <li key={label}>
                      <span className="text-sm text-white/50">{label}</span>
                    </li>
                  ),
                )}
              </ul>
            </div>

            <div>
              <p className="font-semibold text-white mb-4 text-sm">Support</p>
              <ul className="space-y-2">
                {["FAQ", "Student Portal", "Slack Community", "Contact Us"].map(
                  (label) => (
                    <li key={label}>
                      <span className="text-sm text-white/50">{label}</span>
                    </li>
                  ),
                )}
              </ul>
              <div className="mt-4">
                <p className="text-xs text-white/40">hello@devforge.academy</p>
                <p className="text-xs text-white/40">+1 (888) 383-4673</p>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-white/40">
              © {new Date().getFullYear()} DevForge Academy. All rights
              reserved.
            </p>
            <p className="text-xs text-white/40">
              Built with ❤️ using{" "}
              <a
                href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
                className="underline hover:text-white/70 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
