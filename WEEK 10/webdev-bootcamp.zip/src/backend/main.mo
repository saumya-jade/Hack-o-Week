import List "mo:core/List";
import Order "mo:core/Order";
import Text "mo:core/Text";

actor {
  type Submission = {
    name : Text;
    email : Text;
    phone : Text;
    message : Text;
  };

  module Submission {
    public func compare(submission1 : Submission, submission2 : Submission) : Order.Order {
      Text.compare(submission1.email, submission2.email);
    };
  };

  let submissions = List.empty<Submission>();

  public shared ({ caller }) func submitInquiry(name : Text, email : Text, phone : Text, message : Text) : async () {
    let submission : Submission = {
      name;
      email;
      phone;
      message;
    };
    submissions.add(submission);
  };

  public query ({ caller }) func getAllSubmissions() : async [Submission] {
    submissions.toArray().sort();
  };
};
