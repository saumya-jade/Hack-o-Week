# Design Brief: Task Manager Undo/Redo

**Purpose & Tone**: Minimal productivity app where undo/redo are first-class citizens. Clean, purposeful interface with zero distraction.

**Palette**:
| Token | Light | Dark |
|-------|-------|------|
| Background | `0.98 0 0` | `0.12 0 0` |
| Foreground | `0.18 0 0` | `0.96 0 0` |
| Primary (Teal) | `0.62 0.17 192` | `0.72 0.16 192` |
| Secondary (Gray) | `0.92 0.04 264` | `0.24 0.03 264` |
| Destructive (Red) | `0.55 0.22 25` | `0.65 0.19 22` |
| Muted | `0.89 0.02 0` | `0.2 0.02 0` |

**Typography**:
- Display: Bricolage Grotesque (modern, geometric, friendly)
- Body: General Sans (clean, productive, high legibility)
- Mono: Geist Mono (technical, intentional)

**Structural Zones**:
- Header: Soft shadow, border-b in subtle gray. Undo/redo buttons (left), title (center), new task button (right).
- Content: Light background with task cards. Cards have minimal shadows and 6px radius.
- Task Card: Checkbox (left), title + description (center), edit/delete (right). Hover state lifts card.

**Shape & Spacing**: 6px border-radius base. 1rem card padding. 0.75rem between elements. Breathing room over density.

**Interactions**:
- Button disabled state: `opacity-50`, cursor disabled
- Button active: teal background with subtle ring on focus
- Card hover: lift with shadow, slight scale
- Action: smooth 0.3s transitions on all interactive elements

**Signature Detail**: Undo/redo buttons prominently displayed in header. When disabled (empty stack), appear faded but never hidden—encourages user discovery and confidence in action reversibility.
