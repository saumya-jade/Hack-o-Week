import TasksLib "../lib/tasks";
import Types "../types/tasks";

mixin (state : TasksLib.State) {

  /// Create a new task with the given title and description
  public shared func addTask(title : Text, description : Text) : async Types.Task {
    TasksLib.addTask(state, title, description);
  };

  /// Edit the title and/or description of an existing task; returns null if not found
  public shared func editTask(id : Types.TaskId, title : Text, description : Text) : async ?Types.Task {
    TasksLib.editTask(state, id, title, description);
  };

  /// Toggle the completed flag of a task; returns null if not found
  public shared func toggleTask(id : Types.TaskId) : async ?Types.Task {
    TasksLib.toggleTask(state, id);
  };

  /// Delete a task by id; returns true if deleted, false if not found
  public shared func deleteTask(id : Types.TaskId) : async Bool {
    TasksLib.deleteTask(state, id);
  };

  /// List all tasks
  public query func listTasks() : async [Types.Task] {
    TasksLib.listTasks(state);
  };

  /// Undo the last action; returns true if there was something to undo
  public shared func undo() : async Bool {
    TasksLib.undo(state);
  };

  /// Redo the last undone action; returns true if there was something to redo
  public shared func redo() : async Bool {
    TasksLib.redo(state);
  };

  /// Return current undo and redo stack sizes
  public query func stackSizes() : async Types.StackSizes {
    TasksLib.stackSizes(state);
  };
};
