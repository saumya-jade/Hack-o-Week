import List "mo:core/List";
import Stack "mo:core/Stack";
import TasksLib "lib/tasks";
import TasksMixin "mixins/tasks-api";

actor {
  let tasksState : TasksLib.State = {
    tasks = List.empty();
    undoStack = Stack.empty();
    redoStack = Stack.empty();
    var nextId = 0;
  };

  include TasksMixin(tasksState);
};
