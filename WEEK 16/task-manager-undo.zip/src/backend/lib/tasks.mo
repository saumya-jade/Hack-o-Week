import List "mo:core/List";
import Stack "mo:core/Stack";
import Time "mo:core/Time";
import Types "../types/tasks";

module {
  public type State = {
    tasks : List.List<Types.TaskInternal>;
    undoStack : Stack.Stack<Types.Action>;
    redoStack : Stack.Stack<Types.Action>;
    var nextId : Nat;
  };

  /// Convert mutable internal task to immutable public Task
  public func toPublic(t : Types.TaskInternal) : Types.Task {
    {
      id = t.id;
      title = t.title;
      description = t.description;
      completed = t.completed;
      createdAt = t.createdAt;
      updatedAt = t.updatedAt;
    };
  };

  /// Create a new task and push an #addTask action onto the undo stack
  public func addTask(state : State, title : Text, description : Text) : Types.Task {
    let now = Time.now();
    let id = state.nextId;
    state.nextId += 1;

    let internal : Types.TaskInternal = {
      id;
      var title;
      var description;
      var completed = false;
      createdAt = now;
      var updatedAt = now;
    };
    state.tasks.add(internal);

    let pub = toPublic(internal);
    // New action clears the redo stack
    state.redoStack.clear();
    state.undoStack.push(#addTask { task = pub });
    pub;
  };

  /// Edit title/description of an existing task; push #editTask action
  public func editTask(state : State, id : Types.TaskId, title : Text, description : Text) : ?Types.Task {
    switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == id })) {
      case null null;
      case (?t) {
        let before = toPublic(t);
        t.title := title;
        t.description := description;
        t.updatedAt := Time.now();
        let after = toPublic(t);
        state.redoStack.clear();
        state.undoStack.push(#editTask { before });
        ?after;
      };
    };
  };

  /// Toggle completed flag; push #toggleTask action
  public func toggleTask(state : State, id : Types.TaskId) : ?Types.Task {
    switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == id })) {
      case null null;
      case (?t) {
        let before = toPublic(t);
        t.completed := not t.completed;
        t.updatedAt := Time.now();
        let after = toPublic(t);
        state.redoStack.clear();
        state.undoStack.push(#toggleTask { before });
        ?after;
      };
    };
  };

  /// Delete a task; push #deleteTask action
  public func deleteTask(state : State, id : Types.TaskId) : Bool {
    switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == id })) {
      case null false;
      case (?t) {
        let snapshot = toPublic(t);
        let filtered = state.tasks.filter(func(task : Types.TaskInternal) : Bool { task.id != id });
        state.tasks.clear();
        state.tasks.append(filtered);
        state.redoStack.clear();
        state.undoStack.push(#deleteTask { task = snapshot });
        true;
      };
    };
  };

  /// Return all tasks as an immutable array
  public func listTasks(state : State) : [Types.Task] {
    state.tasks.map<Types.TaskInternal, Types.Task>(toPublic).toArray();
  };

  /// Undo the last action: pops undo stack, reverses action, pushes to redo stack
  public func undo(state : State) : Bool {
    switch (state.undoStack.pop()) {
      case null false;
      case (?action) {
        switch (action) {
          case (#addTask { task }) {
            // Reverse of add → delete the task
            let filtered = state.tasks.filter(func(t : Types.TaskInternal) : Bool { t.id != task.id });
            state.tasks.clear();
            state.tasks.append(filtered);
            state.redoStack.push(#addTask { task });
          };
          case (#editTask { before }) {
            // Reverse of edit → capture current state as redo's "before", restore original before
            switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == before.id })) {
              case null {};
              case (?t) {
                let current = toPublic(t);
                t.title := before.title;
                t.description := before.description;
                t.updatedAt := before.updatedAt;
                // redo will restore current (the "after") by swapping with its stored "before"
                state.redoStack.push(#editTask { before = current });
              };
            };
          };
          case (#toggleTask { before }) {
            // Reverse of toggle → capture current state as redo's "before", restore original before
            switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == before.id })) {
              case null {};
              case (?t) {
                let current = toPublic(t);
                t.completed := before.completed;
                t.updatedAt := before.updatedAt;
                state.redoStack.push(#toggleTask { before = current });
              };
            };
          };
          case (#deleteTask { task }) {
            // Reverse of delete → re-insert the task
            let internal : Types.TaskInternal = {
              id = task.id;
              var title = task.title;
              var description = task.description;
              var completed = task.completed;
              createdAt = task.createdAt;
              var updatedAt = task.updatedAt;
            };
            state.tasks.add(internal);
            state.redoStack.push(#deleteTask { task });
          };
        };
        true;
      };
    };
  };

  /// Redo the last undone action: pops redo stack, re-applies, pushes to undo stack
  public func redo(state : State) : Bool {
    switch (state.redoStack.pop()) {
      case null false;
      case (?action) {
        switch (action) {
          case (#addTask { task }) {
            // Re-apply add → re-insert the task
            let internal : Types.TaskInternal = {
              id = task.id;
              var title = task.title;
              var description = task.description;
              var completed = task.completed;
              createdAt = task.createdAt;
              var updatedAt = task.updatedAt;
            };
            state.tasks.add(internal);
            state.undoStack.push(#addTask { task });
          };
          case (#editTask { before }) {
            // Re-apply edit — symmetric swap: capture current as new before, restore stored before
            switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == before.id })) {
              case null {};
              case (?t) {
                let newBefore = toPublic(t);
                t.title := before.title;
                t.description := before.description;
                t.updatedAt := before.updatedAt;
                state.undoStack.push(#editTask { before = newBefore });
              };
            };
          };
          case (#toggleTask { before }) {
            // Re-apply toggle — symmetric swap
            switch (state.tasks.find(func(t : Types.TaskInternal) : Bool { t.id == before.id })) {
              case null {};
              case (?t) {
                let newBefore = toPublic(t);
                t.completed := before.completed;
                t.updatedAt := before.updatedAt;
                state.undoStack.push(#toggleTask { before = newBefore });
              };
            };
          };
          case (#deleteTask { task }) {
            // Re-apply delete → remove the task again
            let filtered = state.tasks.filter(func(t : Types.TaskInternal) : Bool { t.id != task.id });
            state.tasks.clear();
            state.tasks.append(filtered);
            state.undoStack.push(#deleteTask { task });
          };
        };
        true;
      };
    };
  };

  /// Return current undo/redo stack sizes
  public func stackSizes(state : State) : Types.StackSizes {
    {
      undoSize = state.undoStack.size();
      redoSize = state.redoStack.size();
    };
  };
};
