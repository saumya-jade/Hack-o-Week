module {
  public type TaskId = Nat;
  public type Timestamp = Int;
};
