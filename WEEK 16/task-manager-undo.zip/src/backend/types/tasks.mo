import Common "common";

module {
  public type TaskId = Common.TaskId;
  public type Timestamp = Common.Timestamp;

  /// Public (shared) representation of a task — no mutable fields
  public type Task = {
    id : TaskId;
    title : Text;
    description : Text;
    completed : Bool;
    createdAt : Timestamp;
    updatedAt : Timestamp;
  };

  /// Internal mutable representation stored in the List
  public type TaskInternal = {
    id : TaskId;
    var title : Text;
    var description : Text;
    var completed : Bool;
    createdAt : Timestamp;
    var updatedAt : Timestamp;
  };

  /// Every mutating action is captured as one of these variants
  public type Action = {
    /// Created task snapshot (used to undo by deleting it again)
    #addTask : { task : Task };
    /// Before-state of the task fields (used to undo edits / toggle)
    #editTask : { before : Task };
    /// Before-state of the completed flag (used to undo toggle)
    #toggleTask : { before : Task };
    /// Snapshot of the deleted task (used to undo by re-inserting)
    #deleteTask : { task : Task };
  };

  /// Sizes returned to the frontend so it can enable/disable undo-redo buttons
  public type StackSizes = {
    undoSize : Nat;
    redoSize : Nat;
  };
};
