export interface Task {
  id: bigint;
  title: string;
  description: string;
  completed: boolean;
  createdAt: bigint;
  updatedAt: bigint;
}

export interface StackSizes {
  undoSize: bigint;
  redoSize: bigint;
}

export enum ActionType {
  ADD_TASK = "ADD_TASK",
  EDIT_TASK = "EDIT_TASK",
  TOGGLE_TASK = "TOGGLE_TASK",
  DELETE_TASK = "DELETE_TASK",
}

export type TaskId = bigint;
