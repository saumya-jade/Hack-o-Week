import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Task {
    id: TaskId;
    title: string;
    createdAt: Timestamp;
    completed: boolean;
    description: string;
    updatedAt: Timestamp;
}
export type Timestamp = bigint;
export interface StackSizes {
    undoSize: bigint;
    redoSize: bigint;
}
export type TaskId = bigint;
export interface backendInterface {
    addTask(title: string, description: string): Promise<Task>;
    deleteTask(id: TaskId): Promise<boolean>;
    editTask(id: TaskId, title: string, description: string): Promise<Task | null>;
    listTasks(): Promise<Array<Task>>;
    redo(): Promise<boolean>;
    stackSizes(): Promise<StackSizes>;
    toggleTask(id: TaskId): Promise<Task | null>;
    undo(): Promise<boolean>;
}
