import TaskListPage from "@/pages/TaskListPage";
import {
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";

const rootRoute = createRootRoute();

const taskListRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: TaskListPage,
});

const routeTree = rootRoute.addChildren([taskListRoute]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
