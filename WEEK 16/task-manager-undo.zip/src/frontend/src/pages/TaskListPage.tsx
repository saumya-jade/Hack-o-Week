import { Layout } from "@/components/Layout";
import { TaskCard } from "@/components/TaskCard";
import { TaskDialog } from "@/components/TaskDialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useListTasks } from "@/hooks/use-tasks";
import type { Task } from "@/types/task";
import { ClipboardList, Plus } from "lucide-react";
import { useState } from "react";

// Staggered skeleton rows for loading state
const SKELETON_IDS = ["sk1", "sk2", "sk3", "sk4", "sk5", "sk6"] as const;

export default function TaskListPage() {
  const { data: tasks, isLoading } = useListTasks();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  function handleNewTask() {
    setEditingTask(null);
    setDialogOpen(true);
  }

  function handleEditTask(task: Task) {
    setEditingTask(task);
    setDialogOpen(true);
  }

  const activeTasks = tasks?.filter((t) => !t.completed) ?? [];
  const completedTasks = tasks?.filter((t) => t.completed) ?? [];
  const totalCount = tasks?.length ?? 0;
  const completedCount = completedTasks.length;

  return (
    <Layout onNewTask={handleNewTask}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Section header */}
        <div className="flex items-end justify-between mb-6 gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-foreground">
              My Tasks
            </h2>
            {!isLoading && totalCount > 0 && (
              <p className="text-sm text-muted-foreground mt-1">
                <span className="font-medium text-primary">
                  {completedCount}
                </span>
                {" of "}
                <span className="font-medium">{totalCount}</span>
                {" completed"}
              </p>
            )}
          </div>

          {/* Progress bar (shown when tasks exist) */}
          {!isLoading && totalCount > 0 && (
            <div className="hidden sm:flex items-center gap-3 flex-shrink-0">
              <div
                className="w-32 h-2 bg-muted rounded-full overflow-hidden"
                aria-label="Task completion progress"
              >
                <div
                  className="h-full bg-primary rounded-full transition-smooth"
                  style={{
                    width: `${Math.round((completedCount / totalCount) * 100)}%`,
                  }}
                />
              </div>
              <span className="text-xs font-medium text-muted-foreground tabular-nums">
                {Math.round((completedCount / totalCount) * 100)}%
              </span>
            </div>
          )}
        </div>

        {/* Loading skeletons */}
        {isLoading ? (
          <div
            data-ocid="tasks.loading_state"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {SKELETON_IDS.map((id, i) => (
              <Skeleton
                key={id}
                data-ocid={`tasks.loading_state.${i + 1}`}
                className="h-44 rounded-xl"
              />
            ))}
          </div>
        ) : totalCount === 0 ? (
          /* Empty state */
          <div
            data-ocid="tasks.empty_state"
            className="flex flex-col items-center justify-center py-28 gap-5 text-center"
          >
            <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center shadow-sm">
              <ClipboardList
                size={36}
                className="text-primary"
                strokeWidth={1.8}
              />
            </div>
            <div className="max-w-xs">
              <p className="font-display text-xl font-bold text-foreground">
                No tasks yet
              </p>
              <p className="text-muted-foreground text-sm mt-2 leading-relaxed">
                Create your first task to start organizing your work and
                tracking progress.
              </p>
            </div>
            <Button
              data-ocid="tasks.empty_state_cta_button"
              onClick={handleNewTask}
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold gap-2 mt-1"
            >
              <Plus size={16} strokeWidth={2.5} />
              New Task
            </Button>
          </div>
        ) : (
          /* Task grid — active first, completed below */
          <div className="space-y-8">
            {activeTasks.length > 0 && (
              <section aria-label="Active tasks">
                <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  Active · {activeTasks.length}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeTasks.map((task, i) => (
                    <TaskCard
                      key={String(task.id)}
                      task={task}
                      index={i + 1}
                      onEdit={() => handleEditTask(task)}
                    />
                  ))}
                </div>
              </section>
            )}

            {completedTasks.length > 0 && (
              <section aria-label="Completed tasks">
                <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  Completed · {completedTasks.length}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {completedTasks.map((task, i) => (
                    <TaskCard
                      key={String(task.id)}
                      task={task}
                      index={activeTasks.length + i + 1}
                      onEdit={() => handleEditTask(task)}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>

      <TaskDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editingTask={editingTask}
      />
    </Layout>
  );
}
