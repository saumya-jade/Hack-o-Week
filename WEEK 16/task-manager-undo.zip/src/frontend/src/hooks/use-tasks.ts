import { createActor } from "@/backend";
import type { StackSizes, Task } from "@/types/task";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

// Helper to get a typed actor instance
type BackendActor = {
  listTasks: () => Promise<Task[]>;
  stackSizes: () => Promise<StackSizes>;
  addTask: (title: string, description: string) => Promise<Task>;
  editTask: (
    id: bigint,
    title: string,
    description: string,
  ) => Promise<Task | null | undefined>;
  toggleTask: (id: bigint) => Promise<Task | null | undefined>;
  deleteTask: (id: bigint) => Promise<boolean>;
  undo: () => Promise<boolean>;
  redo: () => Promise<boolean>;
};

function useBackendActor() {
  return useActor(createActor as Parameters<typeof useActor>[0]);
}

// ── Queries ──────────────────────────────────────────────────────────────────

export function useListTasks() {
  const { actor, isFetching } = useBackendActor();
  return useQuery<Task[]>({
    queryKey: ["tasks"],
    queryFn: async () => {
      if (!actor) return [];
      return (actor as unknown as BackendActor).listTasks();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useStackSizes() {
  const { actor, isFetching } = useBackendActor();
  return useQuery<StackSizes>({
    queryKey: ["stackSizes"],
    queryFn: async () => {
      if (!actor) return { undoSize: 0n, redoSize: 0n };
      return (actor as unknown as BackendActor).stackSizes();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 1500,
  });
}

// ── Mutations ─────────────────────────────────────────────────────────────────

export function useAddTask() {
  const { actor } = useBackendActor();
  const qc = useQueryClient();
  return useMutation<Task, Error, { title: string; description: string }>({
    mutationFn: async ({ title, description }) => {
      if (!actor) throw new Error("Actor not ready");
      return (actor as unknown as BackendActor).addTask(title, description);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["stackSizes"] });
    },
  });
}

export function useEditTask() {
  const { actor } = useBackendActor();
  const qc = useQueryClient();
  return useMutation<
    Task | null,
    Error,
    { id: bigint; title: string; description: string }
  >({
    mutationFn: async ({ id, title, description }) => {
      if (!actor) throw new Error("Actor not ready");
      const res = await (actor as unknown as BackendActor).editTask(
        id,
        title,
        description,
      );
      return res ?? null;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["stackSizes"] });
    },
  });
}

export function useToggleTask() {
  const { actor } = useBackendActor();
  const qc = useQueryClient();
  return useMutation<Task | null, Error, bigint>({
    mutationFn: async (id) => {
      if (!actor) throw new Error("Actor not ready");
      const res = await (actor as unknown as BackendActor).toggleTask(id);
      return res ?? null;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["stackSizes"] });
    },
  });
}

export function useDeleteTask() {
  const { actor } = useBackendActor();
  const qc = useQueryClient();
  return useMutation<boolean, Error, bigint>({
    mutationFn: async (id) => {
      if (!actor) throw new Error("Actor not ready");
      return (actor as unknown as BackendActor).deleteTask(id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["stackSizes"] });
    },
  });
}

export function useUndo() {
  const { actor } = useBackendActor();
  const qc = useQueryClient();
  return useMutation<boolean, Error, void>({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return (actor as unknown as BackendActor).undo();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["stackSizes"] });
    },
  });
}

export function useRedo() {
  const { actor } = useBackendActor();
  const qc = useQueryClient();
  return useMutation<boolean, Error, void>({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return (actor as unknown as BackendActor).redo();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["stackSizes"] });
    },
  });
}
