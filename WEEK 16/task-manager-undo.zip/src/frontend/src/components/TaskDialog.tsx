import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAddTask, useEditTask } from "@/hooks/use-tasks";
import type { Task } from "@/types/task";
import { useEffect, useRef, useState } from "react";

interface TaskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingTask: Task | null;
}

export function TaskDialog({
  open,
  onOpenChange,
  editingTask,
}: TaskDialogProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [titleError, setTitleError] = useState("");
  const titleRef = useRef<HTMLInputElement>(null);

  const addMutation = useAddTask();
  const editMutation = useEditTask();

  const isEditing = editingTask !== null;
  const isPending = addMutation.isPending || editMutation.isPending;

  useEffect(() => {
    if (open) {
      setTitle(editingTask?.title ?? "");
      setDescription(editingTask?.description ?? "");
      setTitleError("");
      // Focus after transition
      setTimeout(() => titleRef.current?.focus(), 50);
    }
  }, [open, editingTask]);

  function validate(): boolean {
    if (!title.trim()) {
      setTitleError("Title is required");
      titleRef.current?.focus();
      return false;
    }
    setTitleError("");
    return true;
  }

  function handleSubmit() {
    if (!validate()) return;

    if (isEditing && editingTask) {
      editMutation.mutate(
        {
          id: editingTask.id,
          title: title.trim(),
          description: description.trim(),
        },
        { onSuccess: () => onOpenChange(false) },
      );
    } else {
      addMutation.mutate(
        { title: title.trim(), description: description.trim() },
        { onSuccess: () => onOpenChange(false) },
      );
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (
      e.key === "Enter" &&
      !e.shiftKey &&
      e.target instanceof HTMLInputElement
    ) {
      e.preventDefault();
      handleSubmit();
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        data-ocid={isEditing ? "edit_task.dialog" : "add_task.dialog"}
        className="sm:max-w-[28rem]"
        onKeyDown={handleKeyDown}
      >
        <DialogHeader className="pb-1">
          <DialogTitle className="font-display text-xl font-bold">
            {isEditing ? "Edit Task" : "New Task"}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-5 py-2">
          {/* Title field */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="task-title" className="text-sm font-semibold">
              Title{" "}
              <span className="text-destructive" aria-hidden="true">
                *
              </span>
            </Label>
            <Input
              ref={titleRef}
              id="task-title"
              data-ocid={isEditing ? "edit_task.input" : "add_task.input"}
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (titleError && e.target.value.trim()) setTitleError("");
              }}
              onBlur={() => {
                if (!title.trim()) setTitleError("Title is required");
              }}
              placeholder="What needs to be done?"
              className={
                titleError
                  ? "border-destructive focus-visible:ring-destructive"
                  : ""
              }
              aria-invalid={!!titleError}
              aria-describedby={titleError ? "task-title-error" : undefined}
            />
            {titleError && (
              <p
                id="task-title-error"
                data-ocid={
                  isEditing
                    ? "edit_task.title_field_error"
                    : "add_task.title_field_error"
                }
                className="text-xs text-destructive flex items-center gap-1"
                role="alert"
              >
                <span aria-hidden="true">⚠</span> {titleError}
              </p>
            )}
          </div>

          {/* Description field */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="task-description" className="text-sm font-semibold">
              Description{" "}
              <span className="text-muted-foreground font-normal">
                (optional)
              </span>
            </Label>
            <Textarea
              id="task-description"
              data-ocid={
                isEditing
                  ? "edit_task.description_textarea"
                  : "add_task.description_textarea"
              }
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details, notes, or context…"
              rows={4}
              className="resize-none leading-relaxed"
            />
          </div>
        </div>

        <DialogFooter className="gap-2 pt-2">
          <Button
            type="button"
            variant="outline"
            data-ocid={
              isEditing ? "edit_task.cancel_button" : "add_task.cancel_button"
            }
            onClick={() => onOpenChange(false)}
            disabled={isPending}
            className="font-medium"
          >
            Cancel
          </Button>
          <Button
            type="button"
            data-ocid={
              isEditing ? "edit_task.save_button" : "add_task.submit_button"
            }
            onClick={handleSubmit}
            disabled={isPending}
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold min-w-[6rem]"
          >
            {isPending
              ? isEditing
                ? "Saving…"
                : "Adding…"
              : isEditing
                ? "Save Changes"
                : "Add Task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
