import { useDeleteTask, useToggleTask } from "@/hooks/use-tasks";
import type { Task } from "@/types/task";
import { AlertCircle, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";

interface TaskCardProps {
  task: Task;
  index: number;
  onEdit: () => void;
}

export function TaskCard({ task, index, onEdit }: TaskCardProps) {
  const toggleMutation = useToggleTask();
  const deleteMutation = useDeleteTask();
  const [confirmDelete, setConfirmDelete] = useState(false);

  function handleDelete() {
    if (!confirmDelete) {
      setConfirmDelete(true);
      // Auto-cancel confirm after 3s
      setTimeout(() => setConfirmDelete(false), 3000);
      return;
    }
    deleteMutation.mutate(task.id, {
      onSettled: () => setConfirmDelete(false),
    });
  }

  return (
    <article
      data-ocid={`tasks.item.${index}`}
      className={`task-card group flex flex-col gap-3 min-h-[10rem] ${
        task.completed ? "task-card-completed" : ""
      }`}
    >
      {/* Top: checkbox + title + description */}
      <div className="flex items-start gap-3 flex-1">
        {/* Teal checkbox */}
        <button
          type="button"
          data-ocid={`tasks.checkbox.${index}`}
          onClick={() => toggleMutation.mutate(task.id)}
          disabled={toggleMutation.isPending}
          className={`mt-0.5 flex-shrink-0 w-6 h-6 rounded flex items-center justify-center border-2 transition-smooth focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 ${
            task.completed
              ? "bg-primary border-primary text-primary-foreground shadow-sm"
              : "border-border hover:border-primary hover:bg-primary/5"
          } disabled:cursor-wait`}
          aria-label={task.completed ? "Mark incomplete" : "Mark complete"}
          aria-pressed={task.completed}
        >
          {task.completed && (
            <svg
              width="10"
              height="8"
              viewBox="0 0 10 8"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M1 4L3.5 6.5L9 1"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
        </button>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3
            className={`font-display font-semibold text-base leading-snug break-words ${
              task.completed
                ? "line-through text-muted-foreground"
                : "text-foreground"
            }`}
          >
            {task.title}
          </h3>
          {task.description ? (
            <p className="text-sm text-muted-foreground mt-1.5 line-clamp-3 break-words leading-relaxed">
              {task.description}
            </p>
          ) : (
            <p className="text-sm text-muted-foreground/50 mt-1.5 italic">
              No description
            </p>
          )}
        </div>
      </div>

      {/* Footer: actions */}
      <div className="flex items-center justify-between pt-2 border-t border-border/50">
        {/* Status badge */}
        <span
          className={`text-xs font-medium px-2 py-0.5 rounded-full ${
            task.completed
              ? "bg-primary/15 text-primary"
              : "bg-muted text-muted-foreground"
          }`}
        >
          {task.completed ? "Done" : "Active"}
        </span>

        {/* Action buttons */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            data-ocid={`tasks.edit_button.${index}`}
            onClick={onEdit}
            className="p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-smooth focus-visible:ring-2 focus-visible:ring-ring"
            aria-label="Edit task"
          >
            <Pencil size={14} strokeWidth={2} />
          </button>

          {confirmDelete ? (
            <button
              type="button"
              data-ocid={`tasks.delete_button.${index}`}
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="flex items-center gap-1 px-2 py-1 rounded-md bg-destructive/10 text-destructive text-xs font-medium hover:bg-destructive/20 transition-smooth disabled:opacity-50"
              aria-label="Confirm delete"
            >
              <AlertCircle size={12} strokeWidth={2} />
              <span>Confirm</span>
            </button>
          ) : (
            <button
              type="button"
              data-ocid={`tasks.delete_button.${index}`}
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-smooth disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-ring"
              aria-label="Delete task"
            >
              <Trash2 size={14} strokeWidth={2} />
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
