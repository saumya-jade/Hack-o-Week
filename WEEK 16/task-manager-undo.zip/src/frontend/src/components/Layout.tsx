import { Button } from "@/components/ui/button";
import { useRedo, useStackSizes, useUndo } from "@/hooks/use-tasks";
import { CheckSquare, Plus, Redo2, Undo2 } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
  onNewTask?: () => void;
}

export function Layout({ children, onNewTask }: LayoutProps) {
  const { data: sizes } = useStackSizes();
  const undoMutation = useUndo();
  const redoMutation = useRedo();

  const canUndo = sizes ? sizes.undoSize > 0n : false;
  const canRedo = sizes ? sizes.redoSize > 0n : false;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center gap-3">
          {/* Undo / Redo buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              data-ocid="header.undo_button"
              onClick={() => undoMutation.mutate()}
              disabled={!canUndo || undoMutation.isPending}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-primary text-primary font-medium text-sm transition-smooth hover:bg-primary/10 disabled:opacity-40 disabled:cursor-not-allowed"
              aria-label="Undo last action"
            >
              <Undo2 size={15} strokeWidth={2.2} />
              <span>Undo</span>
            </button>
            <button
              type="button"
              data-ocid="header.redo_button"
              onClick={() => redoMutation.mutate()}
              disabled={!canRedo || redoMutation.isPending}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-primary text-primary font-medium text-sm transition-smooth hover:bg-primary/10 disabled:opacity-40 disabled:cursor-not-allowed"
              aria-label="Redo last undone action"
            >
              <Redo2 size={15} strokeWidth={2.2} />
              <span>Redo</span>
            </button>
          </div>

          {/* Title — centered */}
          <div className="flex-1 flex justify-center">
            <div className="flex items-center gap-2">
              <CheckSquare
                size={22}
                className="text-primary"
                strokeWidth={2.5}
              />
              <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">
                TaskFlow
              </h1>
            </div>
          </div>

          {/* New Task CTA */}
          <Button
            data-ocid="header.new_task_button"
            onClick={onNewTask}
            className="flex items-center gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-4 py-2 rounded-lg transition-smooth shadow-sm"
          >
            <Plus size={16} strokeWidth={2.5} />
            <span>New Task</span>
          </Button>
        </div>
      </header>

      {/* Page content */}
      <main className="flex-1 bg-background">{children}</main>

      {/* Footer */}
      <footer className="bg-muted/40 border-t border-border py-4 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()}. Built with love using{" "}
        <a
          href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
