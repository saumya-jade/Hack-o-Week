import type { backendInterface, Task } from "../backend";

const sampleTasks: Task[] = [
  {
    id: BigInt(1),
    title: "Finalize Q3 Marketing Report",
    description: "Draft content for slides, review metrics with analysis team",
    completed: false,
    createdAt: BigInt(Date.now() * 1000000),
    updatedAt: BigInt(Date.now() * 1000000),
  },
  {
    id: BigInt(2),
    title: "Team Sync: Sprint Planning",
    description: "Discuss progress on features, address blockers and define next steps",
    completed: false,
    createdAt: BigInt(Date.now() * 1000000),
    updatedAt: BigInt(Date.now() * 1000000),
  },
  {
    id: BigInt(3),
    title: "Design System Review",
    description: "Review updated color tokens and component library changes",
    completed: true,
    createdAt: BigInt(Date.now() * 1000000),
    updatedAt: BigInt(Date.now() * 1000000),
  },
  {
    id: BigInt(4),
    title: "Write Unit Tests for Auth Module",
    description: "Cover edge cases for login, logout, and session expiry flows",
    completed: false,
    createdAt: BigInt(Date.now() * 1000000),
    updatedAt: BigInt(Date.now() * 1000000),
  },
];

let tasks = [...sampleTasks];
let nextId = BigInt(5);
const undoStack: (() => void)[] = [];
const redoStack: (() => void)[] = [];

export const mockBackend: backendInterface = {
  listTasks: async () => [...tasks],

  addTask: async (title: string, description: string) => {
    const newTask: Task = {
      id: nextId++,
      title,
      description,
      completed: false,
      createdAt: BigInt(Date.now() * 1000000),
      updatedAt: BigInt(Date.now() * 1000000),
    };
    const prevTasks = [...tasks];
    tasks = [...tasks, newTask];
    undoStack.push(() => { tasks = prevTasks; });
    redoStack.length = 0;
    return newTask;
  },

  deleteTask: async (id) => {
    const prevTasks = [...tasks];
    const idx = tasks.findIndex((t) => t.id === id);
    if (idx === -1) return false;
    tasks = tasks.filter((t) => t.id !== id);
    undoStack.push(() => { tasks = prevTasks; });
    redoStack.length = 0;
    return true;
  },

  editTask: async (id, title, description) => {
    const prevTasks = [...tasks];
    const idx = tasks.findIndex((t) => t.id === id);
    if (idx === -1) return null;
    const updated = { ...tasks[idx], title, description, updatedAt: BigInt(Date.now() * 1000000) };
    tasks = tasks.map((t) => (t.id === id ? updated : t));
    undoStack.push(() => { tasks = prevTasks; });
    redoStack.length = 0;
    return updated;
  },

  toggleTask: async (id) => {
    const prevTasks = [...tasks];
    const idx = tasks.findIndex((t) => t.id === id);
    if (idx === -1) return null;
    const toggled = { ...tasks[idx], completed: !tasks[idx].completed, updatedAt: BigInt(Date.now() * 1000000) };
    tasks = tasks.map((t) => (t.id === id ? toggled : t));
    undoStack.push(() => { tasks = prevTasks; });
    redoStack.length = 0;
    return toggled;
  },

  undo: async () => {
    if (undoStack.length === 0) return false;
    const action = undoStack.pop()!;
    const prevTasks = [...tasks];
    action();
    redoStack.push(() => { tasks = prevTasks; });
    return true;
  },

  redo: async () => {
    if (redoStack.length === 0) return false;
    const action = redoStack.pop()!;
    const prevTasks = [...tasks];
    action();
    undoStack.push(() => { tasks = prevTasks; });
    return true;
  },

  stackSizes: async () => ({
    undoSize: BigInt(undoStack.length),
    redoSize: BigInt(redoStack.length),
  }),
};
