import { Camera, ChevronLeft, ChevronRight, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useState } from "react";

const photos = [
  {
    id: 1,
    src: "/assets/generated/northern-lights-finland.dim_1200x800.jpg",
    title: "Northern Lights",
    category: "Finland",
  },
  {
    id: 2,
    src: "/assets/generated/mount-fuji-spring-japan.dim_1200x800.jpg",
    title: "Mount Fuji in Spring",
    category: "Japan",
  },
  {
    id: 3,
    src: "/assets/generated/gulmarg-serenity-escape.dim_1200x800.jpg",
    title: "Gulmarg Serenity",
    category: "Kashmir",
  },
  {
    id: 4,
    src: "/assets/generated/lavender-fields-japan.dim_1200x800.jpg",
    title: "Lavender Fields",
    category: "Japan",
  },
  {
    id: 5,
    src: "/assets/generated/chandratal-lake-ladakh.dim_1200x800.jpg",
    title: "Chandratal Lake",
    category: "Leh Ladakh",
  },
  {
    id: 6,
    src: "/assets/generated/santorini-greece-sunset.dim_1200x800.jpg",
    title: "Santorini Sunset",
    category: "Greece",
  },
  {
    id: 7,
    src: "/assets/generated/patagonia-torres-del-paine.dim_1200x800.jpg",
    title: "Torres del Paine",
    category: "Patagonia",
  },
  {
    id: 8,
    src: "/assets/generated/bali-rice-terraces-sunrise.dim_1200x800.jpg",
    title: "Bali Rice Terraces",
    category: "Indonesia",
  },
  {
    id: 9,
    src: "/assets/generated/iceland-black-sand-beach.dim_1200x800.jpg",
    title: "Black Sand Beach",
    category: "Iceland",
  },
];

export default function App() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [direction, setDirection] = useState(0);

  const openLightbox = (index: number) => {
    setActiveIndex(index);
    document.body.classList.add("lightbox-open");
  };

  const closeLightbox = useCallback(() => {
    setActiveIndex(null);
    document.body.classList.remove("lightbox-open");
  }, []);

  const goNext = useCallback(() => {
    if (activeIndex === null) return;
    setDirection(1);
    setActiveIndex((prev) => (prev === null ? 0 : (prev + 1) % photos.length));
  }, [activeIndex]);

  const goPrev = useCallback(() => {
    if (activeIndex === null) return;
    setDirection(-1);
    setActiveIndex((prev) =>
      prev === null ? 0 : (prev - 1 + photos.length) % photos.length,
    );
  }, [activeIndex]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (activeIndex === null) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowRight") goNext();
      if (e.key === "ArrowLeft") goPrev();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [activeIndex, closeLightbox, goNext, goPrev]);

  const activePhoto = activeIndex !== null ? photos[activeIndex] : null;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Header */}
      <header className="relative border-b border-border/50 px-6 py-10 md:py-16 text-center overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 60% 50% at 50% 0%, oklch(0.72 0.12 55 / 0.12) 0%, transparent 70%)",
          }}
        />
        <div className="relative z-10">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Camera className="w-5 h-5 text-primary" strokeWidth={1.5} />
            <span className="text-xs tracking-[0.35em] uppercase text-muted-foreground font-sans">
              Portfolio
            </span>
          </div>
          <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-light tracking-tight text-foreground mb-3">
            Alex Morgan
          </h1>
          <p className="font-display italic text-lg md:text-2xl text-primary/90 font-light">
            Photography
          </p>
          <p className="mt-4 text-sm text-muted-foreground tracking-wide font-sans max-w-xs mx-auto">
            Capturing the world's hidden moments — light, shadow, and silence.
          </p>
        </div>
      </header>

      {/* Gallery Grid */}
      <main className="flex-1 px-4 md:px-8 lg:px-12 py-10 md:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 max-w-6xl mx-auto">
          {photos.map((photo, index) => (
            <motion.div
              key={photo.id}
              data-ocid={`gallery.item.${index + 1}`}
              className="relative group aspect-[4/3] overflow-hidden cursor-pointer bg-muted"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.5,
                delay: index * 0.07,
                ease: "easeOut",
              }}
              onClick={() => openLightbox(index)}
            >
              <img
                src={photo.src}
                alt={photo.title}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-3 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-400">
                <span className="block text-[10px] uppercase tracking-[0.2em] text-primary font-sans mb-1">
                  {photo.category}
                </span>
                <span className="block font-display text-white text-lg font-light">
                  {photo.title}
                </span>
              </div>
              <div className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="text-white/80 text-[10px] font-sans">
                  {index + 1}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 px-6 py-8 text-center">
        <p className="text-xs text-muted-foreground font-sans tracking-wide">
          © {new Date().getFullYear()} Alex Morgan Photography.{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-primary transition-colors"
          >
            Built with ♥ using caffeine.ai
          </a>
        </p>
      </footer>

      {/* Lightbox */}
      <AnimatePresence>
        {activePhoto && (
          <motion.div
            data-ocid="lightbox.dialog"
            className="fixed inset-0 z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="absolute inset-0 bg-black/95 backdrop-blur-md"
              onClick={closeLightbox}
            />

            <div className="relative z-10 flex flex-col items-center w-full max-w-5xl px-4">
              <div className="w-full flex items-center justify-between mb-4">
                <div>
                  <span className="text-[10px] tracking-[0.25em] uppercase text-primary font-sans">
                    {activePhoto.category}
                  </span>
                  <h2 className="font-display text-xl md:text-3xl text-white font-light">
                    {activePhoto.title}
                  </h2>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-muted-foreground text-xs font-sans">
                    {(activeIndex ?? 0) + 1} / {photos.length}
                  </span>
                  <button
                    type="button"
                    data-ocid="lightbox.close_button"
                    onClick={closeLightbox}
                    className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center text-white/70 hover:text-white hover:border-white/50 hover:bg-white/10 transition-all"
                    aria-label="Close lightbox"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="relative w-full overflow-hidden">
                <AnimatePresence mode="wait" custom={direction}>
                  <motion.img
                    key={activePhoto.id}
                    src={activePhoto.src}
                    alt={activePhoto.title}
                    className="w-full max-h-[65vh] object-contain"
                    custom={direction}
                    initial={{ opacity: 0, x: direction * 60 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: direction * -60 }}
                    transition={{ duration: 0.35, ease: "easeInOut" }}
                  />
                </AnimatePresence>
              </div>

              <div className="flex items-center gap-6 mt-5">
                <button
                  type="button"
                  data-ocid="lightbox.pagination_prev"
                  onClick={goPrev}
                  className="flex items-center gap-2 px-5 py-2.5 border border-white/20 rounded-full text-white/70 hover:text-white hover:border-white/50 hover:bg-white/10 transition-all text-sm font-sans"
                  aria-label="Previous photo"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Prev
                </button>

                <div className="flex gap-1.5">
                  {photos.map((photo, i) => (
                    <button
                      type="button"
                      key={photo.id}
                      onClick={() => {
                        setDirection(i > (activeIndex ?? 0) ? 1 : -1);
                        setActiveIndex(i);
                      }}
                      className={`w-1.5 h-1.5 rounded-full transition-all duration-200 ${
                        i === activeIndex
                          ? "bg-primary w-4"
                          : "bg-white/30 hover:bg-white/60"
                      }`}
                      aria-label={`Go to photo ${i + 1}`}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  data-ocid="lightbox.pagination_next"
                  onClick={goNext}
                  className="flex items-center gap-2 px-5 py-2.5 border border-white/20 rounded-full text-white/70 hover:text-white hover:border-white/50 hover:bg-white/10 transition-all text-sm font-sans"
                  aria-label="Next photo"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
