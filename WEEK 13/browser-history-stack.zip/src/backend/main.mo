import Array "mo:core/Array";
import Time "mo:core/Time";
import Principal "mo:core/Principal";

actor {

  type HistoryEntry = {
    url : Text;
    timestamp : Int;
  };

  type UserStateStable = {
    principal : Principal;
    backStack : [Text];
    forwardStack : [Text];
    fullHistory : [HistoryEntry];
  };

  var stableStates : [UserStateStable] = [];

  func findIndex(caller : Principal) : ?Nat {
    var i = 0;
    for (s in stableStates.vals()) {
      if (s.principal == caller) return ?i;
      i += 1;
    };
    null
  };

  func getOrCreate(caller : Principal) : UserStateStable {
    switch (findIndex(caller)) {
      case (?i) stableStates[i];
      case null {
        let state : UserStateStable = {
          principal = caller;
          backStack = ["about:blank"];
          forwardStack = [];
          fullHistory = [{ url = "about:blank"; timestamp = Time.now() }];
        };
        stableStates := stableStates.concat([state]);
        state
      };
    }
  };

  func setState(caller : Principal, state : UserStateStable) {
    switch (findIndex(caller)) {
      case (?i) {
        stableStates := Array.tabulate(stableStates.size(), func(j : Nat) : UserStateStable {
          if (j == i) state else stableStates[j]
        });
      };
      case null {
        stableStates := stableStates.concat([state]);
      };
    }
  };

  public shared ({ caller }) func push(url : Text) : async Text {
    let s = getOrCreate(caller);
    setState(caller, {
      principal = caller;
      backStack = s.backStack.concat([url]);
      forwardStack = [];
      fullHistory = s.fullHistory.concat([{ url; timestamp = Time.now() }]);
    });
    url
  };

  public shared ({ caller }) func back() : async ?Text {
    let s = getOrCreate(caller);
    let len = s.backStack.size();
    if (len <= 1) return null;
    let current = s.backStack[len - 1];
    let newBack = Array.tabulate(len - 1, func(i : Nat) : Text { s.backStack[i] });
    setState(caller, {
      principal = caller;
      backStack = newBack;
      forwardStack = [current].concat(s.forwardStack);
      fullHistory = s.fullHistory;
    });
    ?newBack[newBack.size() - 1]
  };

  public shared ({ caller }) func forward() : async ?Text {
    let s = getOrCreate(caller);
    let fwdLen = s.forwardStack.size();
    if (fwdLen == 0) return null;
    let next = s.forwardStack[0];
    let newFwd = Array.tabulate(fwdLen - 1 : Nat, func(i : Nat) : Text { s.forwardStack[i + 1] });
    setState(caller, {
      principal = caller;
      backStack = s.backStack.concat([next]);
      forwardStack = newFwd;
      fullHistory = s.fullHistory;
    });
    ?next
  };

  public shared ({ caller }) func peek() : async Text {
    let s = getOrCreate(caller);
    let len = s.backStack.size();
    if (len == 0) return "about:blank";
    s.backStack[len - 1]
  };

  public shared ({ caller }) func getBackStack() : async [Text] {
    getOrCreate(caller).backStack
  };

  public shared ({ caller }) func getForwardStack() : async [Text] {
    getOrCreate(caller).forwardStack
  };

  public shared ({ caller }) func getFullHistory() : async [HistoryEntry] {
    getOrCreate(caller).fullHistory
  };

  public shared ({ caller }) func clearHistory() : async () {
    setState(caller, {
      principal = caller;
      backStack = ["about:blank"];
      forwardStack = [];
      fullHistory = [{ url = "about:blank"; timestamp = Time.now() }];
    });
  };
};
