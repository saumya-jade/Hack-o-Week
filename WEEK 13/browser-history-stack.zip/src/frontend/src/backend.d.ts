import { ActorSubclass } from "@dfinity/agent";

export type HistoryEntry = {
  url: string;
  timestamp: bigint;
};

export interface BackendActor {
  push(url: string): Promise<string>;
  back(): Promise<[string] | []>;
  forward(): Promise<[string] | []>;
  peek(): Promise<string>;
  getBackStack(): Promise<string[]>;
  getForwardStack(): Promise<string[]>;
  getFullHistory(): Promise<HistoryEntry[]>;
  clearHistory(): Promise<void>;
}

declare const backend: BackendActor;
export default backend;
