import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Toaster } from "@/components/ui/sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BarChart2,
  BookMarked,
  ChevronLeft,
  ChevronRight,
  Clock,
  Download,
  ExternalLink,
  Globe,
  LayoutDashboard,
  RefreshCw,
  Search,
  Tags,
  Trash2,
  User,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import type { BackendActor, HistoryEntry } from "./backend.d";
import { useActor } from "./hooks/useActor";

function tsToDate(ts: bigint): Date {
  return new Date(Number(ts / 1_000_000n));
}

function formatDateTime(date: Date): string {
  return date.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

const SKELETON_KEYS = ["sk-a", "sk-b", "sk-c", "sk-d", "sk-e"];

export default function App() {
  const { actor: rawActor, isFetching: actorLoading } = useActor();
  const actor = rawActor as unknown as BackendActor | null;
  const queryClient = useQueryClient();
  const [urlInput, setUrlInput] = useState("");
  const [inputFocused, setInputFocused] = useState(false);

  const isReady = !!actor && !actorLoading;

  // ── Queries ──────────────────────────────────────────────
  const { data: currentUrl = "about:blank", isLoading: peekLoading } = useQuery(
    {
      queryKey: ["peek"],
      queryFn: () => actor!.peek(),
      enabled: isReady,
    },
  );

  const { data: backStack = [], isLoading: backLoading } = useQuery({
    queryKey: ["backStack"],
    queryFn: () => actor!.getBackStack(),
    enabled: isReady,
  });

  const { data: forwardStack = [], isLoading: fwdLoading } = useQuery({
    queryKey: ["forwardStack"],
    queryFn: () => actor!.getForwardStack(),
    enabled: isReady,
  });

  const { data: fullHistory = [], isLoading: histLoading } = useQuery({
    queryKey: ["fullHistory"],
    queryFn: () => actor!.getFullHistory(),
    enabled: isReady,
  });

  const isLoading = peekLoading || backLoading || fwdLoading || histLoading;

  const invalidateAll = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ["peek"] });
    queryClient.invalidateQueries({ queryKey: ["backStack"] });
    queryClient.invalidateQueries({ queryKey: ["forwardStack"] });
    queryClient.invalidateQueries({ queryKey: ["fullHistory"] });
  }, [queryClient]);

  useEffect(() => {
    if (!inputFocused) {
      setUrlInput(currentUrl);
    }
  }, [currentUrl, inputFocused]);

  // ── Mutations ─────────────────────────────────────────────
  const { mutate: visitUrl, isPending: visiting } = useMutation({
    mutationFn: (url: string) => actor!.push(url),
    onSuccess: () => {
      invalidateAll();
      toast.success("Visited URL");
    },
    onError: () => toast.error("Failed to visit URL"),
  });

  const { mutate: goBack, isPending: goingBack } = useMutation({
    mutationFn: () => actor!.back(),
    onSuccess: (res: [string] | []) => {
      invalidateAll();
      if (res.length === 0) toast.info("No pages to go back to");
    },
    onError: () => toast.error("Failed to go back"),
  });

  const { mutate: goForward, isPending: goingFwd } = useMutation({
    mutationFn: () => actor!.forward(),
    onSuccess: (res: [string] | []) => {
      invalidateAll();
      if (res.length === 0) toast.info("No pages to go forward to");
    },
    onError: () => toast.error("Failed to go forward"),
  });

  const { mutate: clearHistory, isPending: clearing } = useMutation({
    mutationFn: () => actor!.clearHistory(),
    onSuccess: () => {
      invalidateAll();
      toast.success("History cleared");
    },
    onError: () => toast.error("Failed to clear history"),
  });

  const isBusy = visiting || goingBack || goingFwd || clearing;

  const handleVisit = () => {
    const trimmed = urlInput.trim();
    if (!trimmed) return;
    let url = trimmed;
    if (
      !url.startsWith("http://") &&
      !url.startsWith("https://") &&
      !url.startsWith("about:")
    ) {
      url = `https://${url}`;
    }
    visitUrl(url);
  };

  const canGoBack = backStack.length > 1;
  const canGoFwd = forwardStack.length > 0;

  const sortedHistory = [...fullHistory].sort((a, b) =>
    Number(b.timestamp - a.timestamp),
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Toaster />

      {/* ── Sidebar ── */}
      <aside className="w-[220px] flex-shrink-0 bg-card border-r border-border flex flex-col shadow-xs">
        <div className="px-5 py-5 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center">
              <BookMarked className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-[17px] font-bold tracking-tight text-foreground">
              Histry
            </span>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {[
            { icon: LayoutDashboard, label: "Dashboard", active: true },
            { icon: Clock, label: "Sessions", active: false },
            { icon: Search, label: "Search", active: false },
            { icon: Tags, label: "Tags", active: false },
            { icon: Download, label: "Export", active: false },
          ].map(({ icon: Icon, label, active }) => (
            <button
              type="button"
              key={label}
              data-ocid={`sidebar.${label.toLowerCase()}.link`}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                active
                  ? "bg-secondary text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-border">
          <p className="text-[11px] text-muted-foreground">
            © {new Date().getFullYear()}{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              className="hover:text-primary transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-12 bg-card border-b border-border flex items-center justify-between px-6 flex-shrink-0">
          <nav className="flex items-center gap-1">
            {["Dashboard", "Analytics", "Settings"].map((item) => (
              <button
                type="button"
                key={item}
                data-ocid={`header.${item.toLowerCase()}.link`}
                className={`px-3 py-1.5 rounded-md text-[13px] font-medium transition-colors ${
                  item === "Dashboard"
                    ? "text-primary bg-secondary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                {item}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            {actorLoading && (
              <span className="text-xs text-muted-foreground animate-pulse">
                Connecting...
              </span>
            )}
            <div className="w-8 h-8 rounded-full bg-secondary border-2 border-border flex items-center justify-center">
              <User className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-5 space-y-4">
          {/* URL Bar */}
          <div className="bg-card rounded-xl border border-border shadow-card p-3 flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 rounded-lg"
              disabled={!canGoBack || isBusy || !isReady}
              onClick={() => goBack()}
              data-ocid="nav.back.button"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 rounded-lg"
              disabled={!canGoFwd || isBusy || !isReady}
              onClick={() => goForward()}
              data-ocid="nav.forward.button"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>

            <div className="flex-1 relative">
              <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                data-ocid="nav.url.input"
                className="pl-8 h-8 text-sm rounded-full bg-muted border-0 focus-visible:ring-1"
                placeholder="Enter a URL to visit..."
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleVisit()}
                onFocus={() => setInputFocused(true)}
                onBlur={() => setInputFocused(false)}
                disabled={isBusy || !isReady}
              />
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 rounded-lg"
              onClick={invalidateAll}
              disabled={isBusy || !isReady}
              data-ocid="nav.refresh.button"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isBusy ? "animate-spin" : ""}`}
              />
            </Button>

            <Button
              className="h-8 px-4 text-sm font-semibold bg-accent text-accent-foreground hover:bg-accent/90 rounded-lg"
              onClick={handleVisit}
              disabled={isBusy || !isReady || !urlInput.trim()}
              data-ocid="nav.visit.button"
            >
              Visit
            </Button>
          </div>

          {/* Two-column */}
          <div className="grid grid-cols-2 gap-4">
            {/* Left: Stack Visualization */}
            <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden">
              <div className="px-4 pt-4 pb-3 border-b border-border">
                <p className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                  History Stack Visualization
                </p>
              </div>
              <ScrollArea className="h-[280px]">
                <div className="p-3 space-y-1">
                  {isLoading ? (
                    SKELETON_KEYS.slice(0, 4).map((k) => (
                      <Skeleton key={k} className="h-12 w-full rounded-lg" />
                    ))
                  ) : backStack.length === 0 ? (
                    <div
                      data-ocid="backstack.empty_state"
                      className="flex flex-col items-center justify-center h-32 text-muted-foreground text-sm"
                    >
                      <Clock className="w-8 h-8 mb-2 opacity-30" />
                      <p>No history yet</p>
                    </div>
                  ) : (
                    <>
                      <p className="text-[10px] font-bold tracking-widest uppercase text-muted-foreground px-1 pb-1">
                        Back Stack
                      </p>
                      <AnimatePresence>
                        {[...backStack].reverse().map((url, idx) => {
                          const isCurrent = idx === 0;
                          return (
                            <motion.div
                              key={`back-${url}`}
                              initial={{ opacity: 0, y: -4 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -4 }}
                              transition={{ duration: 0.15, delay: idx * 0.03 }}
                              data-ocid={`backstack.item.${idx + 1}`}
                              className={`rounded-lg px-3 py-2.5 ${
                                isCurrent
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted/50 text-foreground hover:bg-muted"
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <Globe className="w-3 h-3 flex-shrink-0 opacity-70" />
                                <span className="text-[12px] font-medium truncate flex-1">
                                  {url}
                                </span>
                                {isCurrent && (
                                  <Badge className="text-[10px] px-1.5 py-0 bg-white/20 text-white border-0 font-medium">
                                    current
                                  </Badge>
                                )}
                              </div>
                            </motion.div>
                          );
                        })}
                      </AnimatePresence>

                      {forwardStack.length > 0 && (
                        <>
                          <p className="text-[10px] font-bold tracking-widest uppercase text-muted-foreground px-1 pt-3 pb-1">
                            Forward Stack
                          </p>
                          <AnimatePresence>
                            {forwardStack.map((url, idx) => (
                              <motion.div
                                key={`fwd-${url}`}
                                initial={{ opacity: 0, y: 4 }}
                                animate={{ opacity: 1, y: 0 }}
                                data-ocid={`forwardstack.item.${idx + 1}`}
                                className="rounded-lg px-3 py-2.5 bg-muted/30 border border-dashed border-border text-muted-foreground"
                              >
                                <div className="flex items-center gap-2">
                                  <Globe className="w-3 h-3 flex-shrink-0 opacity-50" />
                                  <span className="text-[12px] truncate flex-1">
                                    {url}
                                  </span>
                                </div>
                              </motion.div>
                            ))}
                          </AnimatePresence>
                        </>
                      )}
                    </>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* Right: Current Page View */}
            <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden">
              <div className="px-4 pt-4 pb-3 border-b border-border">
                <p className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                  Current Page View
                </p>
              </div>
              <div className="p-4 h-[280px] flex flex-col gap-4">
                {peekLoading ? (
                  <>
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-20 w-full" />
                  </>
                ) : (
                  <>
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Globe className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground mb-1">
                          Current URL
                        </p>
                        <p className="text-sm font-semibold text-foreground break-all leading-snug">
                          {currentUrl}
                        </p>
                      </div>
                    </div>

                    <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                          Stack Depth
                        </span>
                        <Badge
                          variant="secondary"
                          className="text-xs font-semibold"
                        >
                          {backStack.length}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                          Forward Available
                        </span>
                        <Badge
                          variant="secondary"
                          className="text-xs font-semibold"
                        >
                          {forwardStack.length}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                          Total Visited
                        </span>
                        <Badge
                          variant="secondary"
                          className="text-xs font-semibold"
                        >
                          {fullHistory.length}
                        </Badge>
                      </div>
                    </div>

                    <div className="mt-auto flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 text-xs h-8"
                        disabled={!canGoBack || isBusy || !isReady}
                        onClick={() => goBack()}
                        data-ocid="currentpage.back.button"
                      >
                        <ChevronLeft className="w-3 h-3 mr-1" /> Back
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 text-xs h-8"
                        disabled={!canGoFwd || isBusy || !isReady}
                        onClick={() => goForward()}
                        data-ocid="currentpage.forward.button"
                      >
                        Forward <ChevronRight className="w-3 h-3 ml-1" />
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* History Log */}
          <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden">
            <div className="px-4 pt-4 pb-3 border-b border-border flex items-center justify-between">
              <p className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                History Log
              </p>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {fullHistory.length} entries
                </Badge>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 text-xs text-destructive border-destructive/30 hover:bg-destructive/5"
                  onClick={() => clearHistory()}
                  disabled={isBusy || !isReady || fullHistory.length === 0}
                  data-ocid="history.clear.button"
                >
                  <Trash2 className="w-3 h-3 mr-1" /> Clear History
                </Button>
              </div>
            </div>

            {histLoading ? (
              <div className="p-4 space-y-2" data-ocid="history.loading_state">
                {SKELETON_KEYS.map((k) => (
                  <Skeleton key={k} className="h-10 w-full" />
                ))}
              </div>
            ) : sortedHistory.length === 0 ? (
              <div
                data-ocid="history.empty_state"
                className="flex flex-col items-center justify-center h-32 text-muted-foreground text-sm"
              >
                <BarChart2 className="w-8 h-8 mb-2 opacity-30" />
                <p>No history recorded yet. Visit a URL to start.</p>
              </div>
            ) : (
              <ScrollArea className="h-64">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="text-[11px] font-bold tracking-widest uppercase w-10">
                        #
                      </TableHead>
                      <TableHead className="text-[11px] font-bold tracking-widest uppercase">
                        URL
                      </TableHead>
                      <TableHead className="text-[11px] font-bold tracking-widest uppercase">
                        Visited
                      </TableHead>
                      <TableHead className="text-[11px] font-bold tracking-widest uppercase w-20">
                        Actions
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {sortedHistory.map((entry: HistoryEntry, idx: number) => (
                        <motion.tr
                          key={String(entry.timestamp)}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: idx * 0.02 }}
                          data-ocid={`history.item.${idx + 1}`}
                          className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                        >
                          <TableCell className="text-[12px] text-muted-foreground font-mono">
                            {idx + 1}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Globe className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                              <span className="text-[13px] font-medium truncate max-w-[280px]">
                                {entry.url}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-[12px] text-muted-foreground">
                            {formatDateTime(tsToDate(entry.timestamp))}
                          </TableCell>
                          <TableCell>
                            <button
                              type="button"
                              className="inline-flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 font-medium transition-colors"
                              onClick={() => visitUrl(entry.url)}
                              data-ocid={`history.visit.button.${idx + 1}`}
                            >
                              <ExternalLink className="w-3 h-3" /> Visit
                            </button>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </ScrollArea>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
