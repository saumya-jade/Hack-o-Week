import Time "mo:core/Time";
import Map "mo:core/Map";
import Iter "mo:core/Iter";
import Runtime "mo:core/Runtime";

actor {
  type Task = {
    id : Nat;
    content : Text;
    completed : Bool;
    created : Time.Time;
  };

  let tasks = Map.empty<Nat, Task>();
  var nextId = 0;

  public shared ({ caller }) func addTask(content : Text) : async () {
    let task : Task = {
      id = nextId;
      content;
      completed = false;
      created = Time.now();
    };
    tasks.add(nextId, task);
    nextId += 1;
  };

  public query ({ caller }) func getAllTasks() : async [Task] {
    tasks.values().toArray();
  };

  public shared ({ caller }) func toggleTask(id : Nat) : async () {
    switch (tasks.get(id)) {
      case (null) { Runtime.trap("Task not found") };
      case (?task) {
        let updatedTask = { task with completed = not task.completed };
        tasks.add(id, updatedTask);
      };
    };
  };

  public shared ({ caller }) func deleteTask(id : Nat) : async () {
    if (not tasks.containsKey(id)) { Runtime.trap("Task not found") };
    tasks.remove(id);
  };

  public shared ({ caller }) func clearCompletedTasks() : async () {
    for ((id, task) in tasks.entries()) {
      if (task.completed) {
        tasks.remove(id);
      };
    };
  };
};
