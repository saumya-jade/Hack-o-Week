import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Task {
    id: bigint;
    created: Time;
    content: string;
    completed: boolean;
}
export type Time = bigint;
export interface backendInterface {
    addTask(content: string): Promise<void>;
    clearCompletedTasks(): Promise<void>;
    deleteTask(id: bigint): Promise<void>;
    getAllTasks(): Promise<Array<Task>>;
    toggleTask(id: bigint): Promise<void>;
}
