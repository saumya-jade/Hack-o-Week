import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Toaster } from "@/components/ui/sonner";
import { Plus, Trash2 } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import {
  useAddTask,
  useDeleteTask,
  useGetAllTasks,
  useToggleTask,
} from "./hooks/useQueries";

const GOAL_KEYS = ["goal-1", "goal-2", "goal-3"];
const PRIORITY_KEYS = ["priority-1", "priority-2", "priority-3"];

// Section header with colored bar and dashes
function SectionHeader({
  title,
  color,
  icon,
  badge,
}: {
  title: string;
  color: "blue" | "orange";
  icon?: string;
  badge?: string;
}) {
  const bg = color === "blue" ? "bg-planner-blue" : "bg-planner-orange";
  return (
    <div className={`${bg} flex items-center gap-2 px-3 py-1.5 rounded-t-md`}>
      <div className="flex-1 h-px bg-white/40" />
      <div className="flex items-center gap-1.5 shrink-0">
        {icon && <span className="text-sm">{icon}</span>}
        <span className="text-white text-xs font-bold tracking-wide uppercase">
          {title}
        </span>
        {badge && (
          <span className="bg-white/20 text-white text-[10px] px-1.5 py-0.5 rounded-full font-semibold">
            {badge}
          </span>
        )}
      </div>
      <div className="flex-1 h-px bg-white/40" />
    </div>
  );
}

const TIME_SLOTS = [
  "8:00 AM",
  "9:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "1:00 PM",
  "2:00 PM",
  "3:00 PM",
];

export default function App() {
  const today = new Date();
  const defaultDate = today.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
  const defaultDay = today.toLocaleDateString("en-US", { weekday: "long" });

  const [date, setDate] = useState(defaultDate);
  const [day, setDay] = useState(defaultDay);
  const [goals, setGoals] = useState([
    "Complete morning workout",
    "Review weekly priorities",
    "Finish project proposal",
  ]);
  const [priorities, setPriorities] = useState([
    "Submit Q2 report",
    "Call client at 2pm",
    "Review team pull requests",
  ]);
  const [schedule, setSchedule] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState("");
  const [newTask, setNewTask] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: tasks = [], isLoading } = useGetAllTasks();
  const addTask = useAddTask();
  const toggleTask = useToggleTask();
  const deleteTask = useDeleteTask();

  const handleAddTask = () => {
    const content = newTask.trim();
    if (!content) return;
    setNewTask("");
    addTask.mutate(content, {
      onError: () => toast.error("Failed to add task"),
    });
    inputRef.current?.focus();
  };

  const updateGoal = (i: number, val: string) =>
    setGoals((prev) => prev.map((g, idx) => (idx === i ? val : g)));

  const updatePriority = (i: number, val: string) =>
    setPriorities((prev) => prev.map((p, idx) => (idx === i ? val : p)));

  const updateSchedule = (slot: string, val: string) =>
    setSchedule((prev) => ({ ...prev, [slot]: val }));

  return (
    <div className="min-h-screen bg-background py-8 px-4 flex flex-col items-center">
      <Toaster position="top-right" />

      {/* Planner Notebook */}
      <main className="w-full max-w-4xl">
        <div
          className="bg-white rounded-2xl shadow-notebook overflow-hidden"
          style={{ border: "2px solid oklch(0.78 0.06 70)" }}
        >
          {/* Header Banner */}
          <header className="bg-planner-blue px-6 py-4 flex items-center justify-center gap-3 rounded-t-xl">
            <span className="text-2xl">📅</span>
            <h1 className="text-white font-display text-2xl font-extrabold tracking-wide">
              Daily Task Planner
            </h1>
            <span className="text-2xl">✏️</span>
          </header>

          <div className="p-5">
            {/* Date / Day Row */}
            <div className="flex gap-8 mb-5">
              <div className="flex items-center gap-2 flex-1">
                <span className="text-sm font-bold text-foreground/70 whitespace-nowrap">
                  Date:
                </span>
                <input
                  data-ocid="planner.input"
                  className="lined-input flex-1"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2 flex-1">
                <span className="text-sm font-bold text-foreground/70 whitespace-nowrap">
                  Day:
                </span>
                <input
                  data-ocid="planner.input"
                  className="lined-input flex-1"
                  value={day}
                  onChange={(e) => setDay(e.target.value)}
                />
              </div>
            </div>

            {/* Two-Column Layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* LEFT COLUMN */}
              <div className="flex flex-col gap-4">
                {/* Today's Goals */}
                <section data-ocid="goals.section">
                  <SectionHeader
                    title="Today's Goals"
                    color="orange"
                    icon="🎯"
                  />
                  <div className="planner-content shadow-section">
                    <ul className="space-y-2">
                      {goals.map((goal, i) => (
                        <li
                          key={GOAL_KEYS[i]}
                          className="flex items-center gap-2"
                        >
                          <span className="text-planner-orange font-bold text-sm">
                            •
                          </span>
                          <input
                            className="lined-input"
                            value={goal}
                            onChange={(e) => updateGoal(i, e.target.value)}
                            placeholder={`Goal ${i + 1}`}
                          />
                        </li>
                      ))}
                    </ul>
                  </div>
                </section>

                {/* Priority Tasks */}
                <section data-ocid="priorities.section">
                  <SectionHeader
                    title="Priority Tasks"
                    color="blue"
                    badge="High Importance"
                  />
                  <div className="planner-content shadow-section">
                    <ul className="space-y-2">
                      {priorities.map((p, i) => (
                        <li
                          key={PRIORITY_KEYS[i]}
                          className="flex items-center gap-2"
                        >
                          <span className="text-planner-blue font-bold text-sm w-4 shrink-0">
                            {i + 1}.
                          </span>
                          <input
                            className="lined-input"
                            value={p}
                            onChange={(e) => updatePriority(i, e.target.value)}
                            placeholder={`Priority ${i + 1}`}
                          />
                        </li>
                      ))}
                    </ul>
                  </div>
                </section>

                {/* Schedule */}
                <section data-ocid="schedule.section">
                  <SectionHeader title="Schedule" color="blue" icon="🕐" />
                  <div className="planner-content shadow-section">
                    <div className="space-y-1.5">
                      {TIME_SLOTS.map((slot) => (
                        <div key={slot} className="flex items-center gap-2">
                          <span className="text-xs font-bold text-planner-blue w-16 shrink-0">
                            {slot}
                          </span>
                          <input
                            className="lined-input flex-1"
                            value={schedule[slot] ?? ""}
                            onChange={(e) =>
                              updateSchedule(slot, e.target.value)
                            }
                            placeholder=""
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </section>
              </div>

              {/* RIGHT COLUMN */}
              <div className="flex flex-col gap-4">
                {/* To-Do List */}
                <section data-ocid="todo.section">
                  <SectionHeader title="To-Do List" color="blue" icon="✅" />
                  <div className="planner-content shadow-section">
                    {isLoading ? (
                      <div
                        data-ocid="todo.loading_state"
                        className="space-y-2 py-1"
                      >
                        {[1, 2, 3].map((i) => (
                          <div
                            key={i}
                            className="h-7 rounded bg-border/40 animate-pulse"
                          />
                        ))}
                      </div>
                    ) : (
                      <ScrollArea className="max-h-52">
                        <AnimatePresence initial={false}>
                          {tasks.length === 0 ? (
                            <p
                              data-ocid="todo.list.empty_state"
                              className="text-xs text-muted-foreground text-center py-4"
                            >
                              No tasks yet — add one below!
                            </p>
                          ) : (
                            tasks.map((task, idx) => (
                              <motion.div
                                key={String(task.id)}
                                layout
                                initial={{ opacity: 0, y: -6 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, x: 16 }}
                                transition={{ duration: 0.15 }}
                                data-ocid={`todo.item.${idx + 1}`}
                                className="group flex items-center gap-2 py-1.5 border-b border-border/40 last:border-0"
                              >
                                <Checkbox
                                  data-ocid={`todo.checkbox.${idx + 1}`}
                                  checked={task.completed}
                                  onCheckedChange={() =>
                                    toggleTask.mutate(task.id, {
                                      onError: () =>
                                        toast.error("Failed to update task"),
                                    })
                                  }
                                  className="border-planner-blue data-[state=checked]:bg-planner-blue data-[state=checked]:border-planner-blue shrink-0"
                                />
                                <span
                                  className={`flex-1 text-sm leading-snug ${
                                    task.completed
                                      ? "line-through text-muted-foreground"
                                      : "text-foreground"
                                  }`}
                                >
                                  {task.content}
                                </span>
                                <button
                                  type="button"
                                  data-ocid={`todo.delete_button.${idx + 1}`}
                                  onClick={() =>
                                    deleteTask.mutate(task.id, {
                                      onError: () =>
                                        toast.error("Failed to delete task"),
                                    })
                                  }
                                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-destructive/10 hover:text-destructive text-muted-foreground"
                                  aria-label="Delete task"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </motion.div>
                            ))
                          )}
                        </AnimatePresence>
                      </ScrollArea>
                    )}

                    {/* Add task input */}
                    <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border/40">
                      <Plus className="w-3.5 h-3.5 text-planner-blue shrink-0" />
                      <input
                        ref={inputRef}
                        data-ocid="todo.input"
                        className="flex-1 bg-transparent border-0 border-b border-border/40 focus:outline-none focus:border-planner-blue text-sm py-0.5 font-body"
                        placeholder="Add a task..."
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleAddTask()}
                        disabled={addTask.isPending}
                      />
                      <button
                        type="button"
                        data-ocid="todo.add_button"
                        onClick={handleAddTask}
                        disabled={!newTask.trim() || addTask.isPending}
                        className="text-xs bg-planner-blue text-white px-2 py-1 rounded font-semibold hover:opacity-90 disabled:opacity-40 transition-opacity"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </section>

                {/* Notes */}
                <section data-ocid="notes.section" className="flex-1">
                  <SectionHeader title="Notes" color="blue" icon="📝" />
                  <div className="planner-content shadow-section">
                    <textarea
                      data-ocid="notes.textarea"
                      className="w-full bg-transparent resize-none focus:outline-none text-sm font-body lined-paper min-h-[10rem]"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Write your notes here..."
                      rows={8}
                    />
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-6 text-center">
        <p className="text-xs text-muted-foreground/50 font-body">
          © {new Date().getFullYear()}. Built with ♥ using{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-muted-foreground transition-colors"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
