import { Toaster } from "@/components/ui/sonner";
import { LibraryCatalogue } from "./components/LibraryCatalogue";

export default function App() {
  return (
    <>
      <LibraryCatalogue />
      <Toaster richColors position="top-right" />
    </>
  );
}
