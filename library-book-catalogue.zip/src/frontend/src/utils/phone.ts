/**
 * Utility functions for handling Indian phone numbers with +91 prefix
 */

/**
 * Strips all non-digit characters from a phone number string
 */
export function stripNonDigits(value: string): string {
  return value.replace(/\D/g, "");
}

/**
 * Formats a phone number with +91 prefix for submission to backend
 */
export function formatPhoneWithPrefix(digits: string): string {
  const cleanDigits = stripNonDigits(digits);
  return `+91${cleanDigits}`;
}

/**
 * Validates that the phone number has exactly 10 digits (Indian mobile number)
 */
export function isValidIndianPhone(digits: string): boolean {
  const cleanDigits = stripNonDigits(digits);
  return cleanDigits.length === 10 && /^[6-9]/.test(cleanDigits);
}
