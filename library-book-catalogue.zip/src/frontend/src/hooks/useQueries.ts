import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { Book } from "../backend.d";
import { useActor } from "./useActor";

export function useListAllBooks() {
  const { actor, isFetching } = useActor();
  return useQuery<Book[]>({
    queryKey: ["books"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listAllBooks();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRemainingCapacity() {
  const { actor, isFetching } = useActor();
  return useQuery<bigint>({
    queryKey: ["capacity"],
    queryFn: async () => {
      if (!actor) return BigInt(20);
      return actor.getRemainingCapacity();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddBook() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      title: string;
      author: string;
      genre: string;
      year: bigint;
    }) => {
      if (!actor) throw new Error("Not connected");
      await actor.addBook(
        params.title,
        params.author,
        params.genre,
        params.year,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["books"] });
      qc.invalidateQueries({ queryKey: ["capacity"] });
    },
  });
}

export function useRemoveBook() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error("Not connected");
      await actor.removeBook(id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["books"] });
      qc.invalidateQueries({ queryKey: ["capacity"] });
    },
  });
}
