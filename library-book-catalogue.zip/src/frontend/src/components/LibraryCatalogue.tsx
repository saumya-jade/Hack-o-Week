import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  useAddBook,
  useListAllBooks,
  useRemainingCapacity,
  useRemoveBook,
} from "@/hooks/useQueries";
import {
  BookMarked,
  BookOpen,
  BookPlus,
  Library,
  Search,
  Trash2,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

const MAX_CAPACITY = 20;

export function LibraryCatalogue() {
  const [searchQuery, setSearchQuery] = useState("");
  const [form, setForm] = useState({
    title: "",
    author: "",
    genre: "",
    year: "",
  });
  const [formError, setFormError] = useState("");

  const { data: books = [], isLoading: booksLoading } = useListAllBooks();
  const { data: remainingCapacity } = useRemainingCapacity();
  const addBook = useAddBook();
  const removeBook = useRemoveBook();

  const usedSlots =
    remainingCapacity !== undefined
      ? MAX_CAPACITY - Number(remainingCapacity)
      : books.length;

  const filteredBooks = useMemo(() => {
    if (!searchQuery.trim()) return books;
    const q = searchQuery.toLowerCase();
    return books.filter((b) => b.title.toLowerCase().includes(q));
  }, [books, searchQuery]);

  const capacityFull =
    remainingCapacity !== undefined && Number(remainingCapacity) === 0;

  async function handleAddBook(e: React.FormEvent) {
    e.preventDefault();
    setFormError("");

    if (
      !form.title.trim() ||
      !form.author.trim() ||
      !form.genre.trim() ||
      !form.year.trim()
    ) {
      setFormError("All fields are required.");
      return;
    }
    const yearNum = Number.parseInt(form.year);
    if (Number.isNaN(yearNum) || yearNum < 1 || yearNum > 2100) {
      setFormError("Please enter a valid year.");
      return;
    }
    if (capacityFull) {
      setFormError("Library is at full capacity. Remove a book first.");
      return;
    }

    try {
      await addBook.mutateAsync({
        title: form.title.trim(),
        author: form.author.trim(),
        genre: form.genre.trim(),
        year: BigInt(yearNum),
      });
      setForm({ title: "", author: "", genre: "", year: "" });
      toast.success(`"${form.title.trim()}" added to the catalogue.`);
    } catch {
      toast.error("Failed to add book. Please try again.");
    }
  }

  async function handleRemoveBook(id: bigint, title: string) {
    try {
      await removeBook.mutateAsync(id);
      toast.success(`"${title}" removed from catalogue.`);
    } catch {
      toast.error("Failed to remove book. Please try again.");
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Decorative top bar */}
      <div
        className="h-1 w-full"
        style={{ background: "oklch(0.35 0.1 155)" }}
      />

      {/* Header */}
      <header className="border-b border-border bg-card shadow-xs">
        <div className="container mx-auto py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-lg"
              style={{ background: "oklch(0.35 0.1 155)" }}
            >
              <Library className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground tracking-tight">
                Library Book Catalogue
              </h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                Manage your curated collection
              </p>
            </div>
          </div>

          <Badge
            data-ocid="catalogue.capacity_badge"
            variant="outline"
            className={`text-base px-4 py-2 font-semibold border-2 ${
              capacityFull
                ? "border-destructive text-destructive"
                : usedSlots >= MAX_CAPACITY * 0.8
                  ? "border-accent text-accent-foreground bg-accent/10"
                  : "border-primary text-primary bg-primary/10"
            }`}
          >
            <BookMarked className="w-4 h-4 mr-2" />
            {usedSlots} / {MAX_CAPACITY} books
          </Badge>
        </div>
      </header>

      <main className="container mx-auto py-8 space-y-8">
        {/* Search */}
        <div className="relative max-w-lg">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            data-ocid="catalogue.search_input"
            placeholder="Search books by title\u2026"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-card"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Add Book Form */}
          <Card className="lg:col-span-1 shadow-card border-border">
            <CardHeader className="pb-4">
              <CardTitle className="font-display text-xl flex items-center gap-2">
                <BookPlus
                  className="w-5 h-5"
                  style={{ color: "oklch(0.35 0.1 155)" }}
                />
                Add New Book
              </CardTitle>
              <CardDescription>
                {capacityFull
                  ? "Collection is full \u2014 remove a book to add another"
                  : `${remainingCapacity !== undefined ? Number(remainingCapacity) : "\u2014"} slot${
                      Number(remainingCapacity) !== 1 ? "s" : ""
                    } remaining`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddBook} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="book-title">Title</Label>
                  <Input
                    id="book-title"
                    data-ocid="catalogue.title_input"
                    placeholder="e.g. To Kill a Mockingbird"
                    value={form.title}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, title: e.target.value }))
                    }
                    disabled={capacityFull}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="book-author">Author</Label>
                  <Input
                    id="book-author"
                    data-ocid="catalogue.author_input"
                    placeholder="e.g. Harper Lee"
                    value={form.author}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, author: e.target.value }))
                    }
                    disabled={capacityFull}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="book-genre">Genre</Label>
                  <Input
                    id="book-genre"
                    data-ocid="catalogue.genre_input"
                    placeholder="e.g. Literary Fiction"
                    value={form.genre}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, genre: e.target.value }))
                    }
                    disabled={capacityFull}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="book-year">Year</Label>
                  <Input
                    id="book-year"
                    data-ocid="catalogue.year_input"
                    placeholder="e.g. 1960"
                    type="number"
                    min={1}
                    max={2100}
                    value={form.year}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, year: e.target.value }))
                    }
                    disabled={capacityFull}
                  />
                </div>

                {formError && (
                  <p
                    data-ocid="catalogue.error_state"
                    className="text-sm text-destructive"
                  >
                    {formError}
                  </p>
                )}

                <Button
                  data-ocid="catalogue.add_button"
                  type="submit"
                  className="w-full font-semibold"
                  style={{
                    background: "oklch(0.35 0.1 155)",
                    color: "oklch(0.98 0.005 85)",
                  }}
                  disabled={capacityFull || addBook.isPending}
                >
                  {addBook.isPending ? (
                    <span className="flex items-center gap-2">
                      <svg
                        className="w-4 h-4 animate-spin"
                        viewBox="0 0 24 24"
                        fill="none"
                        aria-hidden="true"
                      >
                        <title>Loading</title>
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                        />
                      </svg>
                      Adding\u2026
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <BookPlus className="w-4 h-4" />
                      Add to Catalogue
                    </span>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Book List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-semibold text-foreground">
                {searchQuery ? `Results for "${searchQuery}"` : "All Books"}
              </h2>
              {!booksLoading && (
                <span className="text-sm text-muted-foreground">
                  {filteredBooks.length}{" "}
                  {filteredBooks.length === 1 ? "book" : "books"}
                </span>
              )}
            </div>

            <Card className="shadow-card overflow-hidden">
              {booksLoading ? (
                <div
                  data-ocid="catalogue.loading_state"
                  className="p-6 space-y-3"
                >
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex gap-4 items-center">
                      <Skeleton className="h-5 flex-1" />
                      <Skeleton className="h-5 w-28" />
                      <Skeleton className="h-5 w-20" />
                      <Skeleton className="h-5 w-12" />
                      <Skeleton className="h-8 w-8 rounded" />
                    </div>
                  ))}
                </div>
              ) : filteredBooks.length === 0 ? (
                <div
                  data-ocid="catalogue.empty_state"
                  className="flex flex-col items-center justify-center py-16 px-6 text-center"
                >
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <BookOpen className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <p className="font-display text-lg font-semibold text-foreground">
                    {searchQuery
                      ? "No books match your search"
                      : "No books in the catalogue"}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {searchQuery
                      ? "Try a different search term"
                      : "Add your first book using the form on the left"}
                  </p>
                </div>
              ) : (
                <div data-ocid="catalogue.list" className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50 hover:bg-muted/50">
                        <TableHead className="font-semibold text-foreground">
                          Title
                        </TableHead>
                        <TableHead className="font-semibold text-foreground">
                          Author
                        </TableHead>
                        <TableHead className="font-semibold text-foreground hidden md:table-cell">
                          Genre
                        </TableHead>
                        <TableHead className="font-semibold text-foreground hidden sm:table-cell">
                          Year
                        </TableHead>
                        <TableHead className="font-semibold text-foreground">
                          Status
                        </TableHead>
                        <TableHead className="w-12" />
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <AnimatePresence>
                        {filteredBooks.map((book, idx) => (
                          <motion.tr
                            key={String(book.id)}
                            data-ocid={`catalogue.item.${idx + 1}`}
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            transition={{ duration: 0.2, delay: idx * 0.03 }}
                            className="group border-b border-border last:border-0 hover:bg-muted/30 transition-colors"
                          >
                            <TableCell className="font-medium text-foreground">
                              {book.title}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {book.author}
                            </TableCell>
                            <TableCell className="text-muted-foreground hidden md:table-cell">
                              {book.genre}
                            </TableCell>
                            <TableCell className="text-muted-foreground hidden sm:table-cell">
                              {String(book.year)}
                            </TableCell>
                            <TableCell>
                              {book.available ? (
                                <Badge className="bg-success text-success-foreground font-medium text-xs">
                                  Available
                                </Badge>
                              ) : (
                                <Badge
                                  variant="destructive"
                                  className="font-medium text-xs"
                                >
                                  Checked Out
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <Button
                                data-ocid={`catalogue.delete_button.${idx + 1}`}
                                variant="ghost"
                                size="icon"
                                className="opacity-0 group-hover:opacity-100 hover:bg-destructive/10 hover:text-destructive transition-all h-8 w-8"
                                onClick={() =>
                                  handleRemoveBook(book.id, book.title)
                                }
                                disabled={removeBook.isPending}
                                title={`Remove "${book.title}"`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                    </TableBody>
                  </Table>
                </div>
              )}
            </Card>
          </div>
        </div>
      </main>

      <Separator className="mt-12" />
      <footer className="container mx-auto py-6 text-center">
        <p className="text-sm text-muted-foreground">
          Library Book Catalogue {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  );
}
