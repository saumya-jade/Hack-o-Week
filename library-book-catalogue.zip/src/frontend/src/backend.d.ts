import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Book {
    id: bigint;
    title: string;
    year: bigint;
    author: string;
    available: boolean;
    genre: string;
}
export interface backendInterface {
    addBook(title: string, author: string, genre: string, year: bigint): Promise<void>;
    getBookById(id: bigint): Promise<Book>;
    getRemainingCapacity(): Promise<bigint>;
    listAllBooks(): Promise<Array<Book>>;
    removeBook(id: bigint): Promise<void>;
    searchByTitle(title: string): Promise<Book>;
}
