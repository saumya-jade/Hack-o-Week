import Nat "mo:core/Nat";
import Text "mo:core/Text";
import Array "mo:core/Array";
import Runtime "mo:core/Runtime";
import Map "mo:core/Map";



actor {
  public type Book = {
    id : Nat;
    title : Text;
    author : Text;
    genre : Text;
    year : Nat;
    available : Bool;
  };

  let maxCapacity = 20;
  var books : [Book] = [];
  var nextId = 0;

  public shared ({ caller }) func addBook(title : Text, author : Text, genre : Text, year : Nat) : async () {
    if (books.size() >= maxCapacity) {
      Runtime.trap("Catalogue is full");
    };

    let newBook : Book = {
      id = nextId;
      title;
      author;
      genre;
      year;
      available = true;
    };

    books := books.concat([newBook]);
    nextId += 1;
  };

  public shared ({ caller }) func removeBook(id : Nat) : async () {
    let index = books.findIndex(func(book) { book.id == id });
    switch (index) {
      case (null) { Runtime.trap("Book not found") };
      case (?i) {
        let before = books.sliceToArray(0, i);
        let after = books.sliceToArray(i + 1, books.size());
        books := before.concat(after);
      };
    };
  };

  public query ({ caller }) func searchByTitle(title : Text) : async Book {
    let foundBook = books.find(func(book) { book.title == title });
    switch (foundBook) {
      case (null) { Runtime.trap("Book not found") };
      case (?book) { book };
    };
  };

  public query ({ caller }) func listAllBooks() : async [Book] {
    books;
  };

  public query ({ caller }) func getRemainingCapacity() : async Nat {
    maxCapacity - books.size();
  };

  public query ({ caller }) func getBookById(id : Nat) : async Book {
    let foundBook = books.find(func(book) { book.id == id });
    switch (foundBook) {
      case (null) { Runtime.trap("Book not found") };
      case (?book) { book };
    };
  };
};
