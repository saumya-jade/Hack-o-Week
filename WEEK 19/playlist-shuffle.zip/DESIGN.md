# Design Brief

## Purpose & Context
Music playlist manager with doubly linked list operations. Users need clear visualization of song order, smooth state transitions, and intuitive controls for shuffle/reverse modes.

## Tone & Aesthetic
Contemporary music app—clean, sophisticated, functional. Inspired by modern music streaming interfaces (Apple Music minimalism). No skeuomorphism, no excessive decoration. Purposeful depth through elevation and spacing rhythm.

## Color Palette

| Token | Light (OKLCH) | Dark (OKLCH) | Role |
|-------|---------------|-------------|------|
| Primary | 0.35 0.12 263 | 0.72 0.15 263 | Deep indigo—primary actions, shuffle indicator |
| Accent | 0.68 0.2 65 | 0.78 0.2 65 | Warm amber—active state, "now playing" emphasis |
| Destructive | 0.55 0.22 25 | 0.65 0.19 22 | Red—delete actions |
| Muted | 0.92 0 0 | 0.25 0 0 | Neutral secondary surface |
| Background | 0.98 0 0 | 0.11 0.01 263 | Page base (light: near-white; dark: deep indigo) |

## Typography
- **Display**: Space Grotesk (modern, geometric, music/tech aesthetic)
- **Body**: Nunito (approachable, friendly, high readability)
- **Mono**: JetBrains Mono (position numbers, optional code display)

## Shape Language
- **Border radius**: 0.625rem (soft, approachable—not rigid, not overly rounded)
- **Elevation**: Cards use subtle backgrounds + 1px border
- **Density**: Generous padding (1.5rem) for cards; compact list items (0.75rem vertical)

## Structural Zones

| Zone | Light | Dark | Purpose |
|------|-------|------|---------|
| Header | bg-card border-b | bg-card/80 border-b | Title "Playlist", mode indicator (Normal/Shuffle) |
| Content (Cards) | bg-card shadow-xs | bg-card shadow-xs | Song cards, position counters, action buttons |
| Controls | bg-muted/40 | bg-muted/40 | Add-to-front, add-to-end, shuffle toggle buttons |
| Footer | bg-muted/30 border-t | bg-muted/30 border-t | Count summary, optional help text |

## Component Patterns
- **Song Card**: Position badge (dark bg, light text), title, artist, delete button (destructive color)
- **Mode Indicator**: "Now Playing: Normal" or "Now Playing: Shuffled (Reversed)" with accent color
- **Action Buttons**: Primary (indigo), secondary (muted background), destructive (red)
- **Input Fields**: Soft border, muted background, focus ring matches primary

## Motion & Transitions
- **Default**: 0.3s cubic-bezier(0.4, 0, 0.2, 1) for all interactive elements
- **Shuffle Toggle**: No animation override—use default smooth transition
- **Delete**: Fade + slide (optional, if list animates)

## Constraints & Anti-Patterns
- ✗ Do NOT use gray/neutral primary—indigo is distinctive for music
- ✗ Do NOT add decorative gradients (no 3D gloss, no animated background)
- ✗ Do NOT use arbitrary spacing—maintain rhythm (0.5rem, 0.75rem, 1rem, 1.5rem)
- ✓ DO keep song count visible at all times
- ✓ DO highlight current shuffle mode (Normal vs Shuffled)
- ✓ DO use position numbers as visual anchors in the list

## Signature Detail
Shuffle mode toggle displays both state *and* visual confirmation: the entire card background shifts subtly when entering shuffle/reverse mode, coupled with clear text state ("Normal" vs "Shuffled"). Accent color (amber) highlights the active toggle button, creating a cohesive "this mode is active" signal.

## Dark Mode
Enabled by default (`.dark` class in `index.css`). Same structural approach; primary becomes lighter indigo (0.72 vs 0.35) for readability on dark backgrounds. Background color intentionally uses a deep indigo tint (0.11 0.01 263) instead of pure black for cohesion with the primary color system.
