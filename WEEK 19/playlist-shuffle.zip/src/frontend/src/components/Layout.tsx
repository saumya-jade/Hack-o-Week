import { Toaster } from "@/components/ui/sonner";
import { ListMusic, Shuffle } from "lucide-react";
import type { ReactNode } from "react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
              <ListMusic className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-semibold tracking-tight text-foreground">
              Playlist Shuffle
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Shuffle className="w-4 h-4" />
            <span className="font-body">Doubly Linked List</span>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-background">{children}</main>

      <Toaster richColors position="bottom-right" />

      <footer className="bg-card border-t border-border py-4">
        <div className="max-w-6xl mx-auto px-6 text-center text-xs text-muted-foreground font-body">
          © {new Date().getFullYear()}. Built with love using{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:underline transition-colors duration-200"
          >
            caffeine.ai
          </a>
        </div>
      </footer>
    </div>
  );
}
