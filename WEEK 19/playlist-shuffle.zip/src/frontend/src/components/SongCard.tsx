import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowDownToLine, Music2, Trash2 } from "lucide-react";
import { motion } from "motion/react";
import type { Song } from "../types";

interface SongCardProps {
  song: Song;
  position: number;
  isShuffled: boolean;
  onDelete: (pos: number) => void;
  onAddToEnd: (title: string, artist: string) => void;
}

export function SongCard({
  song,
  position,
  isShuffled,
  onDelete,
  onAddToEnd,
}: SongCardProps) {
  const posLabel = String(position + 1).padStart(2, "0");

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.25, delay: position * 0.04 }}
      layout
      className="group relative rounded-xl border border-border bg-card overflow-hidden transition-smooth hover:border-primary/40 hover:shadow-lg hover:shadow-primary/10"
      data-ocid={`playlist.item.${position + 1}`}
    >
      {/* Position badge */}
      <div className="absolute top-3 left-3 z-10">
        <span
          className={`font-display text-2xl font-bold leading-none transition-colors duration-200 ${
            isShuffled ? "text-gradient-accent" : "text-primary/70"
          }`}
        >
          {posLabel}
        </span>
      </div>

      {/* Delete button */}
      <button
        type="button"
        onClick={() => onDelete(position)}
        className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-smooth text-muted-foreground hover:text-destructive"
        aria-label={`Delete ${song.title}`}
        data-ocid={`playlist.delete_button.${position + 1}`}
      >
        <Trash2 className="w-4 h-4" />
      </button>

      {/* Song info */}
      <div className="pt-10 pb-3 px-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
            <Music2 className="w-5 h-5 text-primary" />
          </div>
          <div className="min-w-0">
            <p className="font-display font-semibold text-sm text-foreground truncate leading-tight">
              {song.title}
            </p>
            <p className="font-body text-xs text-muted-foreground truncate mt-0.5">
              {song.artist}
            </p>
          </div>
        </div>
      </div>

      {/* Add to end action */}
      <button
        type="button"
        onClick={() => onAddToEnd(song.title, song.artist)}
        className="w-full flex items-center justify-center gap-1.5 py-2 px-3 border-t border-border text-xs font-body text-muted-foreground hover:text-primary hover:bg-primary/5 transition-smooth"
        data-ocid={`playlist.add_to_end_button.${position + 1}`}
      >
        <ArrowDownToLine className="w-3 h-3" />
        ADD TO END
      </button>
    </motion.div>
  );
}

interface SongCardSkeletonProps {
  index: number;
}

export function SongCardSkeleton({ index }: SongCardSkeletonProps) {
  return (
    <div
      className="rounded-xl border border-border bg-card overflow-hidden animate-pulse"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="pt-10 pb-3 px-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-muted" />
          <div className="flex-1 space-y-2">
            <div className="h-3.5 bg-muted rounded w-3/4" />
            <div className="h-3 bg-muted rounded w-1/2" />
          </div>
        </div>
      </div>
      <div className="h-8 bg-muted/50 border-t border-border" />
    </div>
  );
}

interface AddSongInlineProps {
  position: "front" | "end";
}

export function AddSongInline({ position }: AddSongInlineProps) {
  return (
    <div
      className="rounded-xl border-2 border-dashed border-border bg-card/50 flex flex-col items-center justify-center p-6 gap-3 transition-smooth hover:border-primary/40 hover:bg-card min-h-[140px]"
      data-ocid={`playlist.add_${position}_card`}
    >
      <Badge
        variant="secondary"
        className={`text-xs font-display font-semibold ${position === "front" ? "bg-primary/20 text-primary border-primary/30" : "bg-accent/20 text-accent-foreground border-accent/30"}`}
      >
        {position === "front" ? "ADD TO FRONT" : "ADD TO END"}
      </Badge>
      <p className="text-xs text-muted-foreground font-body text-center">
        Use the form above to add a song
      </p>
    </div>
  );
}
