import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { type backendInterface, createActor } from "../backend";
import type { Song } from "../types";

const QUERY_KEY = ["songs"] as const;

export function usePlaylist() {
  const { actor, isFetching } = useActor<backendInterface>(createActor);
  const queryClient = useQueryClient();
  const [isShuffled, setIsShuffled] = useState(false);

  const { data: songs = [], isLoading } = useQuery<Song[]>({
    queryKey: QUERY_KEY,
    queryFn: async () => {
      if (!actor) return [];
      const result = await actor.getSongs();
      return result.map((s) => ({
        id: Number(s.id),
        title: s.title,
        artist: s.artist,
      }));
    },
    enabled: !!actor && !isFetching,
  });

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: QUERY_KEY });

  const addToFront = useMutation({
    mutationFn: async ({
      title,
      artist,
    }: { title: string; artist: string }) => {
      if (!actor) return;
      await actor.addToFront(title, artist);
    },
    onSuccess: () => invalidate(),
  });

  const addToEnd = useMutation({
    mutationFn: async ({
      title,
      artist,
    }: { title: string; artist: string }) => {
      if (!actor) return;
      await actor.addToEnd(title, artist);
    },
    onSuccess: () => invalidate(),
  });

  const deleteByPosition = useMutation({
    mutationFn: async (pos: number) => {
      if (!actor) return;
      // Frontend is 0-indexed; canister expects 1-indexed
      await actor.deleteByPosition(BigInt(pos + 1));
    },
    onSuccess: () => invalidate(),
  });

  const reverse = useMutation({
    mutationFn: async () => {
      if (!actor) return;
      await actor.reverse();
      setIsShuffled((prev) => !prev);
    },
    onSuccess: () => invalidate(),
  });

  const clearPlaylist = useMutation({
    mutationFn: async () => {
      if (!actor) return;
      await actor.clearPlaylist();
      setIsShuffled(false);
    },
    onSuccess: () => invalidate(),
  });

  return {
    songs,
    isShuffled,
    isLoading: isLoading || isFetching,
    addToFront: (title: string, artist: string) =>
      addToFront.mutate({ title, artist }),
    addToEnd: (title: string, artist: string) =>
      addToEnd.mutate({ title, artist }),
    deleteByPosition: (pos: number) => deleteByPosition.mutate(pos),
    reverse: () => reverse.mutate(),
    clearPlaylist: () => clearPlaylist.mutate(),
    isAddingToFront: addToFront.isPending,
    isAddingToEnd: addToEnd.isPending,
    isReversing: reverse.isPending,
  };
}
