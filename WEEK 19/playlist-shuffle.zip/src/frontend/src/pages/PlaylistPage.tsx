import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  ArrowDownToLine,
  ArrowUpToLine,
  Plus,
  RotateCcw,
  Shuffle,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";
import { SongCard, SongCardSkeleton } from "../components/SongCard";
import { usePlaylist } from "../hooks/usePlaylist";

interface AddSongForm {
  title: string;
  artist: string;
}

const EMPTY_FORM: AddSongForm = { title: "", artist: "" };

export function PlaylistPage() {
  const {
    songs,
    isLoading,
    addToFront,
    addToEnd,
    deleteByPosition,
    reverse,
    clearPlaylist,
  } = usePlaylist();

  const [isShuffled, setIsShuffled] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [addPosition, setAddPosition] = useState<"front" | "end">("end");
  const [form, setForm] = useState<AddSongForm>(EMPTY_FORM);

  const handleOpenForm = (pos: "front" | "end") => {
    setAddPosition(pos);
    setShowForm(true);
    setForm(EMPTY_FORM);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim() || !form.artist.trim()) return;
    if (addPosition === "front") {
      addToFront(form.title.trim(), form.artist.trim());
      toast.success(`"${form.title}" added to front`);
    } else {
      addToEnd(form.title.trim(), form.artist.trim());
      toast.success(`"${form.title}" added to end`);
    }
    setForm(EMPTY_FORM);
    setShowForm(false);
  };

  const handleDelete = (pos: number) => {
    const song = songs[pos];
    deleteByPosition(pos);
    toast.success(`"${song?.title ?? "Song"}" removed`);
  };

  const handleShuffle = () => {
    reverse();
    setIsShuffled((prev) => !prev);
    toast.success(
      isShuffled ? "Order restored" : "Playlist reversed — shuffle mode on!",
    );
  };

  const handleClear = () => {
    clearPlaylist();
    setIsShuffled(false);
    toast.success("Playlist cleared");
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      {/* Header row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground tracking-tight">
            Your Playlist
          </h1>
          <p className="font-body text-sm text-muted-foreground mt-1">
            {songs.length} song{songs.length !== 1 ? "s" : ""} · Doubly linked
            list
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleOpenForm("front")}
            className="gap-1.5 font-display font-semibold text-xs tracking-wide border-primary/40 text-primary hover:bg-primary/10"
            data-ocid="playlist.add_to_front_button"
          >
            <ArrowUpToLine className="w-3.5 h-3.5" />
            ADD TO FRONT
          </Button>
          <Button
            size="sm"
            onClick={() => handleOpenForm("end")}
            className="gap-1.5 font-display font-semibold text-xs tracking-wide"
            data-ocid="playlist.add_to_end_button"
          >
            <ArrowDownToLine className="w-3.5 h-3.5" />
            ADD TO END
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleClear}
            className="gap-1.5 text-xs font-display text-muted-foreground hover:text-destructive hover:border-destructive/40"
            data-ocid="playlist.clear_button"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            CLEAR
          </Button>
        </div>
      </div>

      {/* Shuffle mode banner */}
      <motion.div
        layout
        className={`mb-6 rounded-xl border px-5 py-3.5 flex items-center justify-between transition-smooth ${
          isShuffled ? "bg-accent/15 border-accent/40" : "bg-card border-border"
        }`}
        data-ocid="playlist.shuffle_toggle"
      >
        <div className="flex items-center gap-3">
          <Shuffle
            className={`w-5 h-5 transition-colors duration-300 ${
              isShuffled ? "text-accent" : "text-muted-foreground"
            }`}
          />
          <span
            className={`font-display font-bold text-sm tracking-widest ${isShuffled ? "text-accent" : "text-muted-foreground"}`}
          >
            SHUFFLE MODE:{" "}
            <span className={isShuffled ? "text-accent" : "text-foreground"}>
              {isShuffled ? "ON" : "NORMAL"}
            </span>
          </span>
          {isShuffled && (
            <Badge className="bg-accent/20 text-accent-foreground border-accent/40 text-[10px] font-display font-bold tracking-wider px-2">
              REVERSED
            </Badge>
          )}
        </div>
        <button
          type="button"
          onClick={handleShuffle}
          className={`relative w-11 h-6 rounded-full border-2 transition-smooth focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
            isShuffled ? "bg-accent border-accent/60" : "bg-muted border-border"
          }`}
          role="switch"
          aria-checked={isShuffled}
          aria-label="Toggle shuffle mode"
          data-ocid="playlist.shuffle_switch"
        >
          <motion.span
            layout
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
            className={`absolute top-0.5 w-4 h-4 rounded-full shadow-sm transition-colors duration-200 ${
              isShuffled
                ? "left-5 bg-accent-foreground"
                : "left-0.5 bg-foreground/70"
            }`}
          />
        </button>
      </motion.div>

      {/* Add song form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden mb-6"
          >
            <div
              className={`rounded-xl border-2 p-5 bg-card ${
                addPosition === "front"
                  ? "border-primary/50"
                  : "border-accent/50"
              }`}
              data-ocid="playlist.add_song_dialog"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Plus className="w-4 h-4 text-primary" />
                  <span className="font-display font-semibold text-sm text-foreground">
                    Add song to{" "}
                    <span
                      className={
                        addPosition === "front" ? "text-primary" : "text-accent"
                      }
                    >
                      {addPosition}
                    </span>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="text-muted-foreground hover:text-foreground transition-colors duration-200"
                  data-ocid="playlist.close_button"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <form
                onSubmit={handleSubmit}
                className="flex flex-col sm:flex-row gap-3"
              >
                <div className="flex-1 space-y-1">
                  <Label className="text-xs font-display font-semibold text-muted-foreground tracking-wider">
                    TITLE
                  </Label>
                  <Input
                    value={form.title}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, title: e.target.value }))
                    }
                    placeholder="Song title..."
                    className="font-body bg-background border-input"
                    required
                    data-ocid="playlist.title_input"
                  />
                </div>
                <div className="flex-1 space-y-1">
                  <Label className="text-xs font-display font-semibold text-muted-foreground tracking-wider">
                    ARTIST
                  </Label>
                  <Input
                    value={form.artist}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, artist: e.target.value }))
                    }
                    placeholder="Artist name..."
                    className="font-body bg-background border-input"
                    required
                    data-ocid="playlist.artist_input"
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    type="submit"
                    className={`w-full sm:w-auto gap-1.5 font-display font-semibold text-xs tracking-wide ${
                      addPosition === "front"
                        ? ""
                        : "bg-accent text-accent-foreground hover:bg-accent/90"
                    }`}
                    data-ocid="playlist.submit_button"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    ADD SONG
                  </Button>
                </div>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Song grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(["sk-a", "sk-b", "sk-c", "sk-d", "sk-e", "sk-f"] as const).map(
            (k, i) => (
              <SongCardSkeleton key={k} index={i} />
            ),
          )}
        </div>
      ) : songs.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-24 gap-4"
          data-ocid="playlist.empty_state"
        >
          <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center">
            <Shuffle className="w-8 h-8 text-muted-foreground" />
          </div>
          <div className="text-center">
            <p className="font-display font-semibold text-foreground">
              No songs yet
            </p>
            <p className="font-body text-sm text-muted-foreground mt-1">
              Add songs to front or end to build your playlist
            </p>
          </div>
          <div className="flex gap-2 mt-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleOpenForm("front")}
              className="gap-1.5 text-xs font-display border-primary/40 text-primary"
              data-ocid="playlist.empty_add_front_button"
            >
              <ArrowUpToLine className="w-3.5 h-3.5" />
              ADD TO FRONT
            </Button>
            <Button
              size="sm"
              onClick={() => handleOpenForm("end")}
              className="gap-1.5 text-xs font-display"
              data-ocid="playlist.empty_add_end_button"
            >
              <ArrowDownToLine className="w-3.5 h-3.5" />
              ADD TO END
            </Button>
          </div>
        </motion.div>
      ) : (
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          <AnimatePresence mode="popLayout">
            {songs.map((song, index) => (
              <SongCard
                key={song.id}
                song={song}
                position={index}
                isShuffled={isShuffled}
                onDelete={handleDelete}
                onAddToEnd={addToEnd}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      )}

      {/* List info footer */}
      {songs.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-8 flex items-center justify-center gap-6 text-xs text-muted-foreground font-body"
        >
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-primary/60" />
            Head:{" "}
            <span className="text-foreground font-semibold">
              {songs[0]?.title}
            </span>
          </span>
          <span className="text-border">·</span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-accent/60" />
            Tail:{" "}
            <span className="text-foreground font-semibold">
              {songs[songs.length - 1]?.title}
            </span>
          </span>
          <span className="text-border">·</span>
          <span>{songs.length} nodes</span>
        </motion.div>
      )}
    </div>
  );
}
