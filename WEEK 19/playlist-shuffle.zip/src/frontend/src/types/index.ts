export interface Song {
  id: number;
  title: string;
  artist: string;
}

export interface PlaylistState {
  songs: Song[];
  isShuffled: boolean;
  isLoading: boolean;
}

export type AddPosition = "front" | "end";
