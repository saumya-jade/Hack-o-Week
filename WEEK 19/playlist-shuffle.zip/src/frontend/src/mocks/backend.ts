import type { backendInterface } from "../backend";

export const mockBackend: backendInterface = {
  addToEnd: async (_title: string, _artist: string) => BigInt(3),
  addToFront: async (_title: string, _artist: string) => BigInt(0),
  clearPlaylist: async () => undefined,
  deleteByPosition: async (_pos: bigint) => true,
  getSongs: async () => [
    { id: BigInt(1), title: "Midnight City", artist: "M83" },
    { id: BigInt(2), title: "Blinding Lights", artist: "The Weeknd" },
    { id: BigInt(3), title: "Levitating", artist: "Dua Lipa" },
  ],
  reverse: async () => undefined,
};
