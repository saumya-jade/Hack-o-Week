import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type SongId = bigint;
export interface Song {
    id: SongId;
    title: string;
    artist: string;
}
export interface backendInterface {
    addToEnd(title: string, artist: string): Promise<bigint>;
    addToFront(title: string, artist: string): Promise<bigint>;
    clearPlaylist(): Promise<void>;
    deleteByPosition(pos: bigint): Promise<boolean>;
    getSongs(): Promise<Array<Song>>;
    reverse(): Promise<void>;
}
