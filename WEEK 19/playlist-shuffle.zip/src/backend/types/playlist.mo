import Common "common";

module {
  public type SongId = Common.SongId;

  /// Immutable song record returned over the public API (shared type)
  public type Song = {
    id     : SongId;
    title  : Text;
    artist : Text;
  };

  /// A node in the doubly linked list — stored in the Map
  public type ListNode = {
    id   : SongId;
    prev : ?SongId;
    next : ?SongId;
  };

  /// Snapshot of the full playlist state (shared-safe — nodes as array of pairs)
  public type PlaylistState = {
    head  : ?SongId;
    tail  : ?SongId;
    nodes : [(SongId, ListNode)];
  };
};
