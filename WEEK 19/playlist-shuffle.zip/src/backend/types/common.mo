module {
  public type SongId = Nat;
  public type Timestamp = Int;
};
