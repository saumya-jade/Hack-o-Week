import PlaylistLib "../lib/playlist";

mixin (state : PlaylistLib.State) {

  /// Add a song to the front of the playlist. Returns the new song's id.
  public func addToFront(title : Text, artist : Text) : async Nat {
    PlaylistLib.addToFront(state, title, artist);
  };

  /// Add a song to the end of the playlist. Returns the new song's id.
  public func addToEnd(title : Text, artist : Text) : async Nat {
    PlaylistLib.addToEnd(state, title, artist);
  };

  /// Delete the song at the given 1-indexed position.
  /// Returns true on success, false if position is out of range.
  public func deleteByPosition(pos : Nat) : async Bool {
    PlaylistLib.deleteByPosition(state, pos);
  };

  /// Return all songs in the current playlist order.
  public query func getSongs() : async [PlaylistLib.Song] {
    PlaylistLib.getSongs(state);
  };

  /// Reverse the playlist order (for shuffle mode).
  public func reverse() : async () {
    PlaylistLib.reverse(state);
  };

  /// Remove all songs from the playlist.
  public func clearPlaylist() : async () {
    PlaylistLib.clear(state);
  };
};
