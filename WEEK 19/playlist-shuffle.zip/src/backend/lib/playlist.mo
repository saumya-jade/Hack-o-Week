import Map     "mo:core/Map";
import List    "mo:core/List";
import Types   "../types/playlist";

module {
  public type SongId        = Types.SongId;
  public type Song          = Types.Song;
  public type ListNode      = Types.ListNode;
  public type PlaylistState = Types.PlaylistState;

  // ── Internal mutable state container ──────────────────────────────────────
  public type State = {
    songs     : Map.Map<SongId, Song>;
    nodes     : Map.Map<SongId, ListNode>;
    var head  : ?SongId;
    var tail  : ?SongId;
    var nextId: Nat;
  };

  public func newState() : State {
    {
      songs     = Map.empty<SongId, Song>();
      nodes     = Map.empty<SongId, ListNode>();
      var head  = null;
      var tail  = null;
      var nextId = 0;
    };
  };

  // ── Internal helpers ──────────────────────────────────────────────────────

  func getNode(state : State, id : SongId) : ListNode {
    switch (state.nodes.get(id)) {
      case (?n) n;
      case null { assert false; loop {} };
    };
  };

  // ── Doubly-linked list operations ─────────────────────────────────────────

  /// Add a new song to the front of the list. Returns the new SongId.
  public func addToFront(state : State, title : Text, artist : Text) : SongId {
    let id = state.nextId;
    state.nextId += 1;

    let song : Song = { id; title; artist };
    state.songs.add(id, song);

    let node : ListNode = { id; prev = null; next = state.head };

    // Update old head's prev pointer
    switch (state.head) {
      case (?oldHeadId) {
        let oldHead = getNode(state, oldHeadId);
        state.nodes.add(oldHeadId, { oldHead with prev = ?id });
      };
      case null {};
    };

    state.nodes.add(id, node);
    state.head := ?id;

    // If list was empty, tail = head
    if (state.tail == null) {
      state.tail := ?id;
    };

    id;
  };

  /// Add a new song to the end of the list. Returns the new SongId.
  public func addToEnd(state : State, title : Text, artist : Text) : SongId {
    let id = state.nextId;
    state.nextId += 1;

    let song : Song = { id; title; artist };
    state.songs.add(id, song);

    let node : ListNode = { id; prev = state.tail; next = null };

    // Update old tail's next pointer
    switch (state.tail) {
      case (?oldTailId) {
        let oldTail = getNode(state, oldTailId);
        state.nodes.add(oldTailId, { oldTail with next = ?id });
      };
      case null {};
    };

    state.nodes.add(id, node);
    state.tail := ?id;

    // If list was empty, head = tail
    if (state.head == null) {
      state.head := ?id;
    };

    id;
  };

  /// Delete the song at 1-indexed position. Returns true if deleted, false if
  /// position is out of range.
  public func deleteByPosition(state : State, pos : Nat) : Bool {
    if (pos == 0) return false;

    // Traverse to the node at 1-indexed position
    var current = state.head;
    var index : Nat = 1;
    while (index < pos) {
      switch (current) {
        case (?cid) {
          let n = getNode(state, cid);
          current := n.next;
        };
        case null { return false };
      };
      index += 1;
    };

    switch (current) {
      case null false;
      case (?targetId) {
        let target = getNode(state, targetId);

        // Rewire prev node's next pointer
        switch (target.prev) {
          case (?prevId) {
            let prevNode = getNode(state, prevId);
            state.nodes.add(prevId, { prevNode with next = target.next });
          };
          case null {
            // target was head
            state.head := target.next;
          };
        };

        // Rewire next node's prev pointer
        switch (target.next) {
          case (?nextId) {
            let nextNode = getNode(state, nextId);
            state.nodes.add(nextId, { nextNode with prev = target.prev });
          };
          case null {
            // target was tail
            state.tail := target.prev;
          };
        };

        state.nodes.remove(targetId);
        state.songs.remove(targetId);
        true;
      };
    };
  };

  /// Return all songs in current traversal order (head → tail).
  public func getSongs(state : State) : [Song] {
    let result = List.empty<Song>();
    var current = state.head;
    label traverse loop {
      switch (current) {
        case null break traverse;
        case (?cid) {
          switch (state.songs.get(cid)) {
            case (?song) result.add(song);
            case null {};
          };
          let node = getNode(state, cid);
          current := node.next;
        };
      };
    };
    result.toArray();
  };

  /// Reverse the linked list in place (swaps head/tail, flips all prev/next).
  public func reverse(state : State) : () {
    // Swap prev/next on every node
    var current = state.head;
    label traverse loop {
      switch (current) {
        case null break traverse;
        case (?cid) {
          let node = getNode(state, cid);
          let nextId = node.next;
          // Swap prev and next
          state.nodes.add(cid, { node with prev = node.next; next = node.prev });
          current := nextId;
        };
      };
    };
    // Swap head and tail
    let oldHead = state.head;
    state.head := state.tail;
    state.tail := oldHead;
  };

  /// Remove every song and reset state to empty.
  public func clear(state : State) : () {
    state.songs.clear();
    state.nodes.clear();
    state.head := null;
    state.tail := null;
  };
};
