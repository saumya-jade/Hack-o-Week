import PlaylistLib "lib/playlist";
import PlaylistApi  "mixins/playlist-api";

actor {
  // ── Stable playlist state (doubly linked list) ───────────────────────────
  let playlistState = PlaylistLib.newState();

  // ── Expose playlist API ──────────────────────────────────────────────────
  include PlaylistApi(playlistState);
};
