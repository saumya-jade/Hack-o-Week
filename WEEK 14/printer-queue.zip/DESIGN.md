# Design Brief

## Direction

Printer Queue Dashboard — utility-first SaaS interface for managing print jobs with strict FIFO ordering and clear job state visibility.

## Tone

Professional and functional — minimal decoration, maximum clarity. Every visual element serves queue management, no flourish.

## Differentiation

Next-in-queue indicator uses a subtle green highlight; priority badges use color coding (red/yellow/green) for instant scan-ability.

## Color Palette

| Token | OKLCH | Role |
| --- | --- | --- |
| background | 0.972 0.004 250 | Off-white page background |
| foreground | 0.18 0.012 255 | High-contrast dark text |
| card | 1 0 0 | Pure white job cards |
| primary | 0.54 0.175 252 | Blue action buttons (Add/Print) |
| accent | 0.68 0.165 155 | Green success states and badges |
| muted | 0.95 0.005 252 | Light backgrounds for alternation |
| success | 0.65 0.18 145 | Completion indicator |
| warning | 0.72 0.15 85 | Amber for priority badges |
| destructive | 0.577 0.245 27.325 | Red for dequeue/danger |

## Typography

- Display: Plus Jakarta Sans — form labels, section headings
- Body: DM Sans — job list text, UI labels, timestamps
- Mono: Geist Mono — job IDs (when needed)
- Scale: labels `text-sm font-semibold`, body `text-base`, headers `text-lg font-semibold`

## Elevation & Depth

Minimal shadow hierarchy: card-level items use `shadow-sm` for separation from background; no elevation animation. Border used for visual containment instead of shadow.

## Structural Zones

| Zone | Background | Border | Notes |
| --- | --- | --- | --- |
| Header | muted/10% | border-bottom | Add Job form with inputs and submit button |
| Content | background | none | Queue list with alternating subtle card backgrounds |
| Job Card | card | border | Clear grid layout: ID, name, count, priority badge, time, action button |
| Next-to-Print | status-next | accent-border | Highlighted card shows which job will print next |

## Spacing & Rhythm

16px section gaps; 12px within card; 6px label-to-input spacing. Compact density with breathing room around interactive elements.

## Component Patterns

- Buttons: `rounded-md`, primary blue for actions, destructive red for dequeue, height `h-10`, padding `px-4`
- Input fields: `rounded-sm`, 2px border, focus ring blue
- Badges: color-coded by priority (Low=muted, Medium=warning amber, High=destructive red), `rounded-full`, `px-2 py-1 text-xs`
- Cards: 1px border, `rounded-sm`, 8px padding, white background

## Motion

Entrance: jobs fade in as they enter queue; Hover: button and card hover states with 0.2s transition; Dequeue: fade-out with ease-out 0.15s. No decorative animations.

## Constraints

- FIFO ordering is non-negotiable — no priority queue reordering
- Timestamps must show enqueue time, not wall-clock
- Each job needs visible dequeue button on its row
- Priority is a visual label only, does not affect queue order

## Signature Detail

The "next-in-queue" card has a soft green background (`oklch(0.97 0.08 155)`) with an accent border to provide immediate visual confirmation of which job will print first.
