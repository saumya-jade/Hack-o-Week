import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Toaster } from "@/components/ui/sonner";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  FileText,
  History,
  Inbox,
  Pause,
  Play,
  Printer,
  Trash2,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";
import { createActor } from "./backend";
import type { CompletedJob, PrintJob } from "./backend";

type Priority = "low" | "medium" | "high";

function priorityBadge(priority: string) {
  const p = priority.toLowerCase() as Priority;
  if (p === "high")
    return (
      <Badge className="bg-destructive/15 text-destructive border-destructive/30 font-semibold text-[11px] px-2 py-0.5 uppercase tracking-wide border">
        High
      </Badge>
    );
  if (p === "medium")
    return (
      <Badge className="bg-amber-100 text-amber-700 border-amber-300 font-semibold text-[11px] px-2 py-0.5 uppercase tracking-wide border">
        Medium
      </Badge>
    );
  return (
    <Badge className="bg-muted text-muted-foreground border-border font-semibold text-[11px] px-2 py-0.5 uppercase tracking-wide border">
      Low
    </Badge>
  );
}

function formatEnqueued(ts: bigint): string {
  const ms = Number(ts / 1_000_000n);
  const diff = Date.now() - ms;
  if (diff < 60_000) return "just now";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)} min ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)} hr ago`;
  return new Date(ms).toLocaleDateString();
}

function formatCompletedAt(ts: bigint): string {
  const ms = Number(ts / 1_000_000n);
  return new Date(ms).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatWaitTime(totalSeconds: number): string {
  if (totalSeconds <= 0) return "Next";
  if (totalSeconds < 60) return `${totalSeconds}s`;
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return secs > 0 ? `${mins}m ${secs}s` : `${mins}m`;
}

function calcEstWait(queue: PrintJob[], idx: number): string {
  if (idx === 0) return "Next";
  const totalPages = queue
    .slice(0, idx)
    .reduce((sum, j) => sum + Number(j.pageCount), 0);
  return formatWaitTime(totalPages);
}

const SKELETON_KEYS = ["sk-1", "sk-2", "sk-3", "sk-4"];

export default function App() {
  const { actor: rawActor, isFetching: actorLoading } = useActor(createActor);
  const actor = rawActor as unknown as {
    enqueueJob: (
      name: string,
      pages: bigint,
      priority: string,
    ) => Promise<PrintJob>;
    dequeueJob: () => Promise<PrintJob | null>;
    getQueue: () => Promise<PrintJob[]>;
    clearQueue: () => Promise<void>;
    getHistory: () => Promise<CompletedJob[]>;
    clearHistory: () => Promise<void>;
  } | null;

  const queryClient = useQueryClient();
  const [docName, setDocName] = useState("");
  const [pageCount, setPageCount] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [lastEnqueued, setLastEnqueued] = useState<{
    name: string;
    position: number;
  } | null>(null);
  const [isPaused, setIsPaused] = useState(false);

  const isReady = !!actor && !actorLoading;

  const { data: queue = [], isLoading: queueLoading } = useQuery<PrintJob[]>({
    queryKey: ["queue"],
    queryFn: () => actor!.getQueue(),
    enabled: isReady,
    refetchInterval: 5000,
  });

  const { data: historyJobs = [], isLoading: historyLoading } = useQuery<
    CompletedJob[]
  >({
    queryKey: ["history"],
    queryFn: () => actor!.getHistory(),
    enabled: isReady,
    refetchInterval: 5000,
  });

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ["queue"] });
    queryClient.invalidateQueries({ queryKey: ["history"] });
  };

  const { mutate: enqueue, isPending: enqueuing } = useMutation({
    mutationFn: () =>
      actor!.enqueueJob(
        docName.trim(),
        BigInt(Number.parseInt(pageCount, 10)),
        priority,
      ),
    onSuccess: (job) => {
      invalidateAll();
      const position = queue.length + 1;
      setLastEnqueued({ name: job.documentName, position });
      setDocName("");
      setPageCount("");
      setPriority("medium");
      toast.success(`Job #PQ-${job.id} added to queue at position ${position}`);
    },
    onError: () => toast.error("Failed to add print job"),
  });

  const { mutate: dequeue, isPending: dequeuing } = useMutation({
    mutationFn: () => actor!.dequeueJob(),
    onSuccess: (job) => {
      invalidateAll();
      setLastEnqueued(null);
      if (job) {
        toast.success(`Printed: ${job.documentName} (#PQ-${job.id})`);
      } else {
        toast.info("Queue is already empty");
      }
    },
    onError: () => toast.error("Failed to dequeue job"),
  });

  const { mutate: clearQueue, isPending: clearing } = useMutation({
    mutationFn: () => actor!.clearQueue(),
    onSuccess: () => {
      invalidateAll();
      setLastEnqueued(null);
      toast.success("Queue cleared");
    },
    onError: () => toast.error("Failed to clear queue"),
  });

  const { mutate: clearHistory, isPending: clearingHistory } = useMutation({
    mutationFn: () => actor!.clearHistory(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["history"] });
      toast.success("History cleared");
    },
    onError: () => toast.error("Failed to clear history"),
  });

  const isBusy = enqueuing || dequeuing || clearing || clearingHistory;

  const canSubmit =
    isReady &&
    !isBusy &&
    docName.trim().length > 0 &&
    Number.parseInt(pageCount, 10) > 0;

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Toaster richColors position="top-right" />

      {/* Sidebar */}
      <aside className="w-[220px] flex-shrink-0 bg-card border-r border-border flex flex-col">
        <div className="px-5 py-5 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-sm">
              <Printer className="w-4 h-4 text-primary-foreground" />
            </div>
            <span
              className="text-[17px] font-bold tracking-tight text-foreground"
              style={{ fontFamily: "var(--font-display)" }}
            >
              PrintQ
            </span>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {[
            { icon: Printer, label: "Queue", active: true, stub: false },
            { icon: History, label: "History", active: false, stub: false },
            { icon: AlertCircle, label: "Reports", active: false, stub: true },
          ].map(({ icon: Icon, label, active, stub }) => (
            <button
              type="button"
              key={label}
              data-ocid={`sidebar.${label.toLowerCase()}.link`}
              disabled={stub}
              title={stub ? "Coming soon" : undefined}
              onClick={
                !stub && label === "History"
                  ? () => {
                      document
                        .getElementById("history-section")
                        ?.scrollIntoView({ behavior: "smooth" });
                    }
                  : undefined
              }
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                active
                  ? "bg-secondary text-primary"
                  : stub
                    ? "text-muted-foreground/40 cursor-not-allowed"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
              {stub && (
                <span className="ml-auto text-[10px] font-semibold uppercase tracking-wide text-muted-foreground/50">
                  Soon
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-border">
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            © {new Date().getFullYear()}{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              className="hover:text-primary transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="bg-card border-b border-border flex items-center justify-between px-6 flex-shrink-0 h-14">
          <div>
            <h1
              className="text-[17px] font-bold text-foreground leading-tight"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Dashboard
            </h1>
            <p className="text-[12px] text-muted-foreground">
              Printer Job Queue
            </p>
          </div>
          <div className="flex items-center gap-3">
            {actorLoading && (
              <span className="text-xs text-muted-foreground animate-pulse">
                Connecting…
              </span>
            )}
            {/* Pause/Resume Toggle */}
            <Button
              variant="outline"
              size="sm"
              data-ocid="queue.pause_toggle.button"
              onClick={() => setIsPaused((p) => !p)}
              className={`h-8 px-3 text-xs font-semibold gap-1.5 transition-colors ${
                isPaused
                  ? "border-amber-400 bg-amber-50 text-amber-700 hover:bg-amber-100 hover:border-amber-500"
                  : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {isPaused ? (
                <>
                  <Play className="w-3.5 h-3.5" />
                  Resume
                </>
              ) : (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  Pause
                </>
              )}
            </Button>
            <Badge
              variant="secondary"
              className="text-xs font-semibold gap-1.5"
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${isReady ? "bg-accent" : "bg-muted-foreground"}`}
              />
              {queue.length} jobs
            </Badge>
          </div>
        </header>

        {/* Paused Banner */}
        <AnimatePresence>
          {isPaused && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              data-ocid="queue.paused.banner"
              className="overflow-hidden"
            >
              <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 flex items-center gap-2.5">
                <Pause className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <p className="text-[13px] font-semibold text-amber-700">
                  Queue is{" "}
                  <span className="uppercase tracking-wide">PAUSED</span> —
                  printing is disabled until you resume.
                </p>
                <button
                  type="button"
                  onClick={() => setIsPaused(false)}
                  className="ml-auto text-[12px] font-semibold text-amber-700 hover:text-amber-900 underline underline-offset-2 transition-colors"
                  data-ocid="queue.paused.resume_link"
                >
                  Resume now
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <main className="flex-1 overflow-auto p-6 space-y-6">
          {/* Add Job Form */}
          <section>
            <h2
              className="text-[15px] font-bold text-foreground mb-3"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Add New Print Job
            </h2>
            <div className="bg-card rounded-xl border border-border p-5 shadow-sm">
              <div className="grid grid-cols-[1fr_160px_200px_auto] gap-4 items-end">
                <div className="space-y-1.5">
                  <Label
                    htmlFor="doc-name"
                    className="text-[12px] font-semibold text-foreground"
                  >
                    Document Name
                  </Label>
                  <Input
                    id="doc-name"
                    data-ocid="form.doc_name.input"
                    placeholder="E.g., Quarterly Report.pdf"
                    value={docName}
                    onChange={(e) => setDocName(e.target.value)}
                    onKeyDown={(e) =>
                      e.key === "Enter" && canSubmit && enqueue()
                    }
                    disabled={isBusy || !isReady}
                    className="h-10 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label
                    htmlFor="page-count"
                    className="text-[12px] font-semibold text-foreground"
                  >
                    Page Count
                  </Label>
                  <Input
                    id="page-count"
                    data-ocid="form.page_count.input"
                    type="number"
                    min={1}
                    placeholder="12"
                    value={pageCount}
                    onChange={(e) => setPageCount(e.target.value)}
                    onKeyDown={(e) =>
                      e.key === "Enter" && canSubmit && enqueue()
                    }
                    disabled={isBusy || !isReady}
                    className="h-10 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[12px] font-semibold text-foreground">
                    Priority
                  </Label>
                  <Select
                    value={priority}
                    onValueChange={(v) => setPriority(v as Priority)}
                    disabled={isBusy || !isReady}
                  >
                    <SelectTrigger
                      className="h-10 text-sm"
                      data-ocid="form.priority.select"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low" data-ocid="form.priority.low">
                        Low
                      </SelectItem>
                      <SelectItem
                        value="medium"
                        data-ocid="form.priority.medium"
                      >
                        Medium
                      </SelectItem>
                      <SelectItem value="high" data-ocid="form.priority.high">
                        High
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  data-ocid="form.add_job.submit_button"
                  onClick={() => enqueue()}
                  disabled={!canSubmit}
                  className="h-10 px-6 font-semibold text-sm"
                >
                  {enqueuing ? "Adding…" : "Add Job"}
                </Button>
              </div>

              <AnimatePresence>
                {lastEnqueued && (
                  <motion.div
                    initial={{ opacity: 0, y: -4, height: 0 }}
                    animate={{ opacity: 1, y: 0, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="mt-3 flex items-center gap-2 text-[13px] text-accent font-medium"
                    data-ocid="form.enqueue.success_state"
                  >
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                    <span>
                      <strong>{lastEnqueued.name}</strong> added at position{" "}
                      <strong>#{lastEnqueued.position}</strong> in queue
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </section>

          {/* Print Queue */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2
                className="text-[15px] font-bold text-foreground"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Print Queue
              </h2>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs font-semibold">
                  {queue.length} pending
                </Badge>
                {queue.length > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 text-xs text-destructive border-destructive/30 hover:bg-destructive/5"
                    onClick={() => clearQueue()}
                    disabled={isBusy || !isReady}
                    data-ocid="queue.clear.button"
                  >
                    <Trash2 className="w-3 h-3 mr-1" />
                    Clear All
                  </Button>
                )}
              </div>
            </div>

            <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
              {/* Table Header */}
              {!queueLoading && queue.length > 0 && (
                <div className="grid grid-cols-[40px_1fr_110px_110px_110px_110px_150px] items-center gap-3 px-4 py-2.5 border-b border-border bg-muted/40">
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    #
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Document
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Job ID
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Pages
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Priority
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Est. Wait
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Enqueued
                  </span>
                </div>
              )}

              {queueLoading ? (
                <div className="p-4 space-y-3" data-ocid="queue.loading_state">
                  {SKELETON_KEYS.map((k) => (
                    <Skeleton key={k} className="h-16 w-full rounded-lg" />
                  ))}
                </div>
              ) : queue.length === 0 ? (
                <div
                  data-ocid="queue.empty_state"
                  className="flex flex-col items-center justify-center py-16 text-muted-foreground"
                >
                  <Inbox className="w-12 h-12 mb-3 opacity-20" />
                  <p className="text-sm font-semibold">Queue is empty</p>
                  <p className="text-xs mt-1 opacity-70">
                    Add a print job above to get started
                  </p>
                </div>
              ) : (
                <ScrollArea className="max-h-[400px]">
                  <AnimatePresence initial={false}>
                    {queue.map((job, idx) => {
                      const isFirst = idx === 0;
                      const estWait = calcEstWait(queue, idx);
                      return (
                        <motion.div
                          key={String(job.id)}
                          initial={{ opacity: 0, y: -6 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -20, height: 0 }}
                          transition={{ duration: 0.18, delay: idx * 0.03 }}
                          data-ocid={`queue.item.${idx + 1}`}
                          className={`grid grid-cols-[40px_1fr_110px_110px_110px_110px_150px] items-center gap-3 px-4 py-3.5 border-b border-border/60 last:border-b-0 transition-colors ${
                            isFirst
                              ? "bg-accent/5 border-l-4 border-l-accent"
                              : "hover:bg-muted/30"
                          }`}
                        >
                          {/* Position */}
                          <div className="flex flex-col items-center gap-0.5">
                            <span className="text-[13px] font-bold text-foreground font-mono">
                              {idx + 1}
                            </span>
                            {isFirst && (
                              <span className="text-[9px] font-bold text-accent uppercase tracking-wide leading-none">
                                next
                              </span>
                            )}
                          </div>

                          {/* Document Name */}
                          <div className="min-w-0">
                            {isFirst && (
                              <div className="flex items-center gap-1.5 mb-0.5">
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-accent uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 rounded-full bg-accent inline-block" />
                                  Next to print
                                </span>
                              </div>
                            )}
                            <p className="text-[13px] font-semibold text-foreground truncate">
                              {job.documentName}
                            </p>
                          </div>

                          {/* Job ID */}
                          <span className="text-[12px] font-mono text-muted-foreground font-medium">
                            #PQ-{String(job.id)}
                          </span>

                          {/* Page Count */}
                          <div className="flex items-center gap-1.5 text-[13px] text-foreground">
                            <FileText className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                            {String(job.pageCount)}p
                          </div>

                          {/* Priority Badge */}
                          <div data-ocid={`queue.priority.${idx + 1}`}>
                            {priorityBadge(job.priority)}
                          </div>

                          {/* Est. Wait */}
                          <div
                            className={`flex items-center gap-1 text-[12px] font-mono font-semibold ${
                              isFirst ? "text-accent" : "text-muted-foreground"
                            }`}
                            data-ocid={`queue.est_wait.${idx + 1}`}
                          >
                            <Clock className="w-3 h-3 flex-shrink-0" />
                            {estWait}
                          </div>

                          {/* Enqueued + Action */}
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[12px] text-muted-foreground truncate">
                              {formatEnqueued(job.enqueuedAt)}
                            </span>
                            {isFirst && (
                              <Button
                                size="sm"
                                variant="destructive"
                                className="h-7 px-3 text-xs font-semibold flex-shrink-0"
                                onClick={() => dequeue()}
                                disabled={isBusy || !isReady || isPaused}
                                data-ocid="queue.dequeue.button"
                                title={
                                  isPaused
                                    ? "Queue is paused — resume to print"
                                    : undefined
                                }
                              >
                                {dequeuing ? (
                                  "Printing…"
                                ) : (
                                  <>
                                    <Printer className="w-3 h-3 mr-1" />
                                    Print
                                  </>
                                )}
                              </Button>
                            )}
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </ScrollArea>
              )}
            </div>

            {queue.length > 1 && (
              <p className="text-[11px] text-muted-foreground mt-2 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                Jobs are processed in strict FIFO order — only the first job in
                the queue can be printed. Priority is a visual label only.
              </p>
            )}
          </section>

          <Separator className="my-2" />

          {/* History Section */}
          <section id="history-section" data-ocid="history.section">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h2
                  className="text-[15px] font-bold text-foreground"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Print History
                </h2>
                {historyJobs.length > 0 && (
                  <Badge variant="secondary" className="text-xs font-semibold">
                    {historyJobs.length} completed
                  </Badge>
                )}
              </div>
              {historyJobs.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs text-muted-foreground border-border/60 hover:bg-muted hover:text-foreground"
                  onClick={() => clearHistory()}
                  disabled={isBusy || !isReady}
                  data-ocid="history.clear.button"
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  Clear History
                </Button>
              )}
            </div>

            <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
              {/* History Table Header */}
              {!historyLoading && historyJobs.length > 0 && (
                <div className="grid grid-cols-[1fr_100px_110px_180px] items-center gap-3 px-4 py-2.5 border-b border-border bg-muted/40">
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Document
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Pages
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Priority
                  </span>
                  <span className="text-[11px] font-bold tracking-widest uppercase text-muted-foreground">
                    Completed At
                  </span>
                </div>
              )}

              {historyLoading ? (
                <div
                  className="p-4 space-y-3"
                  data-ocid="history.loading_state"
                >
                  {["h-sk-1", "h-sk-2"].map((k) => (
                    <Skeleton key={k} className="h-12 w-full rounded-lg" />
                  ))}
                </div>
              ) : historyJobs.length === 0 ? (
                <div
                  data-ocid="history.empty_state"
                  className="flex flex-col items-center justify-center py-12 text-muted-foreground"
                >
                  <History className="w-10 h-10 mb-3 opacity-20" />
                  <p className="text-sm font-semibold">No completed jobs yet</p>
                  <p className="text-xs mt-1 opacity-70">
                    Processed jobs will appear here
                  </p>
                </div>
              ) : (
                <ScrollArea className="max-h-[320px]">
                  <AnimatePresence initial={false}>
                    {historyJobs.slice(0, 20).map((job, idx) => (
                      <motion.div
                        key={String(job.id)}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.15, delay: idx * 0.02 }}
                        data-ocid={`history.item.${idx + 1}`}
                        className="grid grid-cols-[1fr_100px_110px_180px] items-center gap-3 px-4 py-3 border-b border-border/60 last:border-b-0 hover:bg-muted/20 transition-colors"
                      >
                        {/* Document Name */}
                        <div className="min-w-0 flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-accent flex-shrink-0" />
                          <span className="text-[13px] font-medium text-foreground truncate">
                            {job.documentName}
                          </span>
                        </div>

                        {/* Page Count */}
                        <div className="flex items-center gap-1 text-[13px] text-muted-foreground">
                          <FileText className="w-3.5 h-3.5 flex-shrink-0" />
                          {String(job.pageCount)}p
                        </div>

                        {/* Priority */}
                        <div>{priorityBadge(job.priority)}</div>

                        {/* Completed At */}
                        <div className="flex items-center gap-1 text-[12px] text-muted-foreground">
                          <Clock className="w-3 h-3 flex-shrink-0" />
                          {formatCompletedAt(job.completedAt)}
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </ScrollArea>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
