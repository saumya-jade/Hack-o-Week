import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface CompletedJob {
    id: bigint;
    completedAt: bigint;
    documentName: string;
    priority: string;
    enqueuedAt: bigint;
    pageCount: bigint;
}
export interface PrintJob {
    id: bigint;
    documentName: string;
    priority: string;
    enqueuedAt: bigint;
    pageCount: bigint;
}
export interface backendInterface {
    clearHistory(): Promise<void>;
    clearQueue(): Promise<void>;
    dequeueJob(): Promise<PrintJob | null>;
    enqueueJob(documentName: string, pageCount: bigint, priority: string): Promise<PrintJob>;
    getHistory(): Promise<Array<CompletedJob>>;
    getQueue(): Promise<Array<PrintJob>>;
}
