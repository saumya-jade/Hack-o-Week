import type { backendInterface, CompletedJob, PrintJob } from "../backend";

const mockQueue: PrintJob[] = [
  {
    id: BigInt(1),
    documentName: "Q4 Financial Report.pdf",
    priority: "high",
    enqueuedAt: BigInt((Date.now() - 120000) * 1_000_000),
    pageCount: BigInt(42),
  },
  {
    id: BigInt(2),
    documentName: "Employee Handbook.docx",
    priority: "medium",
    enqueuedAt: BigInt((Date.now() - 60000) * 1_000_000),
    pageCount: BigInt(18),
  },
  {
    id: BigInt(3),
    documentName: "Meeting Notes.txt",
    priority: "low",
    enqueuedAt: BigInt((Date.now() - 30000) * 1_000_000),
    pageCount: BigInt(3),
  },
];

let queue: PrintJob[] = [...mockQueue];
let history: CompletedJob[] = [
  {
    id: BigInt(101),
    documentName: "Project Proposal Draft.pdf",
    pageCount: BigInt(8),
    priority: "medium",
    enqueuedAt: BigInt((Date.now() - 900000) * 1_000_000),
    completedAt: BigInt((Date.now() - 600000) * 1_000_000),
  },
  {
    id: BigInt(100),
    documentName: "Budget Spreadsheet.xlsx",
    pageCount: BigInt(5),
    priority: "high",
    enqueuedAt: BigInt((Date.now() - 1800000) * 1_000_000),
    completedAt: BigInt((Date.now() - 1200000) * 1_000_000),
  },
];
let nextId = BigInt(4);

export const mockBackend: backendInterface = {
  getQueue: async () => [...queue],

  enqueueJob: async (documentName: string, pageCount: bigint, priority: string): Promise<PrintJob> => {
    const job: PrintJob = {
      id: nextId++,
      documentName,
      priority,
      enqueuedAt: BigInt(Date.now() * 1_000_000),
      pageCount,
    };
    queue.push(job);
    return job;
  },

  dequeueJob: async (): Promise<PrintJob | null> => {
    if (queue.length === 0) return null;
    const job = queue.shift()!;
    const completed: CompletedJob = {
      ...job,
      completedAt: BigInt(Date.now() * 1_000_000),
    };
    history.unshift(completed);
    if (history.length > 20) history = history.slice(0, 20);
    return job;
  },

  clearQueue: async (): Promise<void> => {
    queue = [];
  },

  getHistory: async (): Promise<CompletedJob[]> => [...history],

  clearHistory: async (): Promise<void> => {
    history = [];
  },
};
