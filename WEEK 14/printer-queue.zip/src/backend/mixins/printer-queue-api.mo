import Types "../types/printer-queue";
import PrinterQueueLib "../lib/printer-queue";
import Queue "mo:core/Queue";
import List "mo:core/List";
import Time "mo:core/Time";

mixin (queue : Queue.Queue<Types.PrintJob>, counter : Types.Counter, history : List.List<Types.CompletedJob>) {
  public func enqueueJob(documentName : Text, pageCount : Nat, priority : Text) : async Types.PrintJob {
    let id = counter.nextId;
    counter.nextId += 1;
    PrinterQueueLib.enqueue(queue, id, documentName, pageCount, priority, Time.now());
  };

  public func dequeueJob() : async ?Types.PrintJob {
    PrinterQueueLib.dequeue(queue, history, Time.now());
  };

  public query func getQueue() : async [Types.PrintJob] {
    queue.toArray();
  };

  public func clearQueue() : async () {
    queue.clear();
  };

  public query func getHistory() : async [Types.CompletedJob] {
    PrinterQueueLib.historyNewestFirst(history);
  };

  public func clearHistory() : async () {
    history.clear();
  };
};
