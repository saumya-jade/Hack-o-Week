module {
  public type PrintJob = {
    id : Nat;
    documentName : Text;
    pageCount : Nat;
    priority : Text;
    enqueuedAt : Int;
  };

  public type CompletedJob = {
    id : Nat;
    documentName : Text;
    pageCount : Nat;
    priority : Text;
    enqueuedAt : Int;
    completedAt : Int;
  };

  public type Counter = {
    var nextId : Nat;
  };
};
