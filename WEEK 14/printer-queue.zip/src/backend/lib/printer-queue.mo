import Types "../types/printer-queue";
import Queue "mo:core/Queue";
import List "mo:core/List";
import Array "mo:core/Array";

module {
  public type PrintJob = Types.PrintJob;
  public type CompletedJob = Types.CompletedJob;

  let MAX_HISTORY : Nat = 50;

  public func enqueue(
    queue : Queue.Queue<PrintJob>,
    nextId : Nat,
    documentName : Text,
    pageCount : Nat,
    priority : Text,
    now : Int,
  ) : PrintJob {
    let job : PrintJob = {
      id = nextId;
      documentName;
      pageCount;
      priority;
      enqueuedAt = now;
    };
    queue.pushBack(job);
    job;
  };

  public func dequeue(
    queue : Queue.Queue<PrintJob>,
    history : List.List<CompletedJob>,
    now : Int,
  ) : ?PrintJob {
    switch (queue.popFront()) {
      case null null;
      case (?job) {
        let completed : CompletedJob = {
          id = job.id;
          documentName = job.documentName;
          pageCount = job.pageCount;
          priority = job.priority;
          enqueuedAt = job.enqueuedAt;
          completedAt = now;
        };
        // Append newest entry; trim oldest if over limit
        history.add(completed);
        if (history.size() > MAX_HISTORY) {
          // Drop the oldest entry (index 0) by slicing from index 1
          let kept = history.sliceToArray(1, history.size().toInt());
          history.clear();
          history.addAll(kept.values());
        };
        ?job;
      };
    };
  };

  public func toArray(queue : Queue.Queue<PrintJob>) : [PrintJob] {
    queue.toArray();
  };

  public func historyNewestFirst(history : List.List<CompletedJob>) : [CompletedJob] {
    history.toArray().reverse();
  };
};
