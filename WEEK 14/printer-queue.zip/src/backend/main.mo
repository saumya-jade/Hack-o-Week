import Queue "mo:core/Queue";
import List "mo:core/List";
import Types "types/printer-queue";
import PrinterQueueMixin "mixins/printer-queue-api";

actor {
  let queue = Queue.empty<Types.PrintJob>();
  let counter : Types.Counter = { var nextId = 0 };
  let history = List.empty<Types.CompletedJob>();

  include PrinterQueueMixin(queue, counter, history);
};
