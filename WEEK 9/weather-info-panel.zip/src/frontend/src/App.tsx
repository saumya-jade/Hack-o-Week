import { Input } from "@/components/ui/input";
import { Clock, Droplets, Search, Thermometer, Wind, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";

type WeatherCondition = "sunny" | "cloudy" | "rainy";

interface CityWeather {
  city: string;
  country: string;
  flag: string;
  tempC: number;
  tempF: number;
  feelsLikeC: number;
  condition: WeatherCondition;
  conditionLabel: string;
  emoji: string;
  humidity: number;
  windKph: number;
}

const CITIES: CityWeather[] = [
  {
    city: "New York",
    country: "USA",
    flag: "🇺🇸",
    tempC: 18,
    tempF: 64,
    feelsLikeC: 16,
    condition: "cloudy",
    conditionLabel: "Partly Cloudy",
    emoji: "⛅",
    humidity: 62,
    windKph: 14,
  },
  {
    city: "London",
    country: "UK",
    flag: "🇬🇧",
    tempC: 9,
    tempF: 48,
    feelsLikeC: 6,
    condition: "rainy",
    conditionLabel: "Heavy Rain",
    emoji: "🌧️",
    humidity: 85,
    windKph: 22,
  },
  {
    city: "Tokyo",
    country: "Japan",
    flag: "🇯🇵",
    tempC: 24,
    tempF: 75,
    feelsLikeC: 25,
    condition: "sunny",
    conditionLabel: "Sunny",
    emoji: "☀️",
    humidity: 55,
    windKph: 8,
  },
  {
    city: "Paris",
    country: "France",
    flag: "🇫🇷",
    tempC: 14,
    tempF: 57,
    feelsLikeC: 12,
    condition: "cloudy",
    conditionLabel: "Partly Cloudy",
    emoji: "⛅",
    humidity: 70,
    windKph: 16,
  },
  {
    city: "Sydney",
    country: "Australia",
    flag: "🇦🇺",
    tempC: 27,
    tempF: 81,
    feelsLikeC: 28,
    condition: "sunny",
    conditionLabel: "Sunny",
    emoji: "☀️",
    humidity: 48,
    windKph: 11,
  },
  {
    city: "Dubai",
    country: "UAE",
    flag: "🇦🇪",
    tempC: 38,
    tempF: 100,
    feelsLikeC: 42,
    condition: "sunny",
    conditionLabel: "Blazing Sun",
    emoji: "☀️",
    humidity: 30,
    windKph: 9,
  },
  {
    city: "Toronto",
    country: "Canada",
    flag: "🇨🇦",
    tempC: 5,
    tempF: 41,
    feelsLikeC: 1,
    condition: "rainy",
    conditionLabel: "Light Rain",
    emoji: "🌧️",
    humidity: 78,
    windKph: 19,
  },
  {
    city: "Mumbai",
    country: "India",
    flag: "🇮🇳",
    tempC: 32,
    tempF: 90,
    feelsLikeC: 36,
    condition: "cloudy",
    conditionLabel: "Hazy Sun",
    emoji: "🌤️",
    humidity: 72,
    windKph: 13,
  },
  {
    city: "São Paulo",
    country: "Brazil",
    flag: "🇧🇷",
    tempC: 22,
    tempF: 72,
    feelsLikeC: 23,
    condition: "cloudy",
    conditionLabel: "Partly Cloudy",
    emoji: "⛅",
    humidity: 68,
    windKph: 10,
  },
];

const conditionAccent: Record<
  WeatherCondition,
  { label: string; dot: string }
> = {
  sunny: { label: "text-amber-300", dot: "bg-amber-400" },
  rainy: { label: "text-sky-300", dot: "bg-sky-400" },
  cloudy: { label: "text-slate-300", dot: "bg-slate-400" },
};

const conditionCard: Record<WeatherCondition, string> = {
  sunny: "glass-card-sunny",
  rainy: "glass-card-rainy",
  cloudy: "glass-card-cloudy",
};

function StatPill({
  icon,
  value,
  label,
}: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="stat-pill flex items-center gap-1.5 px-3 py-1.5">
      <span className="text-muted-foreground">{icon}</span>
      <div>
        <div className="text-xs font-semibold text-foreground leading-tight">
          {value}
        </div>
        <div className="text-[10px] text-muted-foreground leading-tight">
          {label}
        </div>
      </div>
    </div>
  );
}

function WeatherCard({
  data,
  index,
  marker,
}: { data: CityWeather; index: number; marker: string }) {
  const accent = conditionAccent[data.condition];
  const cardClass = conditionCard[data.condition];

  return (
    <motion.article
      data-ocid={marker}
      className={`${cardClass} rounded-2xl p-6 flex flex-col gap-5 relative overflow-hidden`}
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20, scale: 0.96 }}
      transition={{
        duration: 0.5,
        delay: index * 0.07,
        ease: [0.25, 0.46, 0.45, 0.94],
      }}
      whileHover={{ scale: 1.015, transition: { duration: 0.2 } }}
      layout
    >
      {/* Subtle radial glow behind emoji */}
      <div
        className="absolute -top-8 -right-8 w-40 h-40 rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{
          background:
            data.condition === "sunny"
              ? "oklch(0.82 0.20 75)"
              : data.condition === "rainy"
                ? "oklch(0.62 0.18 230)"
                : "oklch(0.70 0.08 260)",
        }}
      />

      {/* Header */}
      <div className="flex items-start justify-between relative z-10">
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-xl">{data.flag}</span>
            <h2 className="font-display text-xl font-bold text-foreground tracking-tight">
              {data.city}
            </h2>
          </div>
          <p className="text-sm text-muted-foreground font-body pl-8">
            {data.country}
          </p>
        </div>
        <motion.div
          className="text-5xl leading-none select-none"
          animate={{ y: [0, -6, 0] }}
          transition={{
            duration: 4,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            delay: index * 0.8,
          }}
        >
          {data.emoji}
        </motion.div>
      </div>

      {/* Temperature */}
      <div className="relative z-10">
        <div className="flex items-end gap-3">
          <span className="font-display text-6xl font-bold text-foreground leading-none tracking-tighter">
            {data.tempC}°
          </span>
          <div className="pb-1">
            <span className="text-2xl font-display font-light text-muted-foreground">
              C
            </span>
            <span className="text-muted-foreground mx-1">/</span>
            <span className="text-lg font-body text-muted-foreground">
              {data.tempF}°F
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 mt-2">
          <span
            className={`inline-block w-1.5 h-1.5 rounded-full ${accent.dot}`}
          />
          <span className={`text-sm font-semibold font-body ${accent.label}`}>
            {data.conditionLabel}
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap gap-2 relative z-10">
        <StatPill
          icon={<Droplets size={13} />}
          value={`${data.humidity}%`}
          label="Humidity"
        />
        <StatPill
          icon={<Wind size={13} />}
          value={`${data.windKph} km/h`}
          label="Wind"
        />
        <StatPill
          icon={<Thermometer size={13} />}
          value={`${data.feelsLikeC}°C`}
          label="Feels like"
        />
      </div>
    </motion.article>
  );
}

export default function App() {
  const year = new Date().getFullYear();
  const hostname =
    typeof window !== "undefined" ? window.location.hostname : "";
  const caffeineUrl = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(hostname)}`;

  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = query.trim()
    ? CITIES.filter(
        (c) =>
          c.city.toLowerCase().includes(query.toLowerCase()) ||
          c.country.toLowerCase().includes(query.toLowerCase()),
      )
    : CITIES;

  function toggleSearch() {
    if (searchOpen) {
      setQuery("");
    }
    setSearchOpen((prev) => !prev);
  }

  return (
    <div className="bg-atmosphere min-h-screen flex flex-col">
      <div className="flex-1 relative z-10">
        {/* Header */}
        <header className="pt-12 pb-2 px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-5">
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Live Conditions
              </span>
              <motion.span
                className="inline-block w-1.5 h-1.5 rounded-full bg-primary"
                animate={{ opacity: [1, 0.3, 1] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
              />
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-foreground tracking-tight leading-tight mb-2">
              World Weather
            </h1>
            <p className="text-muted-foreground font-body text-base">
              Atmospheric conditions across global cities
            </p>
          </motion.div>
        </header>

        {/* Search Toggle Row */}
        <motion.div
          className="flex justify-center items-center mt-4 mb-2 px-4 gap-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.35, duration: 0.5 }}
        >
          {/* Animated search bar */}
          <AnimatePresence>
            {searchOpen && (
              <motion.div
                key="search-bar"
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: "clamp(200px, 40vw, 360px)", opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="overflow-hidden"
              >
                <div className="relative">
                  <Search
                    size={14}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
                  />
                  <Input
                    data-ocid="search.search_input"
                    autoFocus
                    placeholder="Search city or country…"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="pl-8 pr-4 py-2 h-9 bg-input/70 border-border text-sm font-body placeholder:text-muted-foreground focus-visible:ring-primary/60 rounded-full"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Toggle button */}
          <button
            type="button"
            data-ocid="search.toggle"
            onClick={toggleSearch}
            aria-label={searchOpen ? "Close search" : "Open search"}
            className="inline-flex items-center justify-center w-9 h-9 rounded-full stat-pill text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
          >
            <AnimatePresence mode="wait" initial={false}>
              {searchOpen ? (
                <motion.span
                  key="close"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <X size={15} />
                </motion.span>
              ) : (
                <motion.span
                  key="search"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Search size={15} />
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </motion.div>

        {/* Last Updated */}
        <motion.div
          className="flex justify-center mt-2 mb-8 px-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full stat-pill">
            <Clock size={13} className="text-muted-foreground" />
            <span className="text-xs text-muted-foreground font-body">
              Last updated:{" "}
              <span className="text-foreground font-medium">
                Wed, Mar 11, 2026, 10:00 AM
              </span>
            </span>
          </div>
        </motion.div>

        {/* Cards Grid */}
        <main>
          <section
            data-ocid="weather.section"
            className="max-w-5xl mx-auto px-4 pb-16"
          >
            <AnimatePresence mode="popLayout">
              {filtered.length === 0 ? (
                <motion.div
                  key="empty"
                  data-ocid="weather.empty_state"
                  className="flex flex-col items-center justify-center py-20 gap-4"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -16 }}
                  transition={{ duration: 0.35 }}
                >
                  <div className="text-5xl">🔍</div>
                  <p className="font-display text-xl text-foreground font-semibold">
                    No cities found
                  </p>
                  <p className="text-sm text-muted-foreground font-body">
                    Try a different city or country name.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="grid"
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
                  layout
                >
                  {filtered.map((city, i) => (
                    <WeatherCard
                      key={city.city}
                      data={city}
                      index={i}
                      marker={`weather.card.${i + 1}`}
                    />
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        </main>
      </div>

      {/* Footer */}
      <footer className="relative z-10 py-6 text-center border-t border-border">
        <p className="text-xs text-muted-foreground font-body">
          © {year}. Built with ❤️ using{" "}
          <a
            href={caffeineUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
