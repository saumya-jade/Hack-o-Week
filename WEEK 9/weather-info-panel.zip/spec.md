# Weather Info Panel

## Current State
A static weather panel displaying three fixed cities (New York, London, Tokyo) with weather cards showing temperature, humidity, wind, and feels-like data. No search or filtering functionality.

## Requested Changes (Diff)

### Add
- A search toggle/bar at the top of the page that lets users type a city name
- Filter the displayed weather cards based on search input (show only matching cities)
- Show an empty state if no cities match the search
- Expand the city data to include more cities so search is more meaningful

### Modify
- App layout to include search input above the cards grid

### Remove
- Nothing removed

## Implementation Plan
1. Expand CITIES array with more cities (e.g. Paris, Sydney, Dubai, Toronto, Mumbai, São Paulo)
2. Add search state with useState
3. Add a search input with toggle (icon button to show/hide) or always-visible input bar
4. Filter CITIES by search query (case-insensitive match on city name or country)
5. Show empty state card when no results match
6. Add data-ocid markers on search input and toggle button
