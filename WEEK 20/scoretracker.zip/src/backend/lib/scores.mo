import List "mo:core/List";
import Array "mo:core/Array";
import Nat "mo:core/Nat";
import Types "../types/scores";

module {
  /// Add a new score entry to the list
  public func addScore(
    entries : List.List<Types.ScoreEntry>,
    subject : Text,
    score : Nat,
    timestamp : Int,
  ) {
    entries.add({ subject; score; timestamp });
  };

  /// Remove the entry at the given index; traps if index is out of bounds
  public func deleteScore(entries : List.List<Types.ScoreEntry>, index : Nat) {
    let size = entries.size();
    if (index >= size) Runtime.trap("index out of bounds");
    // Rebuild list skipping the target index via linear traversal
    let tmp = entries.toArray();
    entries.clear();
    for (i in Nat.range(0, size)) {
      if (i != index) entries.add(tmp[i]);
    };
  };

  /// Remove all entries
  public func clearScores(entries : List.List<Types.ScoreEntry>) {
    entries.clear();
  };

  /// Return all entries as an immutable array in chronological order
  public func getScores(entries : List.List<Types.ScoreEntry>) : [Types.ScoreEntry] {
    entries.toArray();
  };

  /// Compute min, max, mean via a single linear traversal; returns null when empty
  public func computeStats(entries : List.List<Types.ScoreEntry>) : ?Types.Stats {
    let size = entries.size();
    if (size == 0) return null;

    var minVal : Nat = entries.at(0).score;
    var maxVal : Nat = entries.at(0).score;
    var sum : Nat = 0;

    entries.forEach(func(e) {
      if (e.score < minVal) minVal := e.score;
      if (e.score > maxVal) maxVal := e.score;
      sum += e.score;
    });

    let mean : Float = sum.toFloat() / size.toFloat();

    ?{ min = minVal; max = maxVal; mean; count = size };
  };

  /// Build a 101-element frequency array via linear traversal (index = score, value = count)
  public func computeFrequency(entries : List.List<Types.ScoreEntry>) : Types.FrequencyArray {
    let freq : [var Nat] = Array.repeat(0, 101).toVarArray<Nat>();
    entries.forEach(func(e) {
      if (e.score <= 100) {
        freq[e.score] += 1;
      };
    });
    Array.tabulate(101, func(i : Nat) : Nat { freq[i] });
  };
};
