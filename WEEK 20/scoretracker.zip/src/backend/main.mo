import List "mo:core/List";
import Types "types/scores";
import ScoresApi "mixins/scores-api";

actor {
  let entries = List.empty<Types.ScoreEntry>();

  include ScoresApi(entries);
};
