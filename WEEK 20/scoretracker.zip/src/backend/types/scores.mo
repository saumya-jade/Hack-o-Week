module {
  /// A single exam score entry
  public type ScoreEntry = {
    subject : Text;
    score : Nat;      // 0-100
    timestamp : Int;  // nanoseconds since epoch
  };

  /// Statistics computed via linear traversal over all entries
  public type Stats = {
    min : Nat;
    max : Nat;
    mean : Float;
    count : Nat;
  };

  /// Frequency array: index = score value (0-100), element = count of entries with that score
  public type FrequencyArray = [Nat]; // length 101
};
