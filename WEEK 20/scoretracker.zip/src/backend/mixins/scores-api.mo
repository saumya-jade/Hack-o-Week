import List "mo:core/List";
import Time "mo:core/Time";
import ScoresLib "../lib/scores";
import Types "../types/scores";

mixin (entries : List.List<Types.ScoreEntry>) {
  /// Add a new exam score entry with the current timestamp
  public shared func addScore(subject : Text, score : Nat) : async () {
    ScoresLib.addScore(entries, subject, score, Time.now());
  };

  /// Delete the score entry at the given index
  public shared func deleteScore(index : Nat) : async () {
    ScoresLib.deleteScore(entries, index);
  };

  /// Clear all score entries
  public shared func clearScores() : async () {
    ScoresLib.clearScores(entries);
  };

  /// Return all entries in chronological order
  public query func getScores() : async [Types.ScoreEntry] {
    ScoresLib.getScores(entries);
  };

  /// Return computed statistics (null when no scores exist)
  public query func getStats() : async ?Types.Stats {
    ScoresLib.computeStats(entries);
  };

  /// Return the frequency array (index 0-100 → occurrence count)
  public query func getFrequency() : async Types.FrequencyArray {
    ScoresLib.computeFrequency(entries);
  };
};
