import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { FrequencyEntry } from "@/types/scores";
import { BarChart2 } from "lucide-react";

interface FrequencyTableProps {
  frequencyEntries: FrequencyEntry[];
  modes: number[];
  isLoading: boolean;
}

function getGradeLabel(score: number): string {
  if (score >= 90) return "A";
  if (score >= 80) return "B";
  if (score >= 70) return "C";
  if (score >= 60) return "D";
  return "F";
}

export function FrequencyTable({
  frequencyEntries,
  modes,
  isLoading,
}: FrequencyTableProps) {
  const modeSet = new Set(modes);
  const maxCount = frequencyEntries.reduce((m, e) => Math.max(m, e.count), 0);

  return (
    <Card className="border shadow-sm" data-ocid="frequency_table.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-display flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-primary" />
          Score Distribution (Frequency)
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div
            className="px-6 py-4 space-y-2"
            data-ocid="frequency_table.loading_state"
          >
            {[0, 1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-8 rounded" />
            ))}
          </div>
        ) : frequencyEntries.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-12 text-center"
            data-ocid="frequency_table.empty_state"
          >
            <BarChart2 className="w-10 h-10 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground text-sm">
              No frequency data yet
            </p>
            <p className="text-muted-foreground/60 text-xs mt-1">
              Add scores to see distribution
            </p>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto" data-ocid="frequency_table.table">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40">
                    <th className="text-left px-5 py-2.5 font-semibold text-muted-foreground text-xs uppercase tracking-wide">
                      Score
                    </th>
                    <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase tracking-wide">
                      Grade
                    </th>
                    <th className="text-right px-5 py-2.5 font-semibold text-muted-foreground text-xs uppercase tracking-wide">
                      Count
                    </th>
                    <th className="px-5 py-2.5 font-semibold text-muted-foreground text-xs uppercase tracking-wide w-28">
                      Frequency
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {frequencyEntries.map((entry, idx) => {
                    const isMode = modeSet.has(entry.score);
                    const barPct =
                      maxCount > 0 ? (entry.count / maxCount) * 100 : 0;
                    return (
                      <tr
                        key={entry.score}
                        className={`border-b last:border-0 transition-colors ${
                          isMode
                            ? "bg-amber-50 hover:bg-amber-100/60"
                            : idx % 2 === 1
                              ? "bg-muted/30 hover:bg-muted/50"
                              : "hover:bg-muted/20"
                        }`}
                        data-ocid={`frequency_table.row.${idx + 1}`}
                      >
                        <td className="px-5 py-3">
                          {isMode ? (
                            <Badge className="bg-amber-100 text-amber-700 border border-amber-300 hover:bg-amber-100 tabular-nums font-bold">
                              {entry.score}
                            </Badge>
                          ) : (
                            <span className="tabular-nums font-semibold text-foreground">
                              {entry.score}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                              isMode
                                ? "text-amber-700"
                                : "text-muted-foreground"
                            }`}
                          >
                            {getGradeLabel(entry.score)}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-right tabular-nums font-medium">
                          {isMode ? (
                            <span className="text-amber-700 font-bold">
                              {entry.count}
                            </span>
                          ) : (
                            entry.count
                          )}
                        </td>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-500 ${
                                  isMode ? "bg-amber-400" : "bg-primary/60"
                                }`}
                                style={{ width: `${barPct}%` }}
                              />
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="px-5 py-3 border-t bg-muted/20 flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                Array-based method ·{" "}
                <span className="font-semibold text-primary">
                  101-element array
                </span>{" "}
                · linear traversal O(n)
              </p>
              {modes.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  Mode:{" "}
                  <span className="text-amber-600 font-bold">
                    {modes.join(", ")}
                  </span>
                </p>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
