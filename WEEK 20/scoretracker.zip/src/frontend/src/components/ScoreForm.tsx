import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlusCircle } from "lucide-react";
import { useState } from "react";

interface ScoreFormProps {
  onAdd: (subject: string, score: number) => void;
  isAdding: boolean;
}

interface FormErrors {
  subject?: string;
  score?: string;
}

export function ScoreForm({ onAdd, isAdding }: ScoreFormProps) {
  const [subject, setSubject] = useState("");
  const [scoreVal, setScoreVal] = useState("");
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<{
    subject?: boolean;
    score?: boolean;
  }>({});

  function validate(s: string, v: string): FormErrors {
    const e: FormErrors = {};
    if (!s.trim()) e.subject = "Subject name is required";
    const n = Number.parseInt(v, 10);
    if (v === "") {
      e.score = "Score is required";
    } else if (Number.isNaN(n) || n < 0 || n > 100) {
      e.score = "Score must be between 0 and 100";
    }
    return e;
  }

  function handleBlurSubject() {
    setTouched((t) => ({ ...t, subject: true }));
    setErrors((prev) => ({ ...prev, ...validate(subject, scoreVal) }));
  }

  function handleBlurScore() {
    setTouched((t) => ({ ...t, score: true }));
    setErrors((prev) => ({ ...prev, ...validate(subject, scoreVal) }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const newErrors = validate(subject, scoreVal);
    setErrors(newErrors);
    setTouched({ subject: true, score: true });
    if (Object.keys(newErrors).length > 0) return;
    onAdd(subject.trim(), Number.parseInt(scoreVal, 10));
    setSubject("");
    setScoreVal("");
    setErrors({});
    setTouched({});
  }

  return (
    <Card className="border shadow-sm" data-ocid="add_entry.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-display flex items-center gap-2">
          <PlusCircle className="w-5 h-5 text-primary" />
          Add New Exam Entry
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="subject" className="text-sm font-medium">
              Exam Name
            </Label>
            <Input
              id="subject"
              placeholder="e.g. History 101"
              value={subject}
              onChange={(e) => {
                setSubject(e.target.value);
                if (touched.subject) {
                  setErrors((prev) => ({
                    ...prev,
                    ...validate(e.target.value, scoreVal),
                  }));
                }
              }}
              onBlur={handleBlurSubject}
              data-ocid="add_entry.subject_input"
              className={`bg-input/60 ${touched.subject && errors.subject ? "border-destructive focus-visible:ring-destructive" : ""}`}
              aria-describedby={
                touched.subject && errors.subject ? "subject-error" : undefined
              }
              aria-invalid={!!(touched.subject && errors.subject)}
            />
            {touched.subject && errors.subject && (
              <p
                id="subject-error"
                className="text-xs text-destructive flex items-center gap-1 mt-1"
                data-ocid="add_entry.subject_input.field_error"
              >
                {errors.subject}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="score" className="text-sm font-medium">
              Score (0–100)
            </Label>
            <Input
              id="score"
              type="number"
              min={0}
              max={100}
              placeholder="e.g. 88"
              value={scoreVal}
              onChange={(e) => {
                setScoreVal(e.target.value);
                if (touched.score) {
                  setErrors((prev) => ({
                    ...prev,
                    ...validate(subject, e.target.value),
                  }));
                }
              }}
              onBlur={handleBlurScore}
              data-ocid="add_entry.score_input"
              className={`bg-input/60 ${touched.score && errors.score ? "border-destructive focus-visible:ring-destructive" : ""}`}
              aria-describedby={
                touched.score && errors.score ? "score-error" : undefined
              }
              aria-invalid={!!(touched.score && errors.score)}
            />
            {touched.score && errors.score && (
              <p
                id="score-error"
                className="text-xs text-destructive flex items-center gap-1 mt-1"
                data-ocid="add_entry.score_input.field_error"
              >
                {errors.score}
              </p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full font-semibold"
            disabled={isAdding}
            data-ocid="add_entry.submit_button"
          >
            {isAdding ? "Adding…" : "Add Entry"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
