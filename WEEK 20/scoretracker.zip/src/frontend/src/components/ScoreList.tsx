import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { ScoreEntry } from "@/types/scores";
import {
  BookMarked,
  BookOpen,
  Calculator,
  FlaskConical,
  Globe,
  History,
  Trash2,
} from "lucide-react";

const SUBJECT_ICONS: Record<string, React.ReactNode> = {
  Math: <Calculator className="w-4 h-4" />,
  English: <BookOpen className="w-4 h-4" />,
  Science: <FlaskConical className="w-4 h-4" />,
  History: <History className="w-4 h-4" />,
  Geography: <Globe className="w-4 h-4" />,
};

function getSubjectIcon(subject: string) {
  return SUBJECT_ICONS[subject] ?? <BookMarked className="w-4 h-4" />;
}

function formatDate(ts: bigint) {
  const ms = Number(ts / 1_000_000n);
  if (ms === 0 || Number.isNaN(ms)) return "—";
  return new Date(ms).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function getGradeBadgeClass(score: number): string {
  if (score >= 90) return "bg-primary/15 text-primary border-primary/30";
  if (score >= 80) return "bg-emerald-100 text-emerald-700 border-emerald-200";
  if (score >= 70)
    return "bg-secondary/30 text-secondary-foreground border-secondary/40";
  if (score >= 60) return "bg-amber-100 text-amber-700 border-amber-200";
  return "bg-destructive/10 text-destructive border-destructive/20";
}

interface ScoreListProps {
  scores: ScoreEntry[];
  modes: number[];
  isLoading: boolean;
  isClearing: boolean;
  onDelete: (index: number, subject: string) => void;
  onClear: () => void;
}

export function ScoreList({
  scores,
  modes,
  isLoading,
  isClearing,
  onDelete,
  onClear,
}: ScoreListProps) {
  const modeSet = new Set(modes);

  return (
    <Card className="border shadow-sm" data-ocid="score_list.card">
      <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
        <CardTitle className="text-lg font-display flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" />
          Exam Score List
        </CardTitle>
        {scores.length > 0 && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="text-destructive hover:text-destructive hover:bg-destructive/10 text-xs h-8"
                disabled={isClearing}
                data-ocid="score_list.clear_button"
              >
                {isClearing ? "Clearing…" : "Clear All"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent data-ocid="score_list.clear_dialog">
              <AlertDialogHeader>
                <AlertDialogTitle>Clear all scores?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all {scores.length} score
                  {scores.length !== 1 ? "s" : ""}. This action cannot be
                  undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel data-ocid="score_list.clear_cancel_button">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={onClear}
                  className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                  data-ocid="score_list.clear_confirm_button"
                >
                  Clear All
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div
            className="px-6 py-4 space-y-3"
            data-ocid="score_list.loading_state"
          >
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-12 rounded-lg" />
            ))}
          </div>
        ) : scores.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-12 text-center"
            data-ocid="score_list.empty_state"
          >
            <BookOpen className="w-10 h-10 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground font-medium">No scores yet</p>
            <p className="text-muted-foreground/70 text-sm mt-1">
              Add your first exam entry above
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {scores.map((entry, idx) => {
              const isMode = modeSet.has(entry.score);
              return (
                <div
                  key={`${entry.subject}-${entry.timestamp.toString()}`}
                  className={`flex items-center gap-3 px-5 py-3.5 transition-smooth hover:bg-muted/20 ${
                    idx % 2 === 1 ? "bg-muted/30" : ""
                  }`}
                  data-ocid={`score_list.item.${idx + 1}`}
                >
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                    {getSubjectIcon(entry.subject)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">
                      {entry.subject}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(entry.timestamp)}
                    </p>
                  </div>
                  {isMode ? (
                    <Badge
                      className="tabular-nums font-bold text-sm border bg-amber-100 text-amber-700 border-amber-300 hover:bg-amber-100"
                      data-ocid={`score_list.mode_badge.${idx + 1}`}
                    >
                      {entry.score}
                    </Badge>
                  ) : (
                    <Badge
                      variant="outline"
                      className={`tabular-nums font-bold text-sm border ${getGradeBadgeClass(entry.score)}`}
                    >
                      {entry.score}
                    </Badge>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-10 h-10 text-destructive/60 hover:text-destructive hover:bg-destructive/10 flex-shrink-0"
                    onClick={() => onDelete(idx, entry.subject)}
                    aria-label={`Delete score for ${entry.subject}`}
                    data-ocid={`score_list.delete_button.${idx + 1}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
