import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { Stats } from "@/types/scores";
import {
  ArrowDownUp,
  ArrowUpDown,
  BarChart2,
  TrendingUp,
  Users,
} from "lucide-react";

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  amber?: boolean;
  teal?: boolean;
}

function StatCard({ icon, label, value, amber, teal }: StatCardProps) {
  const borderCls = amber
    ? "border-amber-200 bg-amber-50"
    : teal
      ? "border-primary/20 bg-primary/5"
      : "border-border bg-card";

  const iconBg = amber ? "bg-amber-500" : "bg-primary";

  const textCls = amber
    ? "text-amber-700"
    : teal
      ? "text-primary"
      : "text-foreground";

  return (
    <div
      className={`flex items-center gap-3 rounded-xl border p-4 ${borderCls}`}
    >
      <div
        className={`flex items-center justify-center w-10 h-10 rounded-lg text-primary-foreground flex-shrink-0 ${iconBg}`}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
          {label}
        </p>
        <p className={`text-2xl font-bold font-display truncate ${textCls}`}>
          {value}
        </p>
      </div>
    </div>
  );
}

interface StatsPanelProps {
  stats: Stats | null;
  modes: number[];
  isLoading: boolean;
}

export function StatsPanel({ stats, modes, isLoading }: StatsPanelProps) {
  return (
    <Card className="border shadow-sm" data-ocid="stats.card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-display flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          Statistics Panel
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div
            className="grid grid-cols-2 gap-3"
            data-ocid="stats.loading_state"
          >
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        ) : !stats ? (
          <div
            className="flex flex-col items-center justify-center h-32 text-center"
            data-ocid="stats.empty_state"
          >
            <BarChart2 className="w-8 h-8 text-muted-foreground/40 mb-2" />
            <p className="text-muted-foreground text-sm">
              Add scores to see statistics
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3" data-ocid="stats.grid">
            <StatCard
              icon={<ArrowDownUp className="w-5 h-5" />}
              label="Minimum"
              value={stats.min}
              teal
            />
            <StatCard
              icon={<ArrowUpDown className="w-5 h-5" />}
              label="Maximum"
              value={stats.max}
              teal
            />
            <StatCard
              icon={<BarChart2 className="w-5 h-5" />}
              label="Mean"
              value={stats.mean.toFixed(1)}
              teal
            />
            <StatCard
              icon={<Users className="w-5 h-5" />}
              label="Mode"
              value={
                modes.length > 0 ? (
                  <span
                    title={`Mode score${modes.length > 1 ? "s" : ""}: ${modes.join(", ")}`}
                  >
                    {modes.join(", ")}
                  </span>
                ) : (
                  "—"
                )
              }
              amber
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
