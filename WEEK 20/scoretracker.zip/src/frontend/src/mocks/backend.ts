import type { backendInterface } from "../backend";

export const mockBackend: backendInterface = {
  addScore: async (_subject: string, _score: bigint) => undefined,
  clearScores: async () => undefined,
  deleteScore: async (_index: bigint) => undefined,
  getFrequency: async () => {
    // Frequency array indexed by score (0-100), non-zero entries for sample scores
    const freq = new Array(101).fill(BigInt(0));
    freq[75] = BigInt(1);
    freq[80] = BigInt(2);
    freq[85] = BigInt(2);
    freq[88] = BigInt(3);
    freq[90] = BigInt(4);
    freq[92] = BigInt(3);
    freq[95] = BigInt(1);
    return freq;
  },
  getScores: async () => [
    { subject: "Math", score: BigInt(92), timestamp: BigInt(Date.now() - 2 * 24 * 60 * 60 * 1000) },
    { subject: "English", score: BigInt(88), timestamp: BigInt(Date.now() - 4 * 24 * 60 * 60 * 1000) },
    { subject: "Science", score: BigInt(85), timestamp: BigInt(Date.now() - 6 * 24 * 60 * 60 * 1000) },
    { subject: "History", score: BigInt(90), timestamp: BigInt(Date.now() - 8 * 24 * 60 * 60 * 1000) },
    { subject: "Geography", score: BigInt(78), timestamp: BigInt(Date.now() - 11 * 24 * 60 * 60 * 1000) },
  ],
  getStats: async () => ({
    min: BigInt(78),
    max: BigInt(96),
    mean: 87.6,
    count: BigInt(12),
  }),
};
