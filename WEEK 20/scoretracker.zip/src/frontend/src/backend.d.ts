import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Stats {
    max: bigint;
    min: bigint;
    mean: number;
    count: bigint;
}
export interface ScoreEntry {
    subject: string;
    score: bigint;
    timestamp: bigint;
}
export type FrequencyArray = Array<bigint>;
export interface backendInterface {
    addScore(subject: string, score: bigint): Promise<void>;
    clearScores(): Promise<void>;
    deleteScore(index: bigint): Promise<void>;
    getFrequency(): Promise<FrequencyArray>;
    getScores(): Promise<Array<ScoreEntry>>;
    getStats(): Promise<Stats | null>;
}
