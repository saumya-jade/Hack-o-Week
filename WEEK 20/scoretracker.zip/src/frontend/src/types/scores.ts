export interface ScoreEntry {
  subject: string;
  score: number;
  timestamp: bigint;
}

export interface Stats {
  min: number;
  max: number;
  mean: number;
  count: number;
}

export interface FrequencyEntry {
  score: number;
  count: number;
}

export interface ScoreFormData {
  subject: string;
  score: string;
}
