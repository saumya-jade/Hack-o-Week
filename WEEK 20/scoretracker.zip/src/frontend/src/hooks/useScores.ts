import { type Backend, createActor } from "@/backend";
import type { FrequencyEntry, ScoreEntry, Stats } from "@/types/scores";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

type RawScoreEntry = { subject: string; score: bigint; timestamp: bigint };

function computeStatsLinear(scores: ScoreEntry[]): Stats | null {
  if (scores.length === 0) return null;
  let min = scores[0].score;
  let max = scores[0].score;
  let sum = 0;
  for (let i = 0; i < scores.length; i++) {
    const s = scores[i].score;
    if (s < min) min = s;
    if (s > max) max = s;
    sum += s;
  }
  return { min, max, mean: sum / scores.length, count: scores.length };
}

function computeFrequencyArray(scores: ScoreEntry[]): number[] {
  const freq = new Array<number>(101).fill(0);
  for (let i = 0; i < scores.length; i++) {
    const s = scores[i].score;
    if (s >= 0 && s <= 100) freq[s]++;
  }
  return freq;
}

function freqArrayToEntries(freq: number[]): FrequencyEntry[] {
  const result: FrequencyEntry[] = [];
  for (let i = 0; i <= 100; i++) {
    if (freq[i] > 0) result.push({ score: i, count: freq[i] });
  }
  return result;
}

function findModesLinear(freq: number[]): number[] {
  let maxCount = 0;
  for (let i = 0; i <= 100; i++) {
    if (freq[i] > maxCount) maxCount = freq[i];
  }
  if (maxCount === 0) return [];
  const modes: number[] = [];
  for (let i = 0; i <= 100; i++) {
    if (freq[i] === maxCount) modes.push(i);
  }
  return modes;
}

type BackendWithMethods = Backend & {
  getScores: () => Promise<RawScoreEntry[]>;
  addScore: (subject: string, score: bigint) => Promise<void>;
  deleteScore: (index: bigint) => Promise<void>;
  clearScores: () => Promise<void>;
};

export function useScores() {
  const { actor, isFetching } = useActor(createActor);
  const queryClient = useQueryClient();
  const enabled = !!actor && !isFetching;
  const typedActor = actor as BackendWithMethods | null;

  const scoresQuery = useQuery<ScoreEntry[]>({
    queryKey: ["scores"],
    queryFn: async () => {
      if (!typedActor?.getScores) return [];
      const raw = await typedActor.getScores();
      return raw.map((e: RawScoreEntry) => ({
        subject: e.subject,
        score: Number(e.score),
        timestamp: e.timestamp,
      }));
    },
    enabled,
  });

  const scores = scoresQuery.data ?? [];

  const freqArray = computeFrequencyArray(scores);
  const stats = computeStatsLinear(scores);
  const modes = findModesLinear(freqArray);
  const frequencyEntries = freqArrayToEntries(freqArray);

  const addScore = useMutation({
    mutationFn: async ({
      subject,
      score,
    }: { subject: string; score: number }) => {
      if (!typedActor?.addScore) throw new Error("Actor not ready");
      await typedActor.addScore(subject, BigInt(score));
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["scores"] }),
  });

  const deleteScore = useMutation({
    mutationFn: async (index: number) => {
      if (!typedActor?.deleteScore) throw new Error("Actor not ready");
      await typedActor.deleteScore(BigInt(index));
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["scores"] }),
  });

  const clearScores = useMutation({
    mutationFn: async () => {
      if (!typedActor?.clearScores) throw new Error("Actor not ready");
      await typedActor.clearScores();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["scores"] }),
  });

  return {
    scores,
    stats,
    modes,
    frequencyEntries,
    isLoading: scoresQuery.isLoading,
    addScore: (subject: string, score: number) =>
      addScore.mutate({ subject, score }),
    deleteScore: (index: number) => deleteScore.mutate(index),
    clearScores: () => clearScores.mutate(),
    isAdding: addScore.isPending,
    isDeleting: deleteScore.isPending,
    isClearing: clearScores.isPending,
  };
}
