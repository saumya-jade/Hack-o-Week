import { FrequencyTable } from "@/components/FrequencyTable";
import { ScoreForm } from "@/components/ScoreForm";
import { ScoreList } from "@/components/ScoreList";
import { StatsPanel } from "@/components/StatsPanel";
import { Badge } from "@/components/ui/badge";
import { useScores } from "@/hooks/useScores";
import { BarChart2 } from "lucide-react";
import { toast } from "sonner";

export default function App() {
  const {
    scores,
    stats,
    modes,
    frequencyEntries,
    isLoading,
    addScore,
    deleteScore,
    clearScores,
    isAdding,
    isClearing,
  } = useScores();

  function handleAdd(subject: string, score: number) {
    addScore(subject, score);
    toast.success(`Score added for ${subject}`);
  }

  function handleDelete(index: number, subject: string) {
    deleteScore(index);
    toast.success(`Removed score for ${subject}`);
  }

  function handleClear() {
    clearScores();
    toast.success("All scores cleared");
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-card border-b shadow-subtle sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
              <BarChart2 className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold font-display text-foreground">
              Score Tracker
            </span>
            <Badge
              variant="secondary"
              className="bg-primary/10 text-primary border-primary/20 font-semibold tabular-nums"
              data-ocid="header.score_count"
            >
              {stats?.count ?? 0}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground hidden sm:block">
            Exam Performance Dashboard
          </p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 flex-1 w-full">
        {/* Top row: form + stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
          <ScoreForm onAdd={handleAdd} isAdding={isAdding} />
          <StatsPanel stats={stats} modes={modes} isLoading={isLoading} />
        </div>

        {/* Bottom row: score list + frequency table */}
        <div className="grid grid-cols-1 lg:grid-cols-[1.15fr_1fr] gap-5">
          <ScoreList
            scores={scores}
            modes={modes}
            isLoading={isLoading}
            isClearing={isClearing}
            onDelete={handleDelete}
            onClear={handleClear}
          />
          <FrequencyTable
            frequencyEntries={frequencyEntries}
            modes={modes}
            isLoading={isLoading}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()}. Built with love using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              caffeine.ai
            </a>
          </p>
          <p className="text-xs text-muted-foreground hidden sm:block">
            Stats: linear traversal · Frequency: array-based (O(n))
          </p>
        </div>
      </footer>
    </div>
  );
}
