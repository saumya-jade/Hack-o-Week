# Design Brief: Exam Score Tracker

**Visual Direction:** Analytical clarity with educational warmth. Data-forward interface designed for learners seeking insight into performance patterns. Teal primary color conveys analytical confidence, warm amber highlights mode scores and pedagogical optimism.

**Tone:** Approachable authority. Focused on statistical insight without corporate coldness.

## Color Palette

| Token | Light OKLCH | Dark OKLCH | Usage |
|-------|-------------|-----------|-------|
| Primary | 0.55 0.18 200 | 0.68 0.16 200 | Statistics highlights, primary actions |
| Secondary/Accent | 0.72 0.15 80 | 0.85 0.12 80 | Mode badges, success highlights |
| Destructive | 0.55 0.2 25 | 0.65 0.18 22 | Delete actions, warnings |
| Muted | 0.94 0.02 0 | 0.2 0.01 0 | Row alternation, disabled states |
| Foreground | 0.12 0 0 | 0.93 0 0 | Text, primary contrast |

## Typography

| Tier | Font | Usage |
|------|------|-------|
| Display | Figtree 700 | App title, statistics labels |
| Body | DM Sans 400–500 | Form inputs, score entries, descriptions |
| Mono | JetBrains Mono 400 | Numeric scores, frequency data |

## Structural Zones

| Zone | Treatment | Elevation |
|------|-----------|-----------|
| Header | `bg-card border-b` border | Elevated with bottom border |
| Stats Panel | `bg-card` with left border `border-primary` | Card with accent left border for emphasis |
| Score List | `bg-background` with `row-alt` (even rows `bg-muted/30`) | Alternating rows for scannability |
| Form | `bg-card` rounded inputs, `border-input` focus ring `ring-primary` | Card context, clear affordance |

## Shape Language

- **Radius:** 0.625rem (consistent, approachable, not minimal)
- **Spacing:** Tight within lists (12px), loose between sections (24px), medium within cards (16px)
- **Shadows:** Subtle elevation on cards (`shadow-sm`), no shadows on list rows

## Component Patterns

- Stats display: numeric value in mono, label in display, unit appended in body
- Mode badge: amber background, teal text contrast maintained AA+
- Frequency bars: chart-1 (teal) for bars, muted background for container
- Delete button: destructive color on hover, `text-muted` at rest
- Input validation: ring-primary on focus, `border-destructive` on error state

## Motion

- All transitions: `transition-smooth` (0.3s cubic-bezier)
- Score list item delete: fade-out + slight scale
- Mode badge highlight: subtle background pulse on mount

## Constraints

- No gradients or glow effects — maintain analytical clarity
- Chart colors limited to chart-1 through chart-5, no arbitrary colors
- Icons use same foreground color as text they accompany
- Frequency distribution visual uses chart colors only

## Differentiation

Pedagogical teal paired with educational amber creates immediate distinction from generic productivity tools. Alternating row backgrounds and left-border emphasis on statistics panel prioritize information hierarchy over minimalist flatness.
