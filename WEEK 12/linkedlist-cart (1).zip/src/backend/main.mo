import Array "mo:base/Array";
import Float "mo:base/Float";
import Nat "mo:base/Nat";
import Text "mo:base/Text";

actor {
  type CartItem = {
    id: Nat;
    name: Text;
    price: Float;
    quantity: Nat;
  };

  // Doubly linked list node
  type Node = {
    item: CartItem;
    var prev: ?Nat; // index into nodes array
    var next: ?Nat;
  };

  // We store nodes in a mutable array-backed linked list using head/tail indices
  var nodes: [var ?Node] = Array.init(1000, null);
  var nodeCount: Nat = 0;
  var head: ?Nat = null;
  var tail: ?Nat = null;
  var nextId: Nat = 1;
  var size: Nat = 0;

  func allocNode(item: CartItem, prev: ?Nat, next: ?Nat): Nat {
    let idx = nodeCount;
    nodeCount += 1;
    nodes[idx] := ?{
      item = item;
      var prev = prev;
      var next = next;
    };
    idx
  };

  public func addToHead(name: Text, price: Float, quantity: Nat): async CartItem {
    let item: CartItem = { id = nextId; name = name; price = price; quantity = quantity };
    nextId += 1;
    let idx = allocNode(item, null, head);
    switch (head) {
      case null { tail := ?idx; };
      case (?h) {
        switch (nodes[h]) {
          case (?n) { n.prev := ?idx; };
          case null {};
        };
      };
    };
    head := ?idx;
    size += 1;
    item
  };

  public func addToTail(name: Text, price: Float, quantity: Nat): async CartItem {
    let item: CartItem = { id = nextId; name = name; price = price; quantity = quantity };
    nextId += 1;
    let idx = allocNode(item, tail, null);
    switch (tail) {
      case null { head := ?idx; };
      case (?t) {
        switch (nodes[t]) {
          case (?n) { n.next := ?idx; };
          case null {};
        };
      };
    };
    tail := ?idx;
    size += 1;
    item
  };

  public func removeById(id: Nat): async Bool {
    var current = head;
    var found = false;
    label search loop {
      switch (current) {
        case null { break search; };
        case (?idx) {
          switch (nodes[idx]) {
            case null { break search; };
            case (?n) {
              if (n.item.id == id) {
                // unlink
                switch (n.prev) {
                  case null { head := n.next; };
                  case (?p) {
                    switch (nodes[p]) {
                      case (?pn) { pn.next := n.next; };
                      case null {};
                    };
                  };
                };
                switch (n.next) {
                  case null { tail := n.prev; };
                  case (?nx) {
                    switch (nodes[nx]) {
                      case (?nn) { nn.prev := n.prev; };
                      case null {};
                    };
                  };
                };
                nodes[idx] := null;
                size -= 1;
                found := true;
                break search;
              };
              current := n.next;
            };
          };
        };
      };
    };
    found
  };

  public query func getCart(): async [CartItem] {
    var result: [CartItem] = [];
    var current = head;
    label walk loop {
      switch (current) {
        case null { break walk; };
        case (?idx) {
          switch (nodes[idx]) {
            case null { break walk; };
            case (?n) {
              result := Array.append(result, [n.item]);
              current := n.next;
            };
          };
        };
      };
    };
    result
  };

  public query func getTotal(): async Float {
    var current = head;
    var total: Float = 0.0;
    label walk loop {
      switch (current) {
        case null { break walk; };
        case (?idx) {
          switch (nodes[idx]) {
            case null { break walk; };
            case (?n) {
              total += n.item.price * Float.fromInt(n.item.quantity);
              current := n.next;
            };
          };
        };
      };
    };
    total
  };
}
