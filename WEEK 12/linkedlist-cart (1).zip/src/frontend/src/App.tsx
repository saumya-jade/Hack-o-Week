import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Toaster } from "@/components/ui/sonner";
import { type CartItem, cart } from "@/lib/linkedList";
import {
  ChevronRight,
  Github,
  Linkedin,
  Loader2,
  Package,
  Plus,
  ShoppingCart,
  Trash2,
  Twitter,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useState } from "react";
import { toast } from "sonner";

function formatINR(amount: number): string {
  return `₹${amount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function useCart() {
  const [items, setItems] = useState<CartItem[]>(() => cart.getAll());
  const [total, setTotal] = useState(() => cart.getTotal());

  const refresh = useCallback(() => {
    setItems(cart.getAll());
    setTotal(cart.getTotal());
  }, []);

  return { items, total, refresh };
}

export default function App() {
  const { items, total, refresh } = useCart();

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [removeId, setRemoveId] = useState("");

  const [addingHead, setAddingHead] = useState(false);
  const [addingTail, setAddingTail] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [removingId, setRemovingId] = useState<bigint | null>(null);

  const validateForm = () => {
    if (!name.trim()) {
      toast.error("Product name is required");
      return false;
    }
    const p = Number.parseFloat(price);
    if (Number.isNaN(p) || p <= 0) {
      toast.error("Enter a valid price");
      return false;
    }
    const q = Number.parseInt(quantity);
    if (Number.isNaN(q) || q <= 0) {
      toast.error("Enter a valid quantity");
      return false;
    }
    return true;
  };

  const resetForm = () => {
    setName("");
    setPrice("");
    setQuantity("1");
  };

  const handleAddHead = async () => {
    if (!validateForm()) return;
    setAddingHead(true);
    await new Promise((r) => setTimeout(r, 300));
    cart.addToHead(
      name.trim(),
      Number.parseFloat(price),
      BigInt(Number.parseInt(quantity)),
    );
    refresh();
    resetForm();
    toast.success("Item added to head of cart");
    setAddingHead(false);
  };

  const handleAddTail = async () => {
    if (!validateForm()) return;
    setAddingTail(true);
    await new Promise((r) => setTimeout(r, 300));
    cart.addToTail(
      name.trim(),
      Number.parseFloat(price),
      BigInt(Number.parseInt(quantity)),
    );
    refresh();
    resetForm();
    toast.success("Item added to tail of cart");
    setAddingTail(false);
  };

  const handleRemoveById = async () => {
    const id = Number.parseInt(removeId);
    if (Number.isNaN(id) || id <= 0) {
      toast.error("Enter a valid item ID");
      return;
    }
    setRemoving(true);
    await new Promise((r) => setTimeout(r, 300));
    const removed = cart.removeById(BigInt(id));
    refresh();
    if (removed) {
      toast.success(`Item #${id} removed`);
      setRemoveId("");
    } else {
      toast.error(`Item #${id} not found`);
    }
    setRemoving(false);
  };

  const handleInlineRemove = async (id: bigint) => {
    setRemovingId(id);
    await new Promise((r) => setTimeout(r, 300));
    cart.removeById(id);
    refresh();
    toast.success("Item removed");
    setRemovingId(null);
  };

  const shipping = items.length > 0 ? 99 : 0;
  const grandTotal = total + shipping;

  return (
    <div className="min-h-screen flex flex-col bg-background font-sans">
      <Toaster position="top-right" />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border shadow-xs">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center">
              <ShoppingCart className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-bold text-base text-foreground tracking-tight">
              GlowCart
            </span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            {["Products", "Skincare Tips", "Offers", "About"].map((link) => (
              <a
                key={link}
                href="/"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {link}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center hover:bg-muted transition-colors"
            >
              <Package className="w-4 h-4 text-muted-foreground" />
            </button>
            <Button
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs px-4"
              data-ocid="header.get_started.button"
            >
              Shop Now
            </Button>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground tracking-tight">
            Skincare Shop
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            All prices in Indian Rupees (₹)
          </p>
          <Separator className="mt-4" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* Left: Manage Cart */}
          <Card className="shadow-card border border-border">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg font-semibold">
                Add to Cart
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Add New Item */}
              <div className="space-y-3">
                <p className="text-sm font-semibold text-foreground">
                  Skincare Product
                </p>
                <div>
                  <Label
                    htmlFor="product-name"
                    className="text-xs text-muted-foreground mb-1 block"
                  >
                    Product Name
                  </Label>
                  <Input
                    id="product-name"
                    placeholder="e.g. Vitamin C Serum"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="text-sm"
                    data-ocid="cart.input"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label
                      htmlFor="price"
                      className="text-xs text-muted-foreground mb-1 block"
                    >
                      Price (₹)
                    </Label>
                    <Input
                      id="price"
                      type="number"
                      placeholder="0"
                      min="0"
                      step="1"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="text-sm"
                      data-ocid="cart.price.input"
                    />
                  </div>
                  <div>
                    <Label
                      htmlFor="quantity"
                      className="text-xs text-muted-foreground mb-1 block"
                    >
                      Quantity
                    </Label>
                    <Input
                      id="quantity"
                      type="number"
                      placeholder="1"
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      className="text-sm"
                      data-ocid="cart.quantity.input"
                    />
                  </div>
                </div>
                <Button
                  type="button"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-sm"
                  onClick={handleAddHead}
                  disabled={addingHead || addingTail}
                  data-ocid="cart.add_head.button"
                >
                  {addingHead ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="w-4 h-4 mr-2" />
                  )}
                  {addingHead ? "Adding..." : "Add to Head of Cart"}
                </Button>
                <Button
                  type="button"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-sm"
                  onClick={handleAddTail}
                  disabled={addingHead || addingTail}
                  data-ocid="cart.add_tail.button"
                >
                  {addingTail ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="w-4 h-4 mr-2" />
                  )}
                  {addingTail ? "Adding..." : "Add to Tail of Cart"}
                </Button>
              </div>

              <Separator />

              {/* Remove by ID */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-foreground">Actions</p>
                <div className="flex gap-2">
                  <Input
                    placeholder="Item ID to remove"
                    value={removeId}
                    onChange={(e) => setRemoveId(e.target.value)}
                    type="number"
                    min="1"
                    className="text-sm flex-1"
                    data-ocid="cart.remove_id.input"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleRemoveById}
                    disabled={removing}
                    className="border-border text-sm shrink-0"
                    data-ocid="cart.remove.button"
                  >
                    {removing ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    {removing ? "Removing" : "Remove"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Right column */}
          <div className="space-y-6">
            {/* Cart List */}
            <Card className="shadow-card border border-border">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">
                    Your Cart
                  </CardTitle>
                  <Badge variant="secondary" className="text-xs font-medium">
                    {items.length} item{items.length !== 1 ? "s" : ""}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {items.length === 0 ? (
                  <div
                    className="px-6 py-12 text-center"
                    data-ocid="cart.empty_state"
                  >
                    <ShoppingCart className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-40" />
                    <p className="text-sm text-muted-foreground">
                      Your cart is empty
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Add skincare products using the form on the left
                    </p>
                  </div>
                ) : (
                  <AnimatePresence initial={false}>
                    {items.map((item, idx) => (
                      <motion.div
                        key={item.id.toString()}
                        initial={{ opacity: 0, y: -8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.2 }}
                        data-ocid={`cart.item.${idx + 1}`}
                      >
                        {idx > 0 && <Separator />}
                        <div className="flex items-center justify-between px-6 py-3 hover:bg-muted/30 transition-colors">
                          <div className="flex items-center gap-3 min-w-0">
                            <span className="w-6 h-6 rounded bg-secondary text-muted-foreground text-xs font-semibold flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-foreground truncate">
                                {item.name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatINR(item.price)} &nbsp;·&nbsp; Qty:{" "}
                                {item.quantity.toString()} &nbsp;·&nbsp; ID:{" "}
                                {item.id.toString()}
                              </p>
                            </div>
                          </div>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="ml-3 shrink-0 text-xs px-3 py-1 h-7 border-border text-muted-foreground hover:text-destructive hover:border-destructive"
                            onClick={() => handleInlineRemove(item.id)}
                            disabled={removingId === item.id}
                            data-ocid={`cart.delete_button.${idx + 1}`}
                          >
                            {removingId === item.id ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Trash2 className="w-3 h-3" />
                            )}
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </CardContent>
            </Card>

            {/* Order Summary */}
            <Card className="shadow-card border border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-semibold">
                  Order Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-medium">{formatINR(total)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="font-medium">
                    {shipping === 0 ? "Free" : formatINR(shipping)}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between text-base font-bold">
                  <span>Total Price</span>
                  <span>{formatINR(grandTotal)}</span>
                </div>
                <Button
                  type="button"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 mt-2"
                  disabled={items.length === 0}
                  onClick={() =>
                    toast.success("Proceeding to checkout!", {
                      description: `Order total: ${formatINR(grandTotal)}`,
                    })
                  }
                  data-ocid="cart.checkout.button"
                >
                  Proceed to Checkout
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-8">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} GlowCart. Built with ❤️ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              className="underline hover:text-foreground transition-colors"
              target="_blank"
              rel="noreferrer"
            >
              caffeine.ai
            </a>
          </p>
          <div className="flex items-center gap-4">
            {["Privacy", "Terms", "Contact"].map((l) => (
              <a
                key={l}
                href="/"
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                {l}
              </a>
            ))}
            <div className="flex gap-2">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
