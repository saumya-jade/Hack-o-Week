export interface CartItem {
  id: bigint;
  name: string;
  price: number;
  quantity: bigint;
}

interface Node {
  item: CartItem;
  prev: Node | null;
  next: Node | null;
}

let nextId = 1n;

export class DoublyLinkedList {
  private head: Node | null = null;
  private tail: Node | null = null;
  private size = 0;

  addToHead(name: string, price: number, quantity: bigint): CartItem {
    const item: CartItem = { id: nextId++, name, price, quantity };
    const node: Node = { item, prev: null, next: this.head };
    if (this.head) {
      this.head.prev = node;
    } else {
      this.tail = node;
    }
    this.head = node;
    this.size++;
    return item;
  }

  addToTail(name: string, price: number, quantity: bigint): CartItem {
    const item: CartItem = { id: nextId++, name, price, quantity };
    const node: Node = { item, prev: this.tail, next: null };
    if (this.tail) {
      this.tail.next = node;
    } else {
      this.head = node;
    }
    this.tail = node;
    this.size++;
    return item;
  }

  removeById(id: bigint): boolean {
    let curr = this.head;
    while (curr) {
      if (curr.item.id === id) {
        if (curr.prev) curr.prev.next = curr.next;
        else this.head = curr.next;
        if (curr.next) curr.next.prev = curr.prev;
        else this.tail = curr.prev;
        this.size--;
        return true;
      }
      curr = curr.next;
    }
    return false;
  }

  getAll(): CartItem[] {
    const items: CartItem[] = [];
    let curr = this.head;
    while (curr) {
      items.push(curr.item);
      curr = curr.next;
    }
    return items;
  }

  getTotal(): number {
    let total = 0;
    let curr = this.head;
    while (curr) {
      total += curr.item.price * Number(curr.item.quantity);
      curr = curr.next;
    }
    return total;
  }

  getSize(): number {
    return this.size;
  }
}

export const cart = new DoublyLinkedList();

// Seed with skincare products in INR
cart.addToTail("Cetaphil Gentle Skin Cleanser", 499, 1n);
cart.addToTail("Minimalist 10% Niacinamide Serum", 599, 1n);
cart.addToTail("Neutrogena Sunscreen SPF 50", 399, 2n);
