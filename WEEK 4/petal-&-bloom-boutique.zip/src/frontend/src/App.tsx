import { Toaster } from "@/components/ui/sonner";
import { Instagram, ShoppingBag } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";

interface Product {
  id: number;
  name: string;
  price: string;
  label: string;
  studio: string;
  lifestyle: string;
}

interface BagEntry {
  uid: string;
  name: string;
}

const PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Jumbo Silk Hair Bow",
    price: "$18",
    label: "Bestie Favorite",
    studio: "/assets/generated/hair-bow.dim_600x600.jpg",
    lifestyle: "/assets/generated/hair-bow-lifestyle.dim_600x600.jpg",
  },
  {
    id: 2,
    name: "Puffy Cloud Spa Headband",
    price: "$14",
    label: "Viral Item",
    studio: "/assets/generated/spa-headband.dim_600x600.jpg",
    lifestyle: "/assets/generated/spa-headband-lifestyle.dim_600x600.jpg",
  },
  {
    id: 3,
    name: "Heart-Shaped Gua Sha Tool",
    price: "$22",
    label: "Handpicked",
    studio: "/assets/generated/gua-sha.dim_600x600.jpg",
    lifestyle: "/assets/generated/gua-sha-lifestyle.dim_600x600.jpg",
  },
  {
    id: 4,
    name: 'Ceramic "Tulip" Coffee Mug',
    price: "$28",
    label: "Limited Drop",
    studio: "/assets/generated/tulip-mug.dim_600x600.jpg",
    lifestyle: "/assets/generated/tulip-mug-lifestyle.dim_600x600.jpg",
  },
  {
    id: 5,
    name: "Beaded Phone Charm String",
    price: "$12",
    label: "Handpicked",
    studio: "/assets/generated/phone-charm.dim_600x600.jpg",
    lifestyle: "/assets/generated/phone-charm-lifestyle.dim_600x600.jpg",
  },
  {
    id: 6,
    name: "Fuzzy Faux Fur Room Slippers",
    price: "$32",
    label: "Bestie Favorite",
    studio: "/assets/generated/fur-slippers.dim_600x600.jpg",
    lifestyle: "/assets/generated/fur-slippers-lifestyle.dim_600x600.jpg",
  },
  {
    id: 7,
    name: "Lace-Trimmed Daily Planner",
    price: "$16",
    label: "Handpicked",
    studio: "/assets/generated/lace-planner.dim_600x600.jpg",
    lifestyle: "/assets/generated/lace-planner-lifestyle.dim_600x600.jpg",
  },
  {
    id: 8,
    name: '"Mystery" Aesthetic Bundle',
    price: "$38",
    label: "Limited Drop",
    studio: "/assets/generated/mystery-bundle.dim_600x600.jpg",
    lifestyle: "/assets/generated/mystery-bundle-lifestyle.dim_600x600.jpg",
  },
];

const LABEL_STYLE: Record<string, string> = {
  "Bestie Favorite": "bg-primary text-primary-foreground",
  "Viral Item": "bg-primary text-primary-foreground",
  Handpicked: "bg-primary text-primary-foreground",
  "Limited Drop": "bg-foreground text-background",
};

const INSTAGRAM_IMAGES = [
  { id: "ig1", src: "/assets/generated/hair-bow-lifestyle.dim_600x600.jpg" },
  {
    id: "ig2",
    src: "/assets/generated/spa-headband-lifestyle.dim_600x600.jpg",
  },
  { id: "ig3", src: "/assets/generated/tulip-mug-lifestyle.dim_600x600.jpg" },
  { id: "ig4", src: "/assets/generated/gua-sha-lifestyle.dim_600x600.jpg" },
  {
    id: "ig5",
    src: "/assets/generated/fur-slippers-lifestyle.dim_600x600.jpg",
  },
  {
    id: "ig6",
    src: "/assets/generated/mystery-bundle-lifestyle.dim_600x600.jpg",
  },
];

let uidCounter = 0;
function nextUid() {
  uidCounter += 1;
  return `bag-${uidCounter}`;
}

function ProductCard({
  product,
  index,
  onAddToBag,
}: { product: Product; index: number; onAddToBag: (name: string) => void }) {
  return (
    <motion.div
      className="product-card group bg-card rounded-lg overflow-hidden shadow-card cursor-default"
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.07, ease: "easeOut" }}
      data-ocid={`product.item.${index + 1}`}
    >
      <div className="relative w-full aspect-square overflow-hidden bg-secondary">
        <img
          src={product.studio}
          alt={product.name}
          className="img-studio absolute inset-0 w-full h-full object-cover transition-opacity duration-500"
        />
        <img
          src={product.lifestyle}
          alt={`${product.name} lifestyle`}
          className="img-lifestyle absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-500"
        />
        <span
          className={`absolute bottom-3 left-3 text-xs font-semibold tracking-wide px-3 py-1 rounded-full ${
            LABEL_STYLE[product.label] ?? "bg-primary text-primary-foreground"
          }`}
          data-ocid={`product.tag.${index + 1}`}
        >
          {product.label}
        </span>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-3">
          <h3 className="font-serif text-foreground text-base leading-snug">
            {product.name}
          </h3>
          <span className="text-sm font-bold text-foreground whitespace-nowrap">
            {product.price}
          </span>
        </div>
        <button
          type="button"
          onClick={() => onAddToBag(product.name)}
          className="w-full py-2.5 text-sm font-semibold tracking-widest uppercase rounded bg-primary text-primary-foreground hover:opacity-90 active:scale-[0.98] transition-all duration-150"
          data-ocid={`product.button.${index + 1}`}
        >
          Add to Bag
        </button>
      </div>
    </motion.div>
  );
}

export default function App() {
  const [bagItems, setBagItems] = useState<BagEntry[]>([]);
  const [bagOpen, setBagOpen] = useState(false);

  const bagCount = bagItems.length;

  function handleAddToBag(name: string) {
    setBagItems((prev) => [...prev, { uid: nextUid(), name }]);
    toast.success(`${name} added to bag! 🌸`, {
      description: "Keep shopping or check out when ready.",
      duration: 2500,
    });
  }

  return (
    <div className="min-h-screen bg-background petal-bg">
      <Toaster position="top-right" richColors />

      {/* Header */}
      <header className="bg-secondary sticky top-0 z-50 border-b border-border/50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <a
            href="/"
            className="font-serif text-2xl text-foreground tracking-widest uppercase"
            data-ocid="nav.link"
          >
            Petal &amp; Bloom
          </a>

          <nav
            className="hidden md:flex items-center gap-8"
            aria-label="Main navigation"
          >
            {["Home", "Shop", "About"].map((link) => (
              <a
                key={link}
                href="/"
                className="text-sm tracking-widest uppercase text-muted-foreground hover:text-foreground transition-colors"
                data-ocid="nav.link"
              >
                {link}
              </a>
            ))}
          </nav>

          <button
            type="button"
            onClick={() => setBagOpen((o) => !o)}
            className="relative p-2 hover:bg-background/60 rounded-full transition-colors"
            aria-label={`Shopping bag, ${bagCount} items`}
            data-ocid="bag.open_modal_button"
          >
            <ShoppingBag className="w-5 h-5 text-foreground" />
            <AnimatePresence>
              {bagCount > 0 && (
                <motion.span
                  key="badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="absolute -top-0.5 -right-0.5 w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center"
                >
                  {bagCount}
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>

        <AnimatePresence>
          {bagOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="absolute right-6 top-full mt-2 w-80 bg-card rounded-lg shadow-card border border-border z-50 p-5"
              data-ocid="bag.panel"
            >
              <h4 className="font-serif text-lg mb-3 text-foreground">
                Your Bag
              </h4>
              {bagItems.length === 0 ? (
                <p
                  className="text-muted-foreground text-sm"
                  data-ocid="bag.empty_state"
                >
                  Your bag is empty.
                </p>
              ) : (
                <ul className="space-y-2 max-h-64 overflow-y-auto">
                  {bagItems.map((entry, i) => (
                    <li
                      key={entry.uid}
                      className="text-sm text-foreground flex items-center gap-2"
                      data-ocid={`bag.item.${i + 1}`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
                      {entry.name}
                    </li>
                  ))}
                </ul>
              )}
              {bagItems.length > 0 && (
                <button
                  type="button"
                  className="mt-4 w-full py-2.5 text-sm font-semibold tracking-widest uppercase rounded bg-primary text-primary-foreground hover:opacity-90 transition"
                  data-ocid="bag.submit_button"
                >
                  Checkout · {bagCount} {bagCount === 1 ? "item" : "items"}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Hero */}
      <section className="py-20 px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        >
          <p className="text-xs tracking-[0.4em] uppercase text-muted-foreground mb-4">
            New Collection
          </p>
          <h1 className="font-serif text-5xl md:text-7xl text-foreground uppercase tracking-wider leading-tight mb-5">
            Curated
            <br />
            <em className="not-italic text-primary">For You</em>
          </h1>
          <p className="text-muted-foreground text-base md:text-lg max-w-md mx-auto leading-relaxed">
            A carefully selected collection of aesthetic essentials — because
            every detail of your world deserves to be beautiful.
          </p>
        </motion.div>
        <div className="flex items-center justify-center gap-4 mt-10">
          <div className="h-px w-16 bg-border" />
          <span className="text-primary text-lg">❀</span>
          <div className="h-px w-16 bg-border" />
        </div>
      </section>

      {/* Product Grid */}
      <main className="max-w-6xl mx-auto px-6 pb-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-serif text-xl text-foreground uppercase tracking-widest">
            The Collection
          </h2>
          <span className="text-sm text-muted-foreground">
            {PRODUCTS.length} pieces
          </span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-5 lg:gap-7">
          {PRODUCTS.map((product, i) => (
            <ProductCard
              key={product.id}
              product={product}
              index={i}
              onAddToBag={handleAddToBag}
            />
          ))}
        </div>
      </main>

      {/* Follow our Journey */}
      <section className="bg-secondary py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-10"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <p className="text-xs tracking-[0.4em] uppercase text-muted-foreground mb-2">
              Stay Connected
            </p>
            <h2 className="font-serif text-3xl text-foreground uppercase tracking-widest mb-2">
              Follow Our Journey
            </h2>
            <div className="flex items-center justify-center gap-2 text-primary">
              <Instagram className="w-4 h-4" />
              <span className="text-sm font-semibold tracking-wide">
                @petalnbloom
              </span>
            </div>
          </motion.div>

          <div className="grid grid-cols-3 md:grid-cols-6 gap-2 md:gap-3">
            {INSTAGRAM_IMAGES.map((img, i) => (
              <motion.div
                key={img.id}
                className="aspect-square overflow-hidden rounded-md cursor-pointer group"
                initial={{ opacity: 0, scale: 0.96 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                data-ocid={`instagram.item.${i + 1}`}
              >
                <img
                  src={img.src}
                  alt={`Petal and Bloom lifestyle ${i + 1}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-8">
            <a
              href="https://instagram.com/petalnbloom"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 border border-primary text-primary text-sm font-semibold tracking-widest uppercase rounded hover:bg-primary hover:text-primary-foreground transition-all duration-200"
              data-ocid="instagram.link"
            >
              <Instagram className="w-4 h-4" />
              View on Instagram
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary border-t border-border/50 py-10 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <p className="font-serif text-xl text-foreground uppercase tracking-widest mb-1">
                Petal &amp; Bloom
              </p>
              <p className="text-xs text-muted-foreground">
                Aesthetic essentials, curated with love.
              </p>
            </div>
            <nav
              className="flex items-center gap-6"
              aria-label="Footer navigation"
            >
              {["FAQ", "Returns", "Contact"].map((link) => (
                <a
                  key={link}
                  href="/"
                  className="text-xs tracking-widest uppercase text-muted-foreground hover:text-foreground transition-colors"
                  data-ocid="footer.link"
                >
                  {link}
                </a>
              ))}
            </nav>
          </div>
          <div className="mt-8 pt-6 border-t border-border/50 flex flex-col md:flex-row items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              &copy; {new Date().getFullYear()} Petal &amp; Bloom. All rights
              reserved.
            </p>
            <p className="text-xs text-muted-foreground">
              Built with love using{" "}
              <a
                href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-foreground transition-colors"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
