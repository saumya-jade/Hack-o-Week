# Petal & Bloom Boutique

## Current State
New project — no existing application files beyond scaffold.

## Requested Changes (Diff)

### Add
- Aesthetic boutique product listing page with 8 curated feminine products
- Product cards with hover image-swap effect (studio to lifestyle shot)
- Curated labels: Limited Drop, Handpicked, Bestie Favorite
- Add to Bag functionality with bag counter in the header
- Follow our Journey Instagram-style section at bottom
- Responsive layout: 3-column desktop, 2-column mobile

### Modify
- N/A

### Remove
- N/A

## Implementation Plan
1. Backend: product catalog with bag state (add to bag, get bag count, get products)
2. Frontend: header with logo + bag counter, hero title, product grid, hover effect, Instagram section, footer
3. Products: Jumbo Silk Hair Bow, Puffy Cloud Spa Headband, Heart-Shaped Gua Sha Tool, Ceramic Tulip Coffee Mug, Beaded Phone Charm String, Fuzzy Faux Fur Room Slippers, Lace-Trimmed Daily Planner, Mystery Aesthetic Bundle
4. Champagne pink and cream palette, Playfair Display serif font
